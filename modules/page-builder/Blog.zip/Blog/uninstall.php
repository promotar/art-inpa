<?php

use Illuminate\Support\Facades\Schema;

foreach (['blog_post_tag', 'blog_posts', 'blog_tags', 'blog_categories'] as $table) {
    Schema::dropIfExists($table);
}

return true;
