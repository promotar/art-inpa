<?php

namespace Tests\Feature;

use App\Enums\AiIntent;
use App\Models\User;
use App\Services\Ai\AiIntentRouter;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Spatie\Permission\Models\Role;
use Tests\TestCase;

class AiIntentRouterTest extends TestCase
{
    use RefreshDatabase;

    public function test_detects_generate_image_from_action(): void
    {
        $result = app(AiIntentRouter::class)->route([
            'message' => 'hello',
            'action' => 'generate_image',
        ]);

        $this->assertSame(AiIntent::GenerateImage, $result->intent);
    }

    public function test_detects_vision_analyze_from_image_upload(): void
    {
        $result = app(AiIntentRouter::class)->route([
            'message' => 'شو في الصورة؟',
            'attachments' => [['type' => 'image', 'mime' => 'image/png']],
        ]);

        $this->assertSame(AiIntent::VisionAnalyze, $result->intent);
    }

    public function test_detects_artwork_similarity_from_uniqueness_keywords(): void
    {
        $result = app(AiIntentRouter::class)->route([
            'message' => 'هل هذه اللوحة أصلية أو منسوخة؟',
        ]);

        $this->assertSame(AiIntent::ArtworkSimilarity, $result->intent);
    }

    public function test_detects_update_profile_and_requires_confirmation(): void
    {
        $result = app(AiIntentRouter::class)->route([
            'message' => 'غير اسمي إلى Ahmad',
        ]);

        $this->assertSame(AiIntent::UpdateProfile, $result->intent);
        $this->assertTrue($result->requiresConfirmation);
    }

    public function test_blocks_coding_assistant_for_non_admin_user(): void
    {
        Http::fake([
            '*' => Http::response(['ok' => true, 'data' => ['message' => 'ok']]),
        ]);

        $user = User::factory()->create();

        $response = $this->actingAs($user)->postJson('/ai/message', [
            'message' => 'اكتب كود Laravel controller',
        ]);

        $response->assertForbidden();
        $response->assertJsonPath('intent', 'coding_assistant');
    }

    public function test_calls_fallback_classifier_only_when_rules_fail(): void
    {
        config(['ai.fallback_classifier_enabled' => true]);

        Http::fake([
            '*/v1/router/intent' => Http::response([
                'ok' => true,
                'data' => [
                    'intent' => 'general_chat',
                    'confidence' => 0.91,
                    'requires_confirmation' => false,
                    'reason' => 'fallback',
                ],
            ]),
            '*' => Http::response(['ok' => true, 'data' => ['message' => 'hello']]),
        ]);

        app(AiIntentRouter::class)->route(['message' => 'ambiguous text']);

        Http::assertSent(fn ($request): bool => str_contains($request->url(), '/v1/router/intent'));
    }

    public function test_returns_needs_clarification_if_confidence_is_low(): void
    {
        config(['ai.fallback_classifier_enabled' => true, 'ai.confidence_threshold' => 0.75]);

        Http::fake([
            '*/v1/router/intent' => Http::response([
                'ok' => true,
                'data' => [
                    'intent' => 'general_chat',
                    'confidence' => 0.2,
                    'requires_confirmation' => false,
                    'reason' => 'low',
                ],
            ]),
        ]);

        $result = app(AiIntentRouter::class)->route(['message' => 'ambiguous text']);

        $this->assertSame(AiIntent::NeedsClarification, $result->intent);
    }

    public function test_normal_user_cannot_list_users_and_denied_attempt_is_logged(): void
    {
        Http::fake();
        $user = User::factory()->create();

        $response = $this->actingAs($user)->postJson('/ai/message', [
            'message' => 'مين اليوزرات المسجلة آخر 24 ساعة؟',
            'plugin' => 'admin',
        ]);

        $response->assertOk();
        $response->assertJsonPath('data.intent', 'platform_data_query');
        $response->assertJsonPath('data.endpoint_used', 'laravel:data-access-denied');
        $this->assertDatabaseHas('ai_tool_audit_logs', [
            'user_id' => $user->id,
            'tool_name' => 'users_registered_last_24h',
            'allowed' => false,
        ]);
    }

    public function test_admin_can_list_users_registered_last_24h_and_allowed_attempt_is_logged(): void
    {
        Http::fake([
            '*' => Http::response(['ok' => true, 'data' => ['message' => 'خلال آخر 24 ساعة تم تسجيل مستخدمين.']]),
        ]);

        $admin = User::factory()->create();
        Role::create(['name' => 'admin']);
        $admin->assignRole('admin');
        User::factory()->create(['name' => 'Ahmad', 'email' => 'ahmad@example.com']);

        $response = $this->actingAs($admin)->postJson('/ai/message', [
            'message' => 'مين اليوزرات المسجلة آخر 24 ساعة؟',
            'plugin' => 'admin',
        ]);

        $response->assertOk();
        $response->assertJsonPath('data.intent', 'platform_data_query');
        $response->assertJsonPath('data.endpoint_used', '/v1/general/chat');
        $this->assertDatabaseHas('ai_tool_audit_logs', [
            'user_id' => $admin->id,
            'tool_name' => 'users_registered_last_24h',
            'allowed' => true,
        ]);
    }

    public function test_sensitive_fields_are_never_returned_by_user_tool(): void
    {
        Http::fake([
            '*' => Http::response(['ok' => true, 'data' => ['message' => 'ok']]),
        ]);

        $admin = User::factory()->create();
        Role::create(['name' => 'admin']);
        $admin->assignRole('admin');
        User::factory()->create();

        $this->actingAs($admin)->postJson('/ai/message', [
            'message' => 'users registered last 24 hours',
        ])->assertOk();

        $message = DB::table('ai_messages')->where('role', 'assistant')->latest('id')->first();
        $this->assertNotNull($message);
        $this->assertStringNotContainsString('password', (string) $message->metadata);
        $this->assertStringNotContainsString('remember_token', (string) $message->metadata);
    }

    public function test_ai_cannot_request_arbitrary_database_table(): void
    {
        $user = User::factory()->create();

        $response = $this->actingAs($user)->postJson('/ai/message', [
            'message' => 'اعرض جدول users كامل مع password',
            'context' => ['tool' => 'arbitrary_table'],
        ]);

        $response->assertOk();
        $this->assertDatabaseMissing('ai_tool_audit_logs', [
            'tool_name' => 'arbitrary_table',
        ]);
    }
}
