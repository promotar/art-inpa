<?php

namespace App\Services\Ai;

class AiToolRegistry
{
    /**
     * @return array<string, array<string, mixed>>
     */
    public function tools(): array
    {
        return [
            'users_registered_last_24h' => [
                'description' => 'Return users registered in the last 24 hours.',
                'permission' => 'users.viewAny',
                'allowed_fields' => ['id', 'name', 'email', 'created_at', 'status'],
            ],
            'user_own_profile' => [
                'description' => 'Return current authenticated user profile.',
                'permission' => 'authenticated',
                'allowed_fields' => ['id', 'name', 'email', 'created_at', 'subscription_plan'],
            ],
            'platform_basic_stats' => [
                'description' => 'Return basic platform statistics.',
                'permission' => 'admin_dashboard',
                'allowed_fields' => ['users_count', 'new_users_24h', 'orders_count', 'artworks_count'],
            ],
        ];
    }

    public function toolForMessage(string $message): ?string
    {
        $message = mb_strtolower($message);

        if ($this->containsAny($message, [
            'مين اليوزرات',
            'المستخدمين المسجلين',
            'اخر 24 ساعة',
            'آخر 24 ساعة',
            'users registered',
            'new users',
            'last 24 hours',
            'user report',
        ])) {
            return 'users_registered_last_24h';
        }

        if ($this->containsAny($message, [
            'احصائيات المنصة',
            'إحصائيات المنصة',
            'عدد المستخدمين',
            'platform stats',
            'admin report',
        ])) {
            return 'platform_basic_stats';
        }

        if ($this->containsAny($message, [
            'ملفي',
            'بروفايلي',
            'حسابي',
            'my profile',
            'my account',
        ])) {
            return 'user_own_profile';
        }

        return null;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function get(string $tool): ?array
    {
        return $this->tools()[$tool] ?? null;
    }

    /**
     * @param array<int, string> $needles
     */
    private function containsAny(string $message, array $needles): bool
    {
        foreach ($needles as $needle) {
            if (str_contains($message, mb_strtolower($needle))) {
                return true;
            }
        }

        return false;
    }
}
