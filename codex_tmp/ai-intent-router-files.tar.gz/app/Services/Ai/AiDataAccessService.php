<?php

namespace App\Services\Ai;

use App\Enums\AiIntent;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class AiDataAccessService
{
    public function __construct(
        private readonly AiToolRegistry $tools,
        private readonly AiPermissionChecker $permissions,
        private readonly AiAdminReportService $reports,
    ) {
        //
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    public function execute(string $tool, ?User $user, AiIntent $intent, Request $request, array $input = []): array
    {
        if (! $this->tools->get($tool)) {
            $result = [
                'ok' => false,
                'authorized' => false,
                'error' => 'This AI data tool is not registered.',
            ];
            $this->audit($user, $tool, $intent, false, $result['error'], $input, null, $request);

            return $result;
        }

        if (! $this->permissions->canAccessTool($user, $tool)) {
            $reason = $this->permissions->getToolDeniedReason($user, $tool);
            $this->audit($user, $tool, $intent, false, $reason, $input, null, $request);

            return [
                'ok' => false,
                'authorized' => false,
                'error' => $reason,
            ];
        }

        $result = match ($tool) {
            'users_registered_last_24h' => $this->usersRegisteredLast24h(),
            'user_own_profile' => $this->userOwnProfile($user),
            'platform_basic_stats' => $this->platformBasicStats(),
            default => ['count' => 0, 'items' => []],
        };

        $count = (int) ($result['count'] ?? count($result['items'] ?? []));
        $this->audit($user, $tool, $intent, true, null, $input, $count, $request);

        return [
            'ok' => true,
            'tool' => $tool,
            'authorized' => true,
            'data' => $result,
        ];
    }

    /**
     * @return array{count:int,items:array<int,array<string,mixed>>}
     */
    private function usersRegisteredLast24h(): array
    {
        if (! Schema::hasTable('users')) {
            return ['count' => 0, 'items' => []];
        }

        $items = User::query()
            ->where('created_at', '>=', now()->subDay())
            ->orderByDesc('created_at')
            ->limit(50)
            ->get(['id', 'name', 'email', 'created_at'])
            ->map(fn (User $user): array => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'created_at' => optional($user->created_at)->format('Y-m-d H:i:s'),
                'status' => 'active',
            ])
            ->values()
            ->all();

        return [
            'count' => count($items),
            'items' => $items,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function userOwnProfile(?User $user): array
    {
        if (! $user) {
            return ['count' => 0, 'items' => []];
        }

        return [
            'count' => 1,
            'items' => [[
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'created_at' => optional($user->created_at)->format('Y-m-d H:i:s'),
                'subscription_plan' => data_get($user, 'subscription_plan', 'default'),
            ]],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function platformBasicStats(): array
    {
        return [
            'count' => 1,
            'items' => [$this->reports->basicStats()],
        ];
    }

    /**
     * @param array<string, mixed> $input
     */
    private function audit(?User $user, string $tool, AiIntent $intent, bool $allowed, ?string $reason, array $input, ?int $resultCount, Request $request): void
    {
        if (! Schema::hasTable('ai_tool_audit_logs')) {
            return;
        }

        DB::table('ai_tool_audit_logs')->insert([
            'user_id' => $user?->id,
            'tool_name' => $tool,
            'intent' => $intent->value,
            'allowed' => $allowed,
            'denied_reason' => $reason,
            'input_summary' => json_encode([
                'message_length' => isset($input['message']) ? mb_strlen((string) $input['message']) : null,
                'plugin' => $input['plugin'] ?? null,
            ], JSON_UNESCAPED_SLASHES),
            'result_count' => $resultCount,
            'ip_address' => $request->ip(),
            'user_agent' => substr((string) $request->userAgent(), 0, 500),
            'created_at' => now(),
        ]);
    }
}
