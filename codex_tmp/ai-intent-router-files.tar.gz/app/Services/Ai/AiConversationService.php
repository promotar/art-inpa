<?php

namespace App\Services\Ai;

use App\Enums\AiIntent;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class AiConversationService
{
    /**
     * @param array<string, mixed> $metadata
     */
    public function resolveConversation(?User $user, ?int $conversationId, ?string $plugin, array $metadata = []): int
    {
        if (! Schema::hasTable('ai_conversations')) {
            return 0;
        }

        if ($conversationId && $this->canUseConversation($user, $conversationId)) {
            return $conversationId;
        }

        return (int) DB::table('ai_conversations')->insertGetId([
            'user_id' => $user?->id,
            'plugin' => $plugin,
            'title' => null,
            'metadata' => $metadata === [] ? null : json_encode($metadata, JSON_UNESCAPED_SLASHES),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    /**
     * @param array<int, mixed> $attachments
     * @param array<string, mixed> $metadata
     */
    public function storeMessage(int $conversationId, ?User $user, string $role, ?AiIntent $intent, ?string $content, array $attachments = [], array $metadata = []): void
    {
        if ($conversationId <= 0 || ! Schema::hasTable('ai_messages')) {
            return;
        }

        DB::table('ai_messages')->insert([
            'conversation_id' => $conversationId,
            'user_id' => $user?->id,
            'role' => $role,
            'intent' => $intent?->value,
            'content' => $content,
            'attachments' => $attachments === [] ? null : json_encode($attachments, JSON_UNESCAPED_SLASHES),
            'metadata' => $metadata === [] ? null : json_encode($metadata, JSON_UNESCAPED_SLASHES),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        DB::table('ai_conversations')->where('id', $conversationId)->update(['updated_at' => now()]);
    }

    private function canUseConversation(?User $user, int $conversationId): bool
    {
        $conversation = DB::table('ai_conversations')->where('id', $conversationId)->first(['user_id']);

        if (! $conversation) {
            return false;
        }

        if ($conversation->user_id === null) {
            return $user === null;
        }

        return $user !== null && (int) $conversation->user_id === (int) $user->id;
    }
}
