<?php

namespace App\Services\Ai;

use App\Data\AiIntentResult;
use App\Enums\AiIntent;
use Throwable;

class AiIntentRouter
{
    public function __construct(
        private readonly AiGatewayClient $gateway,
        private readonly AiPromptSanitizer $sanitizer,
        private readonly AiToolRegistry $tools,
    ) {
        //
    }

    /**
     * @param array<string, mixed> $input
     */
    public function route(array $input): AiIntentResult
    {
        $message = $this->sanitizer->sanitizeMessage((string) ($input['message'] ?? ''));
        $plugin = trim((string) ($input['plugin'] ?? ''));
        $action = trim((string) ($input['action'] ?? ''));
        $attachments = is_array($input['attachments'] ?? null) ? $input['attachments'] : [];
        $hasImage = $this->sanitizer->hasImage($attachments);

        if ($intent = $this->fromExplicitAction($action)) {
            return new AiIntentResult($intent, reason: 'explicit UI action');
        }

        if ($tool = $this->tools->toolForMessage($message)) {
            return new AiIntentResult(AiIntent::PlatformDataQuery, reason: 'platform data query keyword', tool: $tool);
        }

        if ($hasImage && $this->containsAny($message, $this->artworkSimilarityKeywords())) {
            return new AiIntentResult(AiIntent::ArtworkSimilarity, reason: 'image plus artwork similarity keyword');
        }

        if ($hasImage && ($message === '' || $this->containsAny($message, $this->visionKeywords()))) {
            return new AiIntentResult(AiIntent::VisionAnalyze, reason: 'uploaded image analysis');
        }

        if ($intent = $this->fromPluginContext($plugin, $message)) {
            return new AiIntentResult($intent, reason: 'plugin context');
        }

        if ($this->containsAny($message, $this->fastImageKeywords())) {
            return new AiIntentResult(AiIntent::FastGenerateImage, reason: 'fast image keyword');
        }

        if ($this->containsAny($message, $this->imageKeywords())) {
            return new AiIntentResult(AiIntent::GenerateImage, reason: 'image generation keyword');
        }

        if ($this->containsAny($message, $this->visionKeywords())) {
            return new AiIntentResult(AiIntent::VisionAnalyze, reason: 'vision keyword');
        }

        if ($this->containsAny($message, $this->artworkSimilarityKeywords())) {
            return new AiIntentResult(AiIntent::ArtworkSimilarity, reason: 'artwork similarity keyword');
        }

        if ($this->containsAny($message, $this->profileUpdateKeywords())) {
            return $this->profileUpdateResult($message);
        }

        if ($this->containsAny($message, $this->ragKeywords())) {
            return new AiIntentResult(AiIntent::RagQuestion, reason: 'knowledge keyword');
        }

        if ($this->containsAny($message, $this->codingKeywords())) {
            return new AiIntentResult(AiIntent::CodingAssistant, reason: 'coding keyword');
        }

        if ((bool) config('ai.fallback_classifier_enabled', true)) {
            return $this->fallbackClassify($message, $plugin, $input, $hasImage);
        }

        return new AiIntentResult(AiIntent::GeneralChat, reason: 'default general chat');
    }

    private function fromExplicitAction(string $action): ?AiIntent
    {
        return match ($action) {
            'generate_image' => AiIntent::GenerateImage,
            'fast_generate_image' => AiIntent::FastGenerateImage,
            'analyze_image' => AiIntent::VisionAnalyze,
            'search_artwork' => AiIntent::ArtworkSimilarity,
            'coding_assistant' => AiIntent::CodingAssistant,
            default => null,
        };
    }

    private function fromPluginContext(string $plugin, string $message): ?AiIntent
    {
        return match ($plugin) {
            'courses' => AiIntent::RagQuestion,
            'gallery' => $this->containsAny($message, $this->artworkSimilarityKeywords()) ? AiIntent::ArtworkSimilarity : AiIntent::VisionAnalyze,
            'page_builder' => AiIntent::GenerateImage,
            'admin_developer' => AiIntent::CodingAssistant,
            'store' => $this->containsAny($message, $this->ragKeywords()) ? AiIntent::RagQuestion : AiIntent::GeneralChat,
            default => null,
        };
    }

    private function fallbackClassify(string $message, string $plugin, array $input, bool $hasImage): AiIntentResult
    {
        try {
            $response = $this->gateway->classifyIntent([
                'message' => $message,
                'plugin' => $plugin,
                'context' => $input['context'] ?? [],
                'has_image' => $hasImage,
                'allowed_intents' => config('ai.enabled_intents', []),
            ]);
        } catch (Throwable) {
            return new AiIntentResult(AiIntent::GeneralChat, confidence: 0.5, reason: 'fallback classifier unavailable');
        }

        $data = is_array($response['data'] ?? null) ? $response['data'] : [];
        $confidence = (float) ($data['confidence'] ?? 0);
        $intent = AiIntent::tryFrom((string) ($data['intent'] ?? 'unknown')) ?? AiIntent::Unknown;

        if ($confidence < (float) config('ai.confidence_threshold', 0.75)) {
            return AiIntentResult::clarification('low fallback classifier confidence');
        }

        return new AiIntentResult(
            intent: $intent,
            confidence: $confidence,
            requiresConfirmation: (bool) ($data['requires_confirmation'] ?? $intent->isSensitive()),
            reason: (string) ($data['reason'] ?? 'fallback classifier'),
            data: is_array($data['data'] ?? null) ? $data['data'] : [],
            tool: isset($data['tool']) ? (string) $data['tool'] : null,
        );
    }

    private function profileUpdateResult(string $message): AiIntentResult
    {
        $field = str_contains($message, 'email') || str_contains($message, 'ايميل') || str_contains($message, 'الإيميل')
            ? 'email'
            : (str_contains($message, 'رقمي') || str_contains($message, 'phone') ? 'phone' : 'name');

        return new AiIntentResult(
            intent: AiIntent::UpdateProfile,
            requiresConfirmation: true,
            reason: 'profile update keyword',
            message: 'Please confirm updating your profile.',
            data: ['field' => $field],
        );
    }

    /**
     * @param array<int, string> $needles
     */
    private function containsAny(string $message, array $needles): bool
    {
        $message = mb_strtolower($message);

        foreach ($needles as $needle) {
            if (str_contains($message, mb_strtolower($needle))) {
                return true;
            }
        }

        return false;
    }

    private function imageKeywords(): array
    {
        return ['اعمل صورة', 'ولد صورة', 'صمم صورة', 'بوستر', 'اعلان', 'إعلان', 'poster', 'generate image', 'create image'];
    }

    private function fastImageKeywords(): array
    {
        return ['صورة سريعة', 'quick image', 'fast image', 'draft image'];
    }

    private function visionKeywords(): array
    {
        return ['حلل الصورة', 'شو في الصورة', 'قيّم اللوحة', 'قيم اللوحة', 'describe image', 'analyze image', 'ocr', 'اقرأ النص'];
    }

    private function artworkSimilarityKeywords(): array
    {
        return ['تشابه', 'منسوخة', 'أصلية', 'اصلية', 'فريدة', 'uniqueness', 'similar artwork', 'copied', 'plagiarism'];
    }

    private function profileUpdateKeywords(): array
    {
        return ['غير اسمي', 'عدل اسمي', 'غير رقمي', 'عدل الايميل', 'update my name', 'change my email'];
    }

    private function ragKeywords(): array
    {
        return ['سياسة', 'شروط', 'كورس', 'مقال', 'محتوى المنصة', 'knowledge base', 'policy', 'course', 'article'];
    }

    private function codingKeywords(): array
    {
        return ['كود', 'برمجة', 'laravel', 'php', 'plugin', 'migration', 'controller', 'code'];
    }
}
