<?php

namespace Modules\AiCore;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class AiAgentRuntimeDiagnosticCommand extends Command
{
    protected $signature = 'ai-core:agent-runtime-diagnostic
        {--plugin=ai-assistant : Plugin slug used for the diagnostic context}
        {--tool=general_chat : AI Core tool slug}
        {--model= : Override agent model for this diagnostic}
        {--timeout-ms= : Override model timeout in milliseconds}
        {--context-window=1 : Diagnostic context window}
        {--message=Hello from AI Core diagnostic. : Sample user message}
        {--conversation-id=diagnostic : Conversation id}
        {--user-id= : Optional user id}
        {--raw : Include raw response summaries in command output}
        {--compact : Use compact command output}';

    protected $description = 'Run a direct AI Core Agent Runtime diagnostic without production plugin chat.';

    public function handle(AiAgentRuntime $runtime): int
    {
        $plugin = (string) $this->option('plugin');
        $toolSlug = AiToolSlug::canonical((string) $this->option('tool'));
        $message = (string) $this->option('message');
        $user = $this->resolveUser();
        $result = $runtime->runProtocolDiagnostic($toolSlug, $message, $plugin, $user, [
            'model' => (string) $this->option('model'),
            'timeout_ms' => (string) $this->option('timeout-ms') === '' ? null : (int) $this->option('timeout-ms'),
            'context_window' => (int) $this->option('context-window'),
            'compact' => (bool) $this->option('compact'),
        ]);
        $run = $this->runRow((string) $result['run_id']);
        $step = $this->latestStep((string) $result['run_id']);

        $output = [
            'run_id' => $result['run_id'],
            'step_id' => $result['step_id'],
            'tool_slug' => $toolSlug,
            'plugin' => $plugin,
            'model' => $result['model'],
            'timeout_ms' => $result['timeout_ms'],
            'prompt_char_size' => $result['prompt_char_size'],
            'latency_ms' => $result['latency_ms'],
            'run_status' => $run->status ?? ($result['status'] ?? null),
            'stop_reason' => $run->stop_reason ?? ($result['stop_reason'] ?? null),
            'step_status' => $step->status ?? null,
            'validation_status' => $step->validation_status ?? null,
            'step_type' => $step->step_type ?? null,
            'parse_result' => $result['parse_result'],
            'validation_result' => $result['validation']['valid'] ?? false,
            'validation_errors' => $result['validation']['errors'] ?? [],
            'repair_attempted' => $result['repair_attempted'],
            'usage_deduction' => $result['usage_deduction'],
            'real_tool_execution' => $result['real_tool_execution'],
        ];

        if (! (bool) $this->option('compact')) {
            $output['agent_step'] = $result['agent_step'];
        }

        if ((bool) $this->option('raw')) {
            $output['raw_response_summary'] = $result['raw_response_summary'];
            $output['repair_response_summary'] = $result['repair_response_summary'];
        }

        $this->line(json_encode($output, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE));

        return self::SUCCESS;
    }

    private function resolveUser(): mixed
    {
        $userId = trim((string) $this->option('user-id'));
        if ($userId === '' || ! class_exists(\App\Models\User::class)) {
            return null;
        }

        return \App\Models\User::query()->find((int) $userId);
    }

    private function latestStep(string $runId): ?object
    {
        if (! Schema::hasTable('ai_core_agent_steps')) {
            return null;
        }

        return DB::table('ai_core_agent_steps')
            ->where('run_id', $runId)
            ->orderByDesc('id')
            ->first();
    }

    private function runRow(string $runId): ?object
    {
        if (! Schema::hasTable('ai_core_agent_runs')) {
            return null;
        }

        return DB::table('ai_core_agent_runs')
            ->where('run_id', $runId)
            ->first();
    }
}
