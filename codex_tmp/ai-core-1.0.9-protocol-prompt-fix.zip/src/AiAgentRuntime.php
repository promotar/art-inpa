<?php

namespace Modules\AiCore;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class AiAgentRuntime
{
    public function __construct(
        private readonly AiCoreSettings $settings,
        private readonly AiAgentRuntimeConfig $config,
        private readonly AiAgentContextBuilder $contextBuilder,
        private readonly AiAgentPromptBuilder $promptBuilder,
        private readonly AiAgentProtocolValidator $validator,
        private readonly AiToolBroker $broker,
        private readonly AiAgentMemoryManager $memory,
        private readonly AiAgentAuditLogger $audit,
        private readonly AiPermissionService $permissions,
    ) {
        //
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @param array<string, mixed> $decision
     * @return array<string, mixed>
     */
    public function runShadow(string $toolSlug, array $payload, array $context, ?Authenticatable $user, array $decision): array
    {
        return $this->run($toolSlug, $payload, $context, $user, $decision, 'shadow');
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @param array<string, mixed> $decision
     * @return array<string, mixed>
     */
    public function runActive(string $toolSlug, array $payload, array $context, ?Authenticatable $user, array $decision): array
    {
        return $this->run($toolSlug, $payload, $context, $user, $decision, 'active');
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function runProtocolDiagnostic(string $toolSlug, string $message, string $plugin, ?Authenticatable $user, array $options = []): array
    {
        $started = microtime(true);
        $toolSlug = AiToolSlug::canonical($toolSlug);
        $runId = (string) ($options['run_id'] ?? 'diagnostic-'.Str::uuid());
        $stepId = $runId.'-step-1';
        $model = trim((string) ($options['model'] ?? '')) ?: $this->config->agentModel(null);
        $timeoutMs = max(250, min(120000, (int) ($options['timeout_ms'] ?? $this->config->shadowTimeoutMs())));
        $contextWindow = max(1, min(30, (int) ($options['context_window'] ?? 1)));
        $availableTools = [$this->minimalTool($toolSlug)];
        $contextEnvelope = [
            'plugin' => $plugin,
            'run_id' => $runId,
            'diagnostic' => true,
            'user' => [
                'id' => $user?->getAuthIdentifier(),
                'roles' => $this->permissions->roles($user),
                'role' => implode(',', $this->permissions->roles($user)),
                'plan' => $options['plan'] ?? null,
            ],
            'available_tools' => $availableTools,
            'current_user_message' => mb_substr($message, 0, 1000),
            'recent_messages' => $contextWindow > 1 ? [['role' => 'user', 'content' => mb_substr($message, 0, 1000)]] : [],
            'runtime_policy' => [
                'diagnostic_only' => true,
                'do_not_call_real_tools' => true,
                'do_not_deduct_usage' => true,
            ],
        ];
        $payload = $this->promptBuilder->diagnosticPayload($model, $contextEnvelope);
        $promptCharSize = strlen(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE) ?: '');
        $contextHash = hash('sha256', json_encode($contextEnvelope, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE) ?: '{}');

        $this->audit->startRun($runId, $plugin, $toolSlug, 'diagnostic', $model, $contextHash, [
            'timeout_ms' => $timeoutMs,
            'prompt_char_size' => $promptCharSize,
            'context_window' => $contextWindow,
            'compact' => (bool) ($options['compact'] ?? true),
            'usage_deduction' => false,
            'real_tool_execution' => false,
        ], $user);

        $this->audit->startStep($runId, $stepId, 0, $plugin, $toolSlug, [
            'mode' => 'diagnostic',
            'model' => $model,
            'timeout_ms' => $timeoutMs,
            'prompt_char_size' => $promptCharSize,
            'status' => 'model_call_started',
        ], $user);

        $raw = null;
        $repairRaw = null;
        $decoded = null;
        $repairAttempted = false;

        try {
            $raw = $this->callAgentModel($payload, $timeoutMs);
            $decoded = $this->decodeJson($raw);

            if (! is_array($decoded)) {
                $repairAttempted = true;
                $repairPayload = $this->promptBuilder->diagnosticRepairPayload($model, $contextEnvelope, $raw);
                $repairRaw = $this->callAgentModel($repairPayload, $timeoutMs);
                $decoded = $this->decodeJson($repairRaw);
            }

            if (! is_array($decoded)) {
                $this->audit->failStep($runId, $stepId, 0, $plugin, $toolSlug, 'invalid_json', 'invalid_agent_protocol', [
                    'mode' => 'diagnostic',
                    'model' => $model,
                    'timeout_ms' => $timeoutMs,
                    'prompt_char_size' => $promptCharSize,
                    'raw_response_summary' => $this->summaryText($raw),
                    'repair_attempted' => $repairAttempted,
                    'repair_response_summary' => $this->summaryText($repairRaw),
                    'parse_result' => 'invalid_json',
                ], $user);
                $this->audit->finishRun($runId, $plugin, $toolSlug, 'failed', 1, 'invalid_agent_protocol', $this->durationMs($started), null, [
                    'mode' => 'diagnostic',
                    'model' => $model,
                    'timeout_ms' => $timeoutMs,
                    'prompt_char_size' => $promptCharSize,
                    'parse_result' => 'invalid_json',
                    'repair_attempted' => $repairAttempted,
                ], $user);

                return $this->diagnosticResult($runId, $stepId, $model, $timeoutMs, $promptCharSize, $started, 'failed', 'invalid_agent_protocol', null, null, $raw, $repairRaw, $repairAttempted);
            }

            $decoded['step_id'] = $stepId;
            $decoded['_agent_raw_response_summary'] = $this->summaryText($raw);
            $decoded['_agent_repair_attempts_used'] = $repairAttempted ? 1 : 0;
            $decoded['_agent_repair_response_summary'] = $this->summaryText($repairRaw);
            $decoded['_agent_prompt_char_size'] = $promptCharSize;
            $decoded['_agent_timeout_ms'] = $timeoutMs;

            $validation = $this->validator->validate($decoded, $availableTools);
            $step = $validation['step'];
            $requestedTool = $step['tool_slug'] ? (string) $step['tool_slug'] : null;
            $this->audit->logStep($runId, $stepId, 0, $plugin, $requestedTool, $step, $validation, $user);

            $status = $validation['valid'] ? 'protocol_valid' : 'failed';
            $stopReason = $validation['valid'] ? null : 'invalid_protocol:'.implode(',', $validation['errors']);
            $this->audit->finishRun($runId, $plugin, $toolSlug, $status, 1, $stopReason, $this->durationMs($started), $step['final_message'] ?? $step['clarification_message'] ?? null, [
                'mode' => 'diagnostic',
                'model' => $model,
                'timeout_ms' => $timeoutMs,
                'prompt_char_size' => $promptCharSize,
                'parse_result' => 'valid_json',
                'validation' => $validation,
                'repair_attempted' => $repairAttempted,
                'usage_deduction' => false,
                'real_tool_execution' => false,
            ], $user);

            return $this->diagnosticResult($runId, $stepId, $model, $timeoutMs, $promptCharSize, $started, $status, $stopReason, $step, $validation, $raw, $repairRaw, $repairAttempted);
        } catch (\Throwable $exception) {
            $reasonCode = $exception instanceof AiCoreException ? $exception->reasonCode() : $this->classifyFailure($exception);
            $this->audit->failStep($runId, $stepId, 0, $plugin, $toolSlug, $this->stepStatusForReason($reasonCode), $reasonCode, [
                'mode' => 'diagnostic',
                'model' => $model,
                'timeout_ms' => $timeoutMs,
                'prompt_char_size' => $promptCharSize,
                'raw_response_summary' => $this->summaryText($raw),
                'repair_attempted' => $repairAttempted,
                'repair_response_summary' => $this->summaryText($repairRaw),
            ], $user);
            $this->audit->finishRun($runId, $plugin, $toolSlug, 'failed', 1, $reasonCode, $this->durationMs($started), null, [
                'mode' => 'diagnostic',
                'model' => $model,
                'timeout_ms' => $timeoutMs,
                'prompt_char_size' => $promptCharSize,
                'error' => 'Protocol diagnostic failed safely.',
                'usage_deduction' => false,
                'real_tool_execution' => false,
            ], $user);

            return $this->diagnosticResult($runId, $stepId, $model, $timeoutMs, $promptCharSize, $started, 'failed', $reasonCode, null, null, $raw, $repairRaw, $repairAttempted);
        }
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @param array<string, mixed> $decision
     * @return array<string, mixed>
     */
    private function run(string $toolSlug, array $payload, array $context, ?Authenticatable $user, array $decision, string $mode): array
    {
        $started = microtime(true);
        $toolSlug = AiToolSlug::canonical($toolSlug);
        $plugin = (string) ($context['plugin'] ?? $context['plugin_slug'] ?? $payload['plugin'] ?? $decision['plugin_slug'] ?? 'unknown');
        $runId = (string) ($context['agent_run_id'] ?? Str::uuid());
        $binding = is_array($decision['binding'] ?? null) ? $decision['binding'] : null;
        $model = $this->config->agentModel($binding);
        $contextEnvelope = $this->contextBuilder->build($toolSlug, $payload, $context, $user, $runId);
        $contextHash = hash('sha256', json_encode($contextEnvelope, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE) ?: '{}');
        $this->audit->startRun($runId, $plugin, $toolSlug, $mode, $model, $contextHash, [
            'requested_mode' => $decision['requested_mode'] ?? $mode,
            'decision_reason' => $decision['reason'] ?? null,
            'shadow_non_blocking' => $mode === 'shadow',
        ], $user);

        $maxLoops = $mode === 'shadow' ? 1 : $this->config->maxToolLoops($binding);
        $loopCount = 0;
        $lastToolResult = null;
        $finalMessage = null;
        $clarificationMessage = null;
        $resultKind = 'none';
        $status = 'completed';
        $stopReason = null;
        $currentStepId = null;
        $currentStepLoopIndex = 0;
        $currentStepPending = false;

        try {
            for ($loop = 0; $loop < $maxLoops; $loop++) {
                $loopCount = $loop + 1;
                $stepId = $runId.'-step-'.($loop + 1);
                $currentStepId = $stepId;
                $currentStepLoopIndex = $loop;
                $currentStepPending = true;
                $this->audit->startStep($runId, $stepId, $loop, $plugin, $toolSlug, [
                    'mode' => $mode,
                    'model' => $model,
                    'timeout_ms' => $mode === 'shadow' ? $this->config->shadowTimeoutMs() : ($this->settings->timeout($toolSlug) * 1000),
                    'status' => 'model_call_started',
                ], $user);

                $step = $this->nextValidatedStep($model, $contextEnvelope, $lastToolResult, $toolSlug, $mode, $stepId);
                $validation = $this->validator->validate($step, (array) ($contextEnvelope['available_tools'] ?? []));
                $step = $validation['step'];
                $requestedTool = $step['tool_slug'] ? (string) $step['tool_slug'] : null;
                $this->audit->logStep($runId, $stepId, $loop, $plugin, $requestedTool, $step, $validation, $user);
                $currentStepPending = false;

                if (! $validation['valid']) {
                    $status = 'failed';
                    $stopReason = 'invalid_protocol:'.implode(',', $validation['errors']);
                    break;
                }

                $resultKind = (string) ($step['result_kind'] ?? 'none');

                if (in_array($step['step_type'], ['final_response', 'refusal'], true)) {
                    $finalMessage = (string) ($step['final_message'] ?? '');
                    $this->storeMemory($plugin, $contextEnvelope, $user, $step);
                    break;
                }

                if ($step['step_type'] === 'clarification') {
                    $clarificationMessage = (string) ($step['clarification_message'] ?? '');
                    $this->storeMemory($plugin, $contextEnvelope, $user, $step);
                    break;
                }

                if ($step['step_type'] === 'tool_result_evaluation') {
                    if ((string) ($step['status'] ?? '') === 'finish') {
                        $finalMessage = (string) ($step['final_message'] ?? '');
                        $this->storeMemory($plugin, $contextEnvelope, $user, $step);
                        break;
                    }

                    if ((string) ($step['status'] ?? '') === 'ask_user') {
                        $clarificationMessage = (string) ($step['clarification_message'] ?? '');
                        $this->storeMemory($plugin, $contextEnvelope, $user, $step);
                        break;
                    }

                    if (in_array((string) ($step['status'] ?? ''), ['blocked', 'failed'], true)) {
                        $status = 'failed';
                        $stopReason = (string) ($step['status'] ?? 'failed');
                        $finalMessage = (string) ($step['final_message'] ?? '');
                        $this->storeMemory($plugin, $contextEnvelope, $user, $step);
                        break;
                    }
                }

                if (! in_array($step['step_type'], ['tool_call', 'tool_result_evaluation'], true)) {
                    $status = 'failed';
                    $stopReason = 'unsupported_step_type';
                    break;
                }

                if ($mode === 'shadow') {
                    $stopReason = 'shadow_tool_call_not_executed';
                    break;
                }

                $toolArguments = (array) ($step['tool_arguments'] ?? []);
                $lastToolResult = $this->broker->execute($runId, $stepId, (string) $requestedTool, $toolArguments, array_merge($context, [
                    'plugin' => $plugin,
                    'agent_runtime_mode' => $mode,
                ]), $user);

                $contextEnvelope['previous_tool_calls'][] = [
                    'step_id' => $stepId,
                    'tool_slug' => $requestedTool,
                    'arguments_summary' => $this->summary($toolArguments),
                ];
                $contextEnvelope['previous_tool_results'][] = $lastToolResult;

                if (in_array((string) ($lastToolResult['status'] ?? ''), ['job_created', 'job_polling'], true)) {
                    $finalMessage = (string) ($step['final_message'] ?? '');
                    $stopReason = 'async_tool_result_preserved_for_existing_polling';
                    break;
                }

                if (! $this->config->toolResultFollowupEnabled()) {
                    $finalMessage = (string) ($step['final_message'] ?? '');
                    $stopReason = 'tool_result_followup_disabled';
                    break;
                }
            }

            if ($loopCount >= $maxLoops && $finalMessage === null && $clarificationMessage === null && $stopReason === null) {
                $status = 'failed';
                $stopReason = 'max_tool_loops_reached';
            }

            $this->audit->finishRun($runId, $plugin, $toolSlug, $status, $loopCount, $stopReason, $this->durationMs($started), $finalMessage ?? $clarificationMessage, [
                'last_tool_result_status' => $lastToolResult['status'] ?? null,
                'mode' => $mode,
            ], $user);

            return [
                'run_id' => $runId,
                'mode' => $mode,
                'status' => $status,
                'stop_reason' => $stopReason,
                'loop_count' => $loopCount,
                'result_kind' => $resultKind,
                'final_message' => $finalMessage,
                'clarification_message' => $clarificationMessage,
                'last_tool_result' => $lastToolResult,
            ];
        } catch (\Throwable $exception) {
            $reasonCode = $exception instanceof AiCoreException ? $exception->reasonCode() : $this->classifyFailure($exception);
            if ($currentStepPending && $currentStepId !== null) {
                $this->audit->failStep($runId, $currentStepId, $currentStepLoopIndex, $plugin, $toolSlug, $this->stepStatusForReason($reasonCode), $reasonCode, [
                    'mode' => $mode,
                    'error' => 'Agent Runtime model call failed safely.',
                    'stable_runtime_unaffected' => $mode === 'shadow',
                ], $user);
            }

            $this->audit->finishRun($runId, $plugin, $toolSlug, 'failed', $loopCount, $reasonCode, $this->durationMs($started), null, [
                'mode' => $mode,
                'error' => 'Agent Runtime failed safely.',
            ], $user);

            throw $exception;
        }
    }

    /**
     * @param array<string, mixed> $contextEnvelope
     * @param array<string, mixed>|null $toolResult
     * @return array<string, mixed>
     */
    private function nextValidatedStep(string $model, array $contextEnvelope, ?array $toolResult, string $toolSlug, string $mode, string $stepId): array
    {
        $timeoutMs = $mode === 'shadow' ? $this->config->shadowTimeoutMs() : ($this->settings->timeout($toolSlug) * 1000);
        $raw = $this->callAgentModel($this->promptBuilder->payload($model, $contextEnvelope, $toolResult), $timeoutMs);
        $decoded = $this->decodeJson($raw);

        $attempts = $this->config->repairAttempts();
        $repairAttemptsUsed = 0;
        while (! is_array($decoded) && $attempts > 0) {
            $attempts--;
            $repairAttemptsUsed++;
            $raw = $this->callAgentModel($this->promptBuilder->payload(
                $model,
                $contextEnvelope,
                $toolResult,
                $this->promptBuilder->repairPrompt($raw)
            ), $timeoutMs);
            $decoded = $this->decodeJson($raw);
        }

        if (! is_array($decoded)) {
            throw new AiCoreException('invalid_agent_protocol', 'AI Core Agent Runtime returned invalid protocol JSON.');
        }

        $decoded['step_id'] = $stepId;
        $decoded['_agent_raw_response_summary'] = mb_substr($raw, 0, 1200);
        $decoded['_agent_repair_attempts_used'] = $repairAttemptsUsed;

        return $decoded;
    }

    /**
     * @param array<string, mixed> $payload
     */
    private function callAgentModel(array $payload, int $timeoutMs): string
    {
        $baseUrl = $this->settings->gatewayBaseUrl();
        if ($baseUrl === '') {
            throw new AiCoreException('gateway_unreachable', 'AI Core Gateway base URL is not configured.');
        }

        $timeoutSeconds = max(0.25, $timeoutMs / 1000);
        $request = Http::timeout($timeoutSeconds)
            ->acceptJson()
            ->when($this->settings->gatewayApiKey() !== '', fn ($http) => $http->withHeaders([
                'X-AI-API-KEY' => $this->settings->gatewayApiKey(),
            ]));

        $response = $request->post($baseUrl.'/v1/general/chat', $payload);
        if (! $response->successful()) {
            throw new AiCoreException('backend_unavailable', 'AI Core Agent Runtime model request failed.');
        }

        $json = $response->json();
        if (is_array($json)) {
            foreach ([
                data_get($json, 'data.message'),
                data_get($json, 'data.content'),
                data_get($json, 'data.response'),
                data_get($json, 'message'),
                data_get($json, 'content'),
                data_get($json, 'response'),
            ] as $candidate) {
                if (is_string($candidate) && trim($candidate) !== '') {
                    return $candidate;
                }
            }

            return json_encode($json, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE) ?: '';
        }

        return $response->body();
    }

    /**
     * @return array<string, mixed>|null
     */
    private function decodeJson(string $raw): ?array
    {
        $raw = trim($raw);
        if ($raw === '') {
            return null;
        }

        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            return $decoded;
        }

        $start = strpos($raw, '{');
        $end = strrpos($raw, '}');
        if ($start !== false && $end !== false && $end > $start) {
            $decoded = json_decode(substr($raw, $start, $end - $start + 1), true);

            return is_array($decoded) ? $decoded : null;
        }

        return null;
    }

    /**
     * @param array<string, mixed> $contextEnvelope
     * @param array<string, mixed> $step
     */
    private function storeMemory(string $plugin, array $contextEnvelope, ?Authenticatable $user, array $step): void
    {
        $conversationId = (string) ($contextEnvelope['conversation_id'] ?? '');
        $summary = is_string($step['memory_summary_update'] ?? null) ? (string) $step['memory_summary_update'] : null;
        $this->memory->update($plugin, $conversationId, $user, $summary, [
            'run_id' => $contextEnvelope['run_id'] ?? null,
            'decision_summary' => $step['decision_summary'] ?? '',
        ]);
    }

    /**
     * @param array<string, mixed> $payload
     */
    private function summary(array $payload): string
    {
        return mb_substr(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE) ?: '{}', 0, 500);
    }

    private function durationMs(float $started): int
    {
        return (int) round((microtime(true) - $started) * 1000);
    }

    /**
     * @return array<string, mixed>
     */
    private function minimalTool(string $toolSlug): array
    {
        $toolSlug = AiToolSlug::canonical($toolSlug);

        return [
            'slug' => $toolSlug,
            'risk_level' => in_array($toolSlug, ['coding_chat', 'training_job_create', 'rag_index', 'artwork_index'], true) ? 'high' : 'low',
            'requires_approval' => false,
            'audit_required' => true,
            'expected_usage_category' => $this->usageCategoryFor($toolSlug),
        ];
    }

    private function usageCategoryFor(string $toolSlug): string
    {
        return match (AiToolSlug::canonical($toolSlug)) {
            'general_chat', 'intent_classify' => 'text_chat',
            'coding_chat' => 'coding_chat',
            'image_generate' => 'image_generate',
            'image_fast_generate' => 'image_fast_generate',
            'vision_analyze' => 'vision_analyze',
            'rag_search', 'rag_index', 'text_embed' => 'rag_search',
            default => 'none',
        };
    }

    /**
     * @param array<string, mixed>|null $step
     * @param array<string, mixed>|null $validation
     * @return array<string, mixed>
     */
    private function diagnosticResult(
        string $runId,
        string $stepId,
        string $model,
        int $timeoutMs,
        int $promptCharSize,
        float $started,
        string $status,
        ?string $stopReason,
        ?array $step,
        ?array $validation,
        ?string $raw,
        ?string $repairRaw,
        bool $repairAttempted,
    ): array {
        return [
            'run_id' => $runId,
            'step_id' => $stepId,
            'model' => $model,
            'timeout_ms' => $timeoutMs,
            'prompt_char_size' => $promptCharSize,
            'latency_ms' => $this->durationMs($started),
            'status' => $status,
            'stop_reason' => $stopReason,
            'parse_result' => is_array($step) ? 'valid_json' : 'invalid_json',
            'validation' => $validation,
            'agent_step' => $step,
            'raw_response_summary' => $this->summaryText($raw),
            'repair_attempted' => $repairAttempted,
            'repair_response_summary' => $this->summaryText($repairRaw),
            'usage_deduction' => false,
            'real_tool_execution' => false,
        ];
    }

    private function summaryText(?string $value): ?string
    {
        if ($value === null || trim($value) === '') {
            return null;
        }

        return mb_substr(trim($value), 0, 1200);
    }

    private function classifyFailure(\Throwable $exception): string
    {
        $message = strtolower($exception->getMessage());
        if (str_contains($message, 'timeout') || str_contains($message, 'timed out') || str_contains($message, 'curl error 28')) {
            return 'timeout';
        }

        return 'agent_runtime_failed';
    }

    private function stepStatusForReason(string $reasonCode): string
    {
        return match ($reasonCode) {
            'timeout' => 'timeout',
            'invalid_agent_protocol' => 'invalid_json',
            default => 'failed',
        };
    }
}
