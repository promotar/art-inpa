<?php

namespace Modules\AiCore;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class AiAgentAuditLogger
{
    public function __construct(private readonly AiAuditLogger $audit)
    {
        //
    }

    /**
     * @param array<string, mixed> $metadata
     */
    public function startRun(string $runId, string $pluginSlug, string $toolSlug, string $mode, string $model, string $contextHash, array $metadata, ?Authenticatable $user): ?int
    {
        $auditId = $this->audit->event('agent_runtime.run_started', [
            'plugin' => $pluginSlug,
            'run_id' => $runId,
            'root_tool_slug' => $toolSlug,
            'mode' => $mode,
            'model' => $model,
            'context_hash' => $contextHash,
            'metadata' => $metadata,
        ], $user, $toolSlug, true);

        if (Schema::hasTable('ai_core_agent_runs')) {
            DB::table('ai_core_agent_runs')->updateOrInsert(
                ['run_id' => $runId],
                [
                    'ai_core_audit_log_id' => $auditId,
                    'user_id' => $user?->getAuthIdentifier(),
                    'plugin_slug' => $pluginSlug,
                    'root_tool_slug' => $toolSlug,
                    'mode' => $mode,
                    'agent_model' => $model,
                    'status' => 'started',
                    'context_hash' => $contextHash,
                    'metadata' => $this->json($metadata),
                    'started_at' => now(),
                    'updated_at' => now(),
                    'created_at' => now(),
                ]
            );
        }

        return $auditId;
    }

    /**
     * @param array<string, mixed> $step
     * @param array<string, mixed> $validation
     */
    public function startStep(string $runId, string $stepId, int $loopIndex, string $pluginSlug, string $toolSlug, array $metadata, ?Authenticatable $user): ?int
    {
        $auditId = $this->audit->event('agent_runtime.step_started', [
            'plugin' => $pluginSlug,
            'run_id' => $runId,
            'step_id' => $stepId,
            'loop_index' => $loopIndex,
            'root_tool_slug' => $toolSlug,
            'metadata' => $metadata,
        ], $user, $toolSlug, true);

        if (Schema::hasTable('ai_core_agent_steps')) {
            DB::table('ai_core_agent_steps')->updateOrInsert(
                ['step_id' => $stepId],
                [
                    'run_id' => $runId,
                    'ai_core_audit_log_id' => $auditId,
                    'loop_index' => $loopIndex,
                    'step_type' => 'model_call',
                    'status' => 'model_call_started',
                    'tool_slug' => null,
                    'validation_status' => 'pending',
                    'agent_step_json' => $this->json([
                        'step_id' => $stepId,
                        'status' => 'model_call_started',
                    ]),
                    'metadata' => $this->json($metadata),
                    'updated_at' => now(),
                    'created_at' => now(),
                ]
            );
        }

        return $auditId;
    }

    /**
     * @param array<string, mixed> $step
     * @param array<string, mixed> $validation
     */
    public function logStep(string $runId, string $stepId, int $loopIndex, string $pluginSlug, ?string $toolSlug, array $step, array $validation, ?Authenticatable $user): ?int
    {
        $auditId = $this->audit->event('agent_runtime.step', [
            'plugin' => $pluginSlug,
            'run_id' => $runId,
            'step_id' => $stepId,
            'loop_index' => $loopIndex,
            'agent_step' => $step,
            'validation' => $validation,
        ], $user, $toolSlug, (bool) ($validation['valid'] ?? false), $validation['reason'] ?? null);

        if (Schema::hasTable('ai_core_agent_steps')) {
            DB::table('ai_core_agent_steps')->updateOrInsert(
                ['step_id' => $stepId],
                [
                    'run_id' => $runId,
                    'ai_core_audit_log_id' => $auditId,
                    'loop_index' => $loopIndex,
                    'step_type' => $step['step_type'] ?? null,
                    'status' => $step['status'] ?? null,
                    'tool_slug' => $toolSlug,
                    'validation_status' => (bool) ($validation['valid'] ?? false) ? 'valid' : 'invalid',
                    'agent_step_json' => $this->json($step),
                    'metadata' => $this->json(['validation' => $validation]),
                    'updated_at' => now(),
                    'created_at' => now(),
                ]
            );
        }

        return $auditId;
    }

    /**
     * @param array<string, mixed> $metadata
     */
    public function failStep(string $runId, string $stepId, int $loopIndex, string $pluginSlug, string $toolSlug, string $status, string $reason, array $metadata, ?Authenticatable $user): ?int
    {
        $auditId = $this->audit->event('agent_runtime.step_failed', [
            'plugin' => $pluginSlug,
            'run_id' => $runId,
            'step_id' => $stepId,
            'loop_index' => $loopIndex,
            'root_tool_slug' => $toolSlug,
            'status' => $status,
            'reason' => $reason,
            'metadata' => $metadata,
        ], $user, $toolSlug, false, $reason);

        if (Schema::hasTable('ai_core_agent_steps')) {
            DB::table('ai_core_agent_steps')->updateOrInsert(
                ['step_id' => $stepId],
                [
                    'run_id' => $runId,
                    'ai_core_audit_log_id' => $auditId,
                    'loop_index' => $loopIndex,
                    'step_type' => 'model_call',
                    'status' => $status,
                    'tool_slug' => null,
                    'validation_status' => 'failed',
                    'agent_step_json' => $this->json([
                        'step_id' => $stepId,
                        'status' => $status,
                        'reason' => $reason,
                    ]),
                    'metadata' => $this->json($metadata),
                    'updated_at' => now(),
                    'created_at' => now(),
                ]
            );
        }

        return $auditId;
    }

    /**
     * @param array<string, mixed> $metadata
     */
    public function shadowFailure(string $pluginSlug, string $toolSlug, string $reason, array $metadata, ?Authenticatable $user): void
    {
        $this->audit->event('agent_runtime.shadow_failed_non_blocking', [
            'plugin' => $pluginSlug,
            'tool_slug' => $toolSlug,
            'reason' => $reason,
            'metadata' => $metadata,
            'stable_runtime_unaffected' => true,
        ], $user, $toolSlug, false, $reason);
    }

    /**
     * @param array<string, mixed> $metadata
     */
    public function finishRun(string $runId, string $pluginSlug, string $toolSlug, string $status, int $loopCount, ?string $stopReason, int $latencyMs, ?string $finalMessage, array $metadata, ?Authenticatable $user): void
    {
        $this->audit->event('agent_runtime.run_finished', [
            'plugin' => $pluginSlug,
            'run_id' => $runId,
            'root_tool_slug' => $toolSlug,
            'status' => $status,
            'loop_count' => $loopCount,
            'stop_reason' => $stopReason,
            'latency_ms' => $latencyMs,
            'final_message_summary' => $finalMessage ? mb_substr($finalMessage, 0, 500) : null,
            'metadata' => $metadata,
        ], $user, $toolSlug, in_array($status, ['completed', 'protocol_valid'], true), $stopReason);

        if (Schema::hasTable('ai_core_agent_runs')) {
            DB::table('ai_core_agent_runs')
                ->where('run_id', $runId)
                ->update([
                    'status' => $status,
                    'loop_count' => $loopCount,
                    'stop_reason' => $stopReason,
                    'latency_ms' => $latencyMs,
                    'final_message_summary' => $finalMessage ? mb_substr($finalMessage, 0, 1000) : null,
                    'metadata' => $this->json($metadata),
                    'finished_at' => now(),
                    'updated_at' => now(),
                ]);
        }
    }

    /**
     * @param array<string, mixed> $payload
     */
    private function json(array $payload): string
    {
        return json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE) ?: '{}';
    }
}
