<?php

use Illuminate\Support\Facades\Route;
use Modules\AiCore\AiCoreAdminController;

Route::get('/', [AiCoreAdminController::class, 'index'])->name('index');
Route::post('/settings', [AiCoreAdminController::class, 'updateSettings'])->name('settings.update');
Route::post('/agent-bindings', [AiCoreAdminController::class, 'updateAgentBindings'])->name('agent-bindings.update');
Route::post('/sync', [AiCoreAdminController::class, 'syncFromServer'])->name('sync');
Route::post('/usage-limits', [AiCoreAdminController::class, 'updateUsageLimits'])->name('usage-limits.update');
Route::post('/datasets/{dataset}/index', [AiCoreAdminController::class, 'indexDataset'])->name('datasets.index');
Route::post('/datasets/{dataset}/reindex', [AiCoreAdminController::class, 'reindexDataset'])->name('datasets.reindex');
Route::post('/datasets/{dataset}/clear', [AiCoreAdminController::class, 'clearDatasetIndex'])->name('datasets.clear');
