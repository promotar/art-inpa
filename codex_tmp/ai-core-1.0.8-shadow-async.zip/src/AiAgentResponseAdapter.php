<?php

namespace Modules\AiCore;

class AiAgentResponseAdapter
{
    /**
     * @param array<string, mixed> $runResult
     * @return array<string, mixed>
     */
    public function toLegacyResponse(string $toolSlug, array $runResult): array
    {
        $lastToolResult = is_array($runResult['last_tool_result'] ?? null) ? $runResult['last_tool_result'] : null;
        if ($lastToolResult && is_array($lastToolResult['result_data'] ?? null) && $this->toolResponseShouldWin($toolSlug)) {
            return $lastToolResult['result_data'];
        }

        $message = (string) ($runResult['final_message'] ?? $runResult['clarification_message'] ?? '');
        if ($message === '') {
            $message = 'AI Core agent runtime completed.';
        }

        return [
            'ok' => ($runResult['status'] ?? '') === 'completed',
            'data' => [
                'message' => $message,
                'agent_runtime' => [
                    'run_id' => $runResult['run_id'] ?? null,
                    'mode' => $runResult['mode'] ?? null,
                    'loop_count' => $runResult['loop_count'] ?? 0,
                    'result_kind' => $runResult['result_kind'] ?? 'text',
                ],
            ],
            'message' => $message,
        ];
    }

    private function toolResponseShouldWin(string $toolSlug): bool
    {
        return in_array(AiToolSlug::canonical($toolSlug), [
            'image_generate',
            'image_fast_generate',
            'image_job_poll',
            'vision_analyze',
            'rag_search',
            'artwork_search',
            'coding_chat',
            'training_job_create',
            'training_job_status',
            'training_job_poll',
        ], true);
    }
}
