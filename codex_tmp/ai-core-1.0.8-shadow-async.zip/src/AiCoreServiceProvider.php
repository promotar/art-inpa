<?php

namespace Modules\AiCore;

use Illuminate\Support\Facades\Route;
use Illuminate\Support\ServiceProvider;

class AiCoreServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        foreach (glob(__DIR__.'/*.php') ?: [] as $file) {
            if ($file !== __FILE__) {
                require_once $file;
            }
        }

        $this->app->singleton(AiCoreSettings::class);
        $this->app->singleton(AiModelRegistry::class);
        $this->app->singleton(AiToolRegistry::class);
        $this->app->singleton(AiPermissionService::class);
        $this->app->singleton(AiUsageLimiter::class);
        $this->app->singleton(AiAuditLogger::class);
        $this->app->singleton(AiToolReadinessService::class);
        $this->app->singleton(AiImagePromptNormalizer::class);
        $this->app->singleton(AiPolicyPackProvider::class);
        $this->app->singleton(AiPlanValidator::class);
        $this->app->singleton(AiSemanticPlanner::class);
        $this->app->singleton(AiToolExecutionContractRegistry::class);
        $this->app->singleton(AiToolExecutionGate::class);
        $this->app->singleton(AiAgentRuntimeConfig::class);
        $this->app->singleton(AiAgentContextBuilder::class);
        $this->app->singleton(AiAgentPromptBuilder::class);
        $this->app->singleton(AiAgentProtocolValidator::class);
        $this->app->singleton(AiAgentMemoryManager::class);
        $this->app->singleton(AiAgentAuditLogger::class);
        $this->app->singleton(AiAgentResponseAdapter::class);
        $this->app->singleton(AiToolBroker::class);
        $this->app->singleton(AiAgentRuntime::class);
        $this->app->singleton(AiCore::class);
        $this->app->singleton(AiGatewayClient::class);
        $this->app->singleton(AiIntentRouter::class);
        $this->app->singleton(AiConversationBridge::class);
        $this->app->singleton(AiRagService::class);
        $this->app->singleton(AiImageJobService::class);
        $this->app->singleton(AiVisionService::class);
        $this->app->singleton(AiArtworkSimilarityService::class);
        $this->app->singleton(AiTrainingProfileService::class);
    }

    public function boot(): void
    {
        $this->loadMigrationsFrom(__DIR__.'/../database/migrations');
        $this->loadViewsFrom(__DIR__.'/../resources/views', 'ai-core');

        $routeFile = __DIR__.'/../routes/admin.php';
        if (is_file($routeFile)) {
            Route::middleware(['web', 'auth', 'staff'])
                ->prefix('admin/plugins/ai-core')
                ->name('admin.plugins.ai-core.')
                ->group($routeFile);
        }

        if ($this->app->runningInConsole()) {
            $this->commands([
                AiAgentRuntimeDiagnosticCommand::class,
            ]);
        }
    }
}
