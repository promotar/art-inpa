<?php

namespace Modules\AiCore;

use Illuminate\Contracts\Auth\Authenticatable;

class AiToolExecutionGate
{
    public function __construct(
        private readonly AiToolRegistry $tools,
        private readonly AiToolExecutionContractRegistry $contracts,
        private readonly AiCoreSettings $settings,
    ) {
        //
    }

    /**
     * @param array<string, mixed> $tool
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @param array<string, mixed>|null $plannerPlan
     * @return array{allowed: bool, payload: array<string, mixed>, context: array<string, mixed>, audit: array<string, mixed>, clarification_question: string|null, reason_blocked: string|null}
     */
    public function validate(string $toolSlug, array $tool, array $payload, array $context, ?array $plannerPlan, ?Authenticatable $user = null): array
    {
        $toolSlug = AiToolSlug::canonical($toolSlug);
        $contract = $this->contracts->forTool($toolSlug);
        $missing = [];
        $reason = null;
        $clarification = null;
        $finalAction = 'execute_tool';
        $finalPayload = $payload;
        $finalContext = $context;

        if (! $this->tools->find($toolSlug) || ! (bool) ($tool['enabled'] ?? false)) {
            $missing[] = 'enabled_tool';
            $reason = 'tool_disabled';
            $finalAction = 'refuse';
        }

        if ($reason === null && (string) ($contract['expected_result_type'] ?? '') === '') {
            $missing[] = 'expected_result_type';
            $reason = 'unknown_expected_result_type';
            $finalAction = 'refuse';
        }

        $plannerAction = $plannerPlan['action'] ?? null;
        if ($reason === null && is_string($plannerAction) && in_array($plannerAction, ['answer_user', 'ask_clarification', 'plugin_action', 'refuse'], true)) {
            if (in_array($toolSlug, ['image_generate', 'image_fast_generate', 'vision_analyze', 'artwork_search'], true)) {
                $reason = 'planner_recommends_non_tool_action';
                $finalAction = $plannerAction === 'refuse' ? 'refuse' : 'ask_clarification';
                $missing[] = 'semantic_execute_tool_action';
                $clarification = $this->clarificationFor($toolSlug);
            }
        }

        if ($reason === null && in_array($toolSlug, ['image_generate', 'image_fast_generate'], true)) {
            $image = $this->validateImageContract($toolSlug, $finalPayload, $finalContext, $plannerPlan);
            $finalPayload = $image['payload'];
            $finalContext = $image['context'];
            $missing = array_merge($missing, $image['missing']);
            $reason = $image['reason'];
            $clarification = $image['clarification'];
            $finalAction = $reason === null ? 'execute_tool' : 'ask_clarification';
        }

        if ($reason === null) {
            foreach ((array) ($contract['required_input_fields'] ?? []) as $field) {
                if (! array_key_exists($field, $finalPayload) || $finalPayload[$field] === null || $finalPayload[$field] === '') {
                    $missing[] = $field;
                }
            }

            if ($missing !== []) {
                $reason = 'missing_required_input';
                $finalAction = (bool) ($contract['clarification_required_on_missing_data'] ?? false) ? 'ask_clarification' : 'refuse';
                $clarification = $this->clarificationFor($toolSlug);
            }
        }

        $allowed = $reason === null;
        $audit = [
            'original_user_message' => $this->originalUserMessage($payload, $context),
            'selected_tool_before_gate' => $toolSlug,
            'planner_recommended_tool' => $plannerPlan['recommended_tool'] ?? null,
            'contract_validation_result' => $allowed ? 'passed' : 'blocked',
            'contract' => [
                'minimum_semantic_completeness' => $contract['minimum_semantic_completeness'] ?? null,
                'expected_result_type' => $contract['expected_result_type'] ?? null,
                'vague_requests_allowed' => $contract['vague_requests_allowed'] ?? null,
                'previous_context_may_be_reused' => $contract['previous_context_may_be_reused'] ?? null,
            ],
            'missing_requirements' => array_values(array_unique($missing)),
            'clarification_question' => $clarification,
            'final_action' => $finalAction,
            'final_tool' => $allowed ? $toolSlug : null,
            'compiled_prompt_en' => $allowed ? ($finalPayload['prompt'] ?? $finalContext['final_prompt'] ?? null) : null,
            'reason_blocked' => $reason,
            'runtime_unchanged' => true,
        ];

        return [
            'allowed' => $allowed,
            'payload' => $finalPayload,
            'context' => $finalContext,
            'audit' => $audit,
            'clarification_question' => $clarification,
            'reason_blocked' => $reason,
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @param array<string, mixed>|null $plannerPlan
     * @return array{payload: array<string, mixed>, context: array<string, mixed>, missing: array<int, string>, reason: string|null, clarification: string|null}
     */
    private function validateImageContract(string $toolSlug, array $payload, array $context, ?array $plannerPlan): array
    {
        $missing = [];
        $reason = null;
        $clarification = null;
        $original = $this->originalUserMessage($payload, $context);
        $compiledPrompt = (string) ($payload['prompt'] ?? $context['final_prompt'] ?? '');
        $previousPrompt = $this->previousImagePrompt($context);
        $isCorrection = (bool) ($plannerPlan['is_correction_or_dissatisfaction'] ?? false);

        if ($isCorrection) {
            if ($previousPrompt === '') {
                return [
                    'payload' => $payload,
                    'context' => $context,
                    'missing' => ['previous_image_context'],
                    'reason' => 'correction_without_previous_context',
                    'clarification' => 'Which previous image should I fix, and what exactly should change?',
                ];
            }

            $plannerPrompt = is_string($plannerPlan['compiled_prompt_en'] ?? null) ? (string) $plannerPlan['compiled_prompt_en'] : '';
            if ($this->isSafeCompiledImagePrompt($plannerPrompt)) {
                $compiledPrompt = $plannerPrompt;
            } elseif ($this->isSafeCompiledImagePrompt($previousPrompt)) {
                $compiledPrompt = $previousPrompt.'. Apply this requested correction: '.mb_substr($original, 0, 500);
            }

            $payload['prompt'] = $compiledPrompt;
            $context['final_prompt'] = $compiledPrompt;
            $context['normalized_prompt'] = $compiledPrompt;
            $context['image_prompt']['final_prompt'] = $compiledPrompt;
            $context['image_prompt']['normalized_prompt'] = $compiledPrompt;
            $context['image_prompt']['reused_previous_context'] = true;
        }

        if (! $this->isSafeCompiledImagePrompt($compiledPrompt)) {
            $missing[] = 'concrete_visual_brief';
            $reason = 'insufficient_visual_brief';
            $clarification = 'What should be in the image? Please include the subject or scene and any important setting, style, or mood.';
        }

        $confidence = $plannerPlan['tool_confidence'] ?? null;
        $threshold = (float) ($this->settings->values()['planner_confidence_threshold'] ?? 0.70);
        if ($reason === null && is_numeric($confidence) && (float) $confidence < $threshold && ($plannerPlan['recommended_tool'] ?? $toolSlug) !== $toolSlug) {
            $missing[] = 'semantic_confidence';
            $reason = 'low_semantic_confidence';
            $clarification = $this->clarificationFor($toolSlug);
        }

        return [
            'payload' => $payload,
            'context' => $context,
            'missing' => $missing,
            'reason' => $reason,
            'clarification' => $clarification,
        ];
    }

    private function isSafeCompiledImagePrompt(string $prompt): bool
    {
        $prompt = trim($prompt);
        if ($prompt === '') {
            return false;
        }

        $withoutQuality = trim(str_ireplace([
            'realistic',
            'cinematic lighting',
            'high detail',
            'high quality',
        ], '', $prompt), " \t\n\r\0\x0B,.");

        if ($withoutQuality === '' || mb_strlen($withoutQuality) < 12) {
            return false;
        }

        if (preg_match('/\p{Arabic}/u', $withoutQuality) === 1) {
            return false;
        }

        $tokens = preg_split('/\s+/u', preg_replace('/[^\pL\pN]+/u', ' ', $withoutQuality) ?: '') ?: [];
        $tokens = array_values(array_filter($tokens, fn (string $token): bool => mb_strlen($token) >= 3));

        return count($tokens) >= 3;
    }

    /**
     * @param array<string, mixed> $context
     */
    private function previousImagePrompt(array $context): string
    {
        foreach ([
            'previous_execution_summary.prompt',
            'previous_execution_summary.final_prompt',
            'previous_execution_summary.normalized_prompt',
            'latest_visual_context.prompt',
            'latest_visual_context.final_prompt',
            'latest_visual_context.normalized_prompt',
            'visual_context.prompt',
            'image_prompt.previous_prompt',
        ] as $path) {
            $value = data_get($context, $path);
            if (is_string($value) && trim($value) !== '') {
                return trim($value);
            }
        }

        return '';
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     */
    private function originalUserMessage(array $payload, array $context): string
    {
        foreach (['original_prompt', 'message', 'user_text', 'text', 'input', 'prompt', 'content'] as $key) {
            $value = $context[$key] ?? $payload[$key] ?? null;
            if (is_string($value) && trim($value) !== '') {
                return mb_substr(trim($value), 0, 1200);
            }
        }

        return '';
    }

    private function clarificationFor(string $toolSlug): string
    {
        return match (AiToolSlug::canonical($toolSlug)) {
            'image_generate', 'image_fast_generate' => 'What should be in the image? Please include the subject or scene and any important setting, style, or mood.',
            'vision_analyze' => 'Please attach or select the image you want me to analyze.',
            'artwork_search' => 'Please provide the artwork image or reference you want me to compare.',
            default => 'Please clarify what you want me to do.',
        };
    }
}
