<?php

namespace Modules\AiCore;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\Http;

class AiSemanticPlanner
{
    public function __construct(
        private readonly AiCoreSettings $settings,
        private readonly AiPolicyPackProvider $policyPacks,
        private readonly AiPlanValidator $validator,
        private readonly AiAuditLogger $audit,
    ) {
        //
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @return array<string, mixed>|null
     */
    public function plan(string $selectedToolSlug, array $payload, array $context = [], ?Authenticatable $user = null): ?array
    {
        if (! $this->enabled()) {
            return null;
        }

        $started = microtime(true);
        $plugin = (string) ($context['plugin'] ?? $context['plugin_slug'] ?? $payload['plugin'] ?? 'unknown');
        $plannerInput = $this->plannerInput($selectedToolSlug, $payload, $context, $user, $plugin);

        try {
            $raw = $this->callPlanner($plannerInput, $selectedToolSlug);
            $decoded = $this->decodePlannerJson($raw);

            if (! is_array($decoded)) {
                $plan = $this->validator->fallbackPlan('Planner returned invalid JSON. Runtime execution used the existing AI Core flow.');
                $this->audit->event('semantic_planner.invalid_json', [
                    'plugin' => $plugin,
                    'selected_tool' => $selectedToolSlug,
                    'planner_model' => $this->plannerModel(),
                    'shadow_mode' => $this->shadowMode(),
                    'duration_ms' => $this->durationMs($started),
                    'decision_summary' => $plan['decision_summary'],
                ], $user, $selectedToolSlug, false, 'invalid_planner_json');

                return $plan + ['status' => 'invalid_json'];
            }

            $plan = $this->validator->validate($decoded, $this->policyPacks->availableToolSlugs());
            $this->audit->event('semantic_planner.shadow', [
                'plugin' => $plugin,
                'selected_tool' => $selectedToolSlug,
                'planner_model' => $this->plannerModel(),
                'shadow_mode' => $this->shadowMode(),
                'duration_ms' => $this->durationMs($started),
                'plan' => $plan,
                'decision_summary' => $plan['decision_summary'],
                'recommended_tool' => $plan['recommended_tool'],
                'tool_confidence' => $plan['tool_confidence'],
                'runtime_unchanged' => true,
            ], $user, $selectedToolSlug, true);

            return $plan + ['status' => 'ok'];
        } catch (\Throwable $exception) {
            $plan = $this->validator->fallbackPlan('Planner failed safely. Runtime execution used the existing AI Core flow.');
            $this->audit->event('semantic_planner.failed', [
                'plugin' => $plugin,
                'selected_tool' => $selectedToolSlug,
                'planner_model' => $this->plannerModel(),
                'shadow_mode' => $this->shadowMode(),
                'duration_ms' => $this->durationMs($started),
                'error' => 'Semantic planner failed safely.',
                'decision_summary' => $plan['decision_summary'],
            ], $user, $selectedToolSlug, false, 'planner_failed');

            return $plan + ['status' => 'failed'];
        }
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    private function plannerInput(string $selectedToolSlug, array $payload, array $context, ?Authenticatable $user, string $plugin): array
    {
        return [
            'current_user_message' => $this->currentUserMessage($payload, $context),
            'recent_conversation_context' => $this->recentConversationContext($payload, $context),
            'plugin_name' => $plugin,
            'user_role_plan_summary' => $this->userRolePlanSummary($user, $context),
            'available_tools' => $this->policyPacks->availableTools(),
            'previous_execution_summary' => $this->previousExecutionSummary($context),
            'attachment_visual_context_metadata' => $this->attachmentVisualContext($payload, $context),
            'policy_pack' => $this->policyPacks->build(),
            'runtime_selected_tool' => $selectedToolSlug,
            'shadow_mode' => true,
        ];
    }

    /**
     * @param array<string, mixed> $plannerInput
     */
    private function callPlanner(array $plannerInput, string $toolSlug): string
    {
        $baseUrl = $this->settings->gatewayBaseUrl();
        if ($baseUrl === '') {
            throw new AiCoreException('gateway_unreachable', 'AI Core Gateway base URL is not configured.');
        }

        $system = implode("\n", [
            'You are the Art INPA AI Core Semantic Planner.',
            'Analyze the request semantically. Do not use keyword matching.',
            'You advise only. You must not decide runtime execution.',
            'Do not reveal chain-of-thought. Store only concise decision_summary.',
            'Return strict JSON only using the requested schema.',
        ]);

        $payload = [
            'model' => $this->plannerModel(),
            'system' => $system,
            'message' => 'Return the semantic plan JSON for this AI Core request.',
            'context' => $plannerInput,
            'temperature' => 0.1,
            'max_tokens' => 700,
            'response_format' => ['type' => 'json_object'],
        ];

        $request = Http::timeout($this->settings->timeout($toolSlug))
            ->retry(1, 200)
            ->acceptJson()
            ->when($this->settings->gatewayApiKey() !== '', fn ($http) => $http->withHeaders([
                'X-AI-API-KEY' => $this->settings->gatewayApiKey(),
            ]));

        $response = $request->post($baseUrl.'/v1/general/chat', $payload);
        if (! $response->successful()) {
            throw new AiCoreException('backend_unavailable', 'Semantic planner request failed.');
        }

        $json = $response->json();
        if (is_array($json)) {
            foreach ([
                data_get($json, 'data.message'),
                data_get($json, 'data.content'),
                data_get($json, 'data.response'),
                data_get($json, 'message'),
                data_get($json, 'content'),
                data_get($json, 'response'),
            ] as $candidate) {
                if (is_string($candidate) && trim($candidate) !== '') {
                    return $candidate;
                }
            }

            return json_encode($json, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE) ?: '';
        }

        return $response->body();
    }

    /**
     * @return array<string, mixed>|null
     */
    private function decodePlannerJson(string $raw): ?array
    {
        $raw = trim($raw);
        if ($raw === '') {
            return null;
        }

        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            return $decoded;
        }

        if (preg_match('/\{(?:[^{}]|(?R))*\}/s', $raw, $matches) === 1) {
            $decoded = json_decode($matches[0], true);

            return is_array($decoded) ? $decoded : null;
        }

        return null;
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     */
    private function currentUserMessage(array $payload, array $context): string
    {
        foreach (['message', 'prompt', 'user_text', 'text', 'input', 'content'] as $key) {
            $value = $payload[$key] ?? $context[$key] ?? null;
            if (is_string($value) && trim($value) !== '') {
                return mb_substr(trim($value), 0, 4000);
            }
        }

        return '';
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @return array<int, mixed>
     */
    private function recentConversationContext(array $payload, array $context): array
    {
        $window = max(1, min(20, (int) ($this->settings->values()['planner_context_window'] ?? 8)));
        foreach (['recent_messages', 'history', 'messages', 'conversation'] as $key) {
            $value = $context[$key] ?? $payload[$key] ?? null;
            if (is_array($value)) {
                return array_slice($this->sanitizeList($value), -$window);
            }
        }

        return [];
    }

    /**
     * @return array<string, mixed>
     */
    private function userRolePlanSummary(?Authenticatable $user, array $context): array
    {
        $roles = [];
        if ($user && method_exists($user, 'getRoleNames')) {
            $roles = $user->getRoleNames()->values()->all();
        } elseif ($user && method_exists($user, 'roles')) {
            $roles = $user->roles()->pluck('name')->all();
        }

        return [
            'authenticated' => $user !== null,
            'user_id' => $user?->getAuthIdentifier(),
            'roles' => array_values(array_filter(array_map('strval', $roles))),
            'plan' => $context['plan'] ?? $context['plan_slug'] ?? $context['subscription_plan'] ?? null,
        ];
    }

    /**
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    private function previousExecutionSummary(array $context): array
    {
        $summary = $context['previous_execution_summary'] ?? $context['last_execution_summary'] ?? $context['latest_tool_result'] ?? [];

        return is_array($summary) ? $this->sanitizeMap($summary, 30) : [];
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    private function attachmentVisualContext(array $payload, array $context): array
    {
        $metadata = [
            'attachments' => $payload['attachments'] ?? $context['attachments'] ?? [],
            'visual_context' => $context['visual_context'] ?? $context['latest_visual_context'] ?? null,
        ];

        return $this->sanitizeMap($metadata, 30);
    }

    /**
     * @param array<int|string, mixed> $items
     * @return array<int, mixed>
     */
    private function sanitizeList(array $items): array
    {
        return collect($items)
            ->take(20)
            ->map(fn (mixed $item): mixed => is_array($item) ? $this->sanitizeMap($item, 20) : $this->excerpt($item))
            ->values()
            ->all();
    }

    /**
     * @param array<int|string, mixed> $map
     * @return array<string, mixed>
     */
    private function sanitizeMap(array $map, int $limit): array
    {
        $safe = [];
        foreach (array_slice($map, 0, $limit, true) as $key => $value) {
            $key = mb_substr((string) $key, 0, 80);
            if ($key === '') {
                continue;
            }

            $lower = strtolower($key);
            if (str_contains($lower, 'api_key') || str_contains($lower, 'token') || str_contains($lower, 'password') || str_contains($lower, 'secret')) {
                $safe[$key] = '[redacted]';
            } elseif (is_array($value)) {
                $safe[$key] = $this->sanitizeMap($value, 20);
            } else {
                $safe[$key] = $this->excerpt($value);
            }
        }

        return $safe;
    }

    private function enabled(): bool
    {
        return (bool) ($this->settings->values()['planner_enabled'] ?? false);
    }

    private function shadowMode(): bool
    {
        return (bool) ($this->settings->values()['planner_shadow_mode'] ?? true);
    }

    private function plannerModel(): string
    {
        return (string) ($this->settings->values()['planner_model'] ?? 'qwen3:8b');
    }

    private function durationMs(float $started): int
    {
        return (int) round((microtime(true) - $started) * 1000);
    }

    private function excerpt(mixed $value): string
    {
        if (! is_scalar($value)) {
            return '';
        }

        return mb_substr(trim((string) $value), 0, 1200);
    }
}
