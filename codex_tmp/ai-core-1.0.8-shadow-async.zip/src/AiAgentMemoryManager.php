<?php

namespace Modules\AiCore;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class AiAgentMemoryManager
{
    public function __construct(private readonly AiAgentRuntimeConfig $config)
    {
        //
    }

    public function summary(string $pluginSlug, string $conversationId, ?Authenticatable $user): string
    {
        if (! $this->config->memorySummaryEnabled() || ! Schema::hasTable('ai_core_agent_memories') || $conversationId === '') {
            return '';
        }

        $row = DB::table('ai_core_agent_memories')
            ->where('plugin_slug', $pluginSlug)
            ->where('conversation_id', $conversationId)
            ->when($user, fn ($query) => $query->where('user_id', $user->getAuthIdentifier()))
            ->when(! $user, fn ($query) => $query->whereNull('user_id'))
            ->first();

        return is_string($row->memory_summary ?? null) ? (string) $row->memory_summary : '';
    }

    /**
     * @param array<string, mixed> $metadata
     */
    public function update(string $pluginSlug, string $conversationId, ?Authenticatable $user, ?string $summary, array $metadata = []): void
    {
        if (! $this->config->memorySummaryEnabled() || ! Schema::hasTable('ai_core_agent_memories') || $conversationId === '') {
            return;
        }

        $summary = trim((string) $summary);
        if ($summary === '') {
            return;
        }

        DB::table('ai_core_agent_memories')->updateOrInsert(
            [
                'user_id' => $user?->getAuthIdentifier(),
                'plugin_slug' => $pluginSlug,
                'conversation_id' => $conversationId,
            ],
            [
                'memory_summary' => mb_substr($summary, 0, 8000),
                'metadata' => json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                'updated_at' => now(),
                'created_at' => now(),
            ]
        );
    }
}
