<?php

namespace Modules\AiCore;

use RuntimeException;

class AiCoreException extends RuntimeException
{
    public function __construct(
        private readonly string $reasonCode,
        string $message,
        int $code = 0,
        ?\Throwable $previous = null,
    ) {
        parent::__construct($this->formatMessage($reasonCode, $message), $code, $previous);
    }

    public function reasonCode(): string
    {
        return $this->reasonCode;
    }

    private function formatMessage(string $reasonCode, string $message): string
    {
        return 'AI Core error ['.$reasonCode.']: '.$message;
    }
}
