<?php

namespace Modules\AiCore;

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Throwable;

class AiCoreSettings
{
    /**
     * @return array<string, mixed>
     */
    public function values(): array
    {
        return Cache::remember('ai_core.settings.values', 300, function (): array {
            if (! Schema::hasTable('ai_core_settings')) {
                return [];
            }

            $values = [];
            $rows = DB::table('ai_core_settings')->where('status', 'active')->get(['key', 'value', 'type']);
            foreach ($rows as $row) {
                $values[(string) $row->key] = $this->cast((string) $row->value, (string) $row->type);
            }

            return $values;
        });
    }

    /**
     * @return array<string, mixed>
     */
    public function publicValues(): array
    {
        $values = $this->values();
        if (array_key_exists('gateway_api_key', $values)) {
            $values['gateway_api_key'] = filled((string) $values['gateway_api_key']) ? 'configured' : 'missing';
        }

        return $values;
    }

    public function gatewayBaseUrl(): string
    {
        return rtrim((string) ($this->values()['gateway_base_url'] ?? ''), '/');
    }

    public function gatewayApiKey(): string
    {
        return (string) ($this->values()['gateway_api_key'] ?? '');
    }

    public function timeout(?string $toolSlug = null): int
    {
        $values = $this->values();
        if ($toolSlug !== null && (str_contains($toolSlug, 'image') || in_array($toolSlug, ['vision_analyze', 'artwork_search'], true))) {
            return max(20, (int) ($values['image_timeout'] ?? 300));
        }

        return max(10, (int) ($values['default_timeout'] ?? 60));
    }

    /**
     * @param  array<string, mixed>  $input
     */
    public function update(array $input, ?int $changedBy = null, string $source = 'admin.plugins.ai-core.settings'): void
    {
        if (! Schema::hasTable('ai_core_settings')) {
            return;
        }

        $changed = false;

        DB::table('ai_core_settings')
            ->where('editable', true)
            ->where('status', 'active')
            ->orderBy('id')
            ->get()
            ->each(function (object $setting) use ($input, $changedBy, $source, &$changed): void {
                $key = (string) $setting->key;

                if (! array_key_exists($key, $input)) {
                    return;
                }

                $raw = $input[$key];
                if ((bool) ($setting->sensitive_flag ?? false) && trim((string) $raw) === '') {
                    return;
                }

                $newValue = $this->normalizeInputValue($raw, (string) $setting->type);
                $oldValue = $setting->value;

                if ((string) $oldValue === (string) $newValue) {
                    return;
                }

                DB::table('ai_core_settings')
                    ->where('id', $setting->id)
                    ->update([
                        'value' => $newValue,
                        'updated_at' => now(),
                    ]);

                $this->recordSettingChange($setting, $oldValue, $newValue, $changedBy, $source);
                $changed = true;
            });

        if ($changed) {
            $this->clearSettingsCaches();
        }
    }

    private function cast(string $value, string $type): mixed
    {
        return match ($type) {
            'boolean' => in_array(strtolower($value), ['1', 'true', 'yes', 'on'], true),
            'integer' => (int) $value,
            'decimal', 'float' => (float) $value,
            'json' => json_decode($value, true) ?: [],
            default => $value,
        };
    }

    private function normalizeInputValue(mixed $value, string $type): string
    {
        return match ($type) {
            'boolean' => in_array((string) $value, ['1', 'true', 'yes', 'on'], true) || $value === true ? '1' : '0',
            'integer' => (string) (int) $value,
            'decimal', 'float' => (string) (float) $value,
            'json' => is_string($value) ? $value : json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            default => is_string($value) ? trim($value) : (string) $value,
        };
    }

    private function recordSettingChange(object $setting, mixed $oldValue, mixed $newValue, ?int $changedBy, string $source): void
    {
        if (! Schema::hasTable('operation_logs')) {
            return;
        }

        $isSensitive = (bool) ($setting->sensitive_flag ?? false);
        $timestamp = now();

        DB::table('operation_logs')->insert([
            'operation_type' => 'ai-core.setting.update',
            'target_type' => 'ai-core-setting',
            'target_slug' => 'ai_core.'.$setting->key,
            'status' => 'success',
            'message' => 'AI Core setting updated.',
            'context' => json_encode([
                'key' => 'ai_core.'.$setting->key,
                'old_value' => $isSensitive ? '[sensitive]' : $oldValue,
                'new_value' => $isSensitive ? '[sensitive]' : $newValue,
                'changed_by' => $changedBy,
                'timestamp' => $timestamp->toDateTimeString(),
                'source' => $source,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'started_at' => $timestamp,
            'finished_at' => $timestamp,
            'created_by' => $changedBy,
            'created_at' => $timestamp,
            'updated_at' => $timestamp,
        ]);
    }

    private function clearSettingsCaches(): void
    {
        Cache::forget('ai_core.settings.values');

        foreach (['cache:clear', 'view:clear'] as $command) {
            try {
                Artisan::call($command);
            } catch (Throwable) {
                // Cache clearing should not block a committed database setting update.
            }
        }
    }
}
