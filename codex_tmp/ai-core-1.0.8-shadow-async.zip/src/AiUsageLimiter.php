<?php

namespace Modules\AiCore;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class AiUsageLimiter
{
    private const ROLE_PRIORITY = [
        'super-admin' => 1000,
        'admin' => 900,
        'developer' => 850,
        'staff' => 800,
        'employee' => 700,
        'user-elite' => 600,
        'user-pro' => 550,
        'user-plus' => 500,
        'user-basic' => 450,
        'user' => 100,
        'guest' => 10,
    ];

    public function __construct(private readonly AiPermissionService $permissions)
    {
        //
    }

    public function canUse(string $toolSlug, ?Authenticatable $user = null, array $context = []): bool
    {
        return $this->decision($toolSlug, $user, $context)['allowed'];
    }

    /**
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function decision(string $toolSlug, ?Authenticatable $user = null, array $context = []): array
    {
        if (! Schema::hasTable('ai_core_usage_limits') || ! Schema::hasTable('ai_core_requests')) {
            return $this->decisionPayload(true, AiToolSlug::canonical($toolSlug), null, null, null, [], 0, null, 0, null, 0, 'usage_tables_missing_fallback_allowed');
        }

        $toolSlug = AiToolSlug::canonical($toolSlug);
        $pluginSlug = $this->permissions->normalizeIdentifier((string) ($context['plugin'] ?? $context['plugin_slug'] ?? '')) ?? '';
        $roles = $context['role'] ?? $this->permissions->roles($user);
        $roles = is_array($roles) ? $roles : [(string) $roles];
        $roles = $this->permissions->normalizeIdentifiers($roles);
        $planSlug = $this->permissions->normalizeIdentifier((string) ($context['plan'] ?? $context['plan_slug'] ?? '')) ?? '';
        $aliases = AiToolSlug::aliasesFor($toolSlug);

        $limits = DB::table('ai_core_usage_limits')
            ->where('tool_slug', $toolSlug)
            ->where(function ($query) use ($pluginSlug): void {
                $query->whereNull('plugin_slug')->orWhere('plugin_slug', $pluginSlug);
            })
            ->where(function ($query) use ($roles): void {
                $query->whereNull('role_slug')->orWhereIn('role_slug', $roles);
            })
            ->when(Schema::hasColumn('ai_core_usage_limits', 'plan_slug'), function ($query) use ($planSlug): void {
                $query->where(function ($nested) use ($planSlug): void {
                    $nested->whereNull('plan_slug');
                    if ($planSlug !== '') {
                        $nested->orWhere('plan_slug', $planSlug);
                    }
                });
            })
            ->where('enabled', true)
            ->get();

        $limit = $this->selectMostSpecificLimit($limits, $roles, $planSlug, $pluginSlug);

        if (! $limit) {
            return $this->decisionPayload(true, $toolSlug, null, null, $planSlug !== '' ? $planSlug : null, $roles, 0, null, 0, null, 0, 'no_matching_limit');
        }

        $selectedRole = $limit->role_slug ? (string) $limit->role_slug : null;
        $selectedPlan = Schema::hasColumn('ai_core_usage_limits', 'plan_slug') && $limit->plan_slug ? (string) $limit->plan_slug : null;
        if (Schema::hasColumn('ai_core_usage_limits', 'cooldown_seconds') && (int) ($limit->cooldown_seconds ?? 0) > 0) {
            $lastRequest = DB::table('ai_core_requests')
                ->whereIn('tool_slug', $aliases)
                ->when($user, fn ($query) => $query->where('user_id', $user->getAuthIdentifier()))
                ->when(! $user, fn ($query) => $query->whereNull('user_id'))
                ->latest('created_at')
                ->first();

            $secondsSinceLastRequest = $lastRequest ? now()->diffInSeconds($lastRequest->created_at) : null;
            if ($lastRequest && $secondsSinceLastRequest < (int) $limit->cooldown_seconds) {
                return $this->decisionPayload(false, $toolSlug, (int) $limit->id, $selectedRole, $selectedPlan, $roles, 0, $limit->daily_limit ? (int) $limit->daily_limit : null, 0, $limit->monthly_limit ? (int) $limit->monthly_limit : null, (int) $limit->cooldown_seconds, 'cooldown_active', $secondsSinceLastRequest);
            }
        }

        $dailyCount = 0;
        if ($limit->daily_limit !== null) {
            $dailyCount = DB::table('ai_core_requests')
                ->whereIn('tool_slug', $aliases)
                ->when($user, fn ($query) => $query->where('user_id', $user->getAuthIdentifier()))
                ->when(! $user, fn ($query) => $query->whereNull('user_id'))
                ->where('created_at', '>=', now()->startOfDay())
                ->count();

            if ($dailyCount >= (int) $limit->daily_limit) {
                return $this->decisionPayload(false, $toolSlug, (int) $limit->id, $selectedRole, $selectedPlan, $roles, $dailyCount, (int) $limit->daily_limit, 0, $limit->monthly_limit !== null ? (int) $limit->monthly_limit : null, (int) ($limit->cooldown_seconds ?? 0), 'daily_limit_exceeded');
            }
        }

        $monthlyCount = 0;
        if (Schema::hasColumn('ai_core_usage_limits', 'monthly_limit') && $limit->monthly_limit !== null) {
            $monthlyCount = DB::table('ai_core_requests')
                ->whereIn('tool_slug', $aliases)
                ->when($user, fn ($query) => $query->where('user_id', $user->getAuthIdentifier()))
                ->when(! $user, fn ($query) => $query->whereNull('user_id'))
                ->where('created_at', '>=', now()->startOfMonth())
                ->count();

            if ($monthlyCount >= (int) $limit->monthly_limit) {
                return $this->decisionPayload(false, $toolSlug, (int) $limit->id, $selectedRole, $selectedPlan, $roles, $dailyCount, $limit->daily_limit ? (int) $limit->daily_limit : null, $monthlyCount, (int) $limit->monthly_limit, (int) ($limit->cooldown_seconds ?? 0), 'monthly_limit_exceeded');
            }
        }

        return $this->decisionPayload(true, $toolSlug, (int) $limit->id, $selectedRole, $selectedPlan, $roles, $dailyCount, $limit->daily_limit !== null ? (int) $limit->daily_limit : null, $monthlyCount, $limit->monthly_limit !== null ? (int) $limit->monthly_limit : null, (int) ($limit->cooldown_seconds ?? 0), 'allowed_by_selected_limit');
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function editableLimits(array $filters = []): array
    {
        if (! Schema::hasTable('ai_core_usage_limits')) {
            return [];
        }

        $this->normalizeStoredIdentifiers();

        $role = $this->permissions->normalizeIdentifier((string) ($filters['role_slug'] ?? '')) ?? '';
        $plan = $this->permissions->normalizeIdentifier((string) ($filters['plan_slug'] ?? '')) ?? '';
        $tool = trim((string) ($filters['tool_slug'] ?? ''));
        $tool = $tool !== '' ? AiToolSlug::canonical($tool) : '';

        return DB::table('ai_core_usage_limits')
            ->when($role !== '', fn ($query) => $query->where('role_slug', $role))
            ->when($plan !== '', fn ($query) => $query->where('plan_slug', $plan))
            ->when($tool !== '', fn ($query) => $query->where('tool_slug', $tool))
            ->orderBy('role_slug')
            ->orderBy('tool_slug')
            ->get()
            ->map(fn (object $row): array => (array) $row)
            ->all();
    }

    /**
     * @param array<int, array<string, mixed>> $limits
     */
    public function updateLimits(array $limits): void
    {
        if (! Schema::hasTable('ai_core_usage_limits')) {
            return;
        }

        foreach ($limits as $id => $input) {
            if (! is_numeric($id)) {
                continue;
            }

            DB::table('ai_core_usage_limits')
                ->where('id', (int) $id)
                ->update([
                    'daily_limit' => $this->nullableInt($input['daily_limit'] ?? null),
                    'monthly_limit' => Schema::hasColumn('ai_core_usage_limits', 'monthly_limit') ? $this->nullableInt($input['monthly_limit'] ?? null) : null,
                    'cooldown_seconds' => Schema::hasColumn('ai_core_usage_limits', 'cooldown_seconds') ? max(0, (int) ($input['cooldown_seconds'] ?? 0)) : 0,
                    'enabled' => in_array((string) ($input['enabled'] ?? '0'), ['1', 'true', 'on'], true),
                    'updated_at' => now(),
                ]);
        }
    }

    private function nullableInt(mixed $value): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }

        return max(0, (int) $value);
    }

    private function normalizeStoredIdentifiers(): void
    {
        $columns = array_values(array_filter([
            Schema::hasColumn('ai_core_usage_limits', 'role_slug') ? 'role_slug' : null,
            Schema::hasColumn('ai_core_usage_limits', 'plan_slug') ? 'plan_slug' : null,
            Schema::hasColumn('ai_core_usage_limits', 'plugin_slug') ? 'plugin_slug' : null,
        ]));

        if ($columns === []) {
            return;
        }

        DB::table('ai_core_usage_limits')
            ->select(array_merge(['id', 'tool_slug'], $columns))
            ->orderBy('id')
            ->get()
            ->each(function (object $row) use ($columns): void {
                $updates = [];

                $canonicalTool = AiToolSlug::canonical((string) ($row->tool_slug ?? ''));
                if ($canonicalTool !== (string) ($row->tool_slug ?? '')) {
                    $updates['tool_slug'] = $canonicalTool;
                }

                foreach ($columns as $column) {
                    $current = $row->{$column} ?? null;
                    if ($current === null || $current === '') {
                        continue;
                    }

                    $normalized = $this->permissions->normalizeIdentifier((string) $current);
                    if ($normalized !== null && $normalized !== $current) {
                        $updates[$column] = $normalized;
                    }
                }

                if ($updates !== []) {
                    $updates['updated_at'] = now();
                    DB::table('ai_core_usage_limits')->where('id', $row->id)->update($updates);
                }
            });
    }

    /**
     * @param \Illuminate\Support\Collection<int, object> $limits
     * @param array<int, string> $roles
     */
    private function selectMostSpecificLimit(\Illuminate\Support\Collection $limits, array $roles, string $planSlug, string $pluginSlug): ?object
    {
        return $limits
            ->sortByDesc(function (object $row) use ($roles, $planSlug, $pluginSlug): int {
                $role = $row->role_slug ? (string) $row->role_slug : null;
                $plan = property_exists($row, 'plan_slug') && $row->plan_slug ? (string) $row->plan_slug : null;
                $plugin = $row->plugin_slug ? (string) $row->plugin_slug : null;

                $score = 0;
                if ($role !== null && in_array($role, $roles, true)) {
                    $score += 100000 + (self::ROLE_PRIORITY[$role] ?? 100);
                }
                if ($role === null) {
                    $score += 1000;
                }
                if ($planSlug !== '' && $plan === $planSlug) {
                    $score += 20000;
                }
                if ($plan === null) {
                    $score += 500;
                }
                if ($pluginSlug !== '' && $plugin === $pluginSlug) {
                    $score += 10000;
                }
                if ($plugin === null) {
                    $score += 250;
                }

                return $score;
            })
            ->first();
    }

    /**
     * @param array<int, string> $roles
     * @return array<string, mixed>
     */
    private function decisionPayload(
        bool $allowed,
        string $tool,
        ?int $selectedLimitId,
        ?string $role,
        ?string $plan,
        array $roles,
        int $usedToday,
        ?int $dailyLimit,
        int $usedMonth,
        ?int $monthlyLimit,
        int $cooldownSeconds,
        string $reason,
        ?int $secondsSinceLastRequest = null,
    ): array {
        return [
            'allowed' => $allowed,
            'tool' => $tool,
            'selected_limit_id' => $selectedLimitId,
            'role' => $role,
            'roles' => $roles,
            'plan' => $plan,
            'used_today' => $usedToday,
            'daily_limit' => $dailyLimit,
            'used_month' => $usedMonth,
            'monthly_limit' => $monthlyLimit,
            'cooldown_seconds' => $cooldownSeconds,
            'seconds_since_last_request' => $secondsSinceLastRequest,
            'reason' => $reason,
        ];
    }
}
