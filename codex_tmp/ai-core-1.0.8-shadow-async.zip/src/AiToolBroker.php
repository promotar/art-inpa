<?php

namespace Modules\AiCore;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class AiToolBroker
{
    /**
     * @param array<string, mixed> $arguments
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function execute(string $runId, string $stepId, string $toolSlug, array $arguments, array $context, ?Authenticatable $user): array
    {
        $toolSlug = AiToolSlug::canonical($toolSlug);
        $argumentsHash = $this->hash($arguments);
        $idempotencyKey = hash('sha256', $runId.'|'.$stepId.'|'.$toolSlug.'|'.$argumentsHash);

        $existing = $this->existingResult($idempotencyKey);
        if ($existing !== null) {
            return $existing;
        }

        $this->markToolStarted($runId, $stepId, $toolSlug, $idempotencyKey, $argumentsHash);

        $toolContext = array_merge($context, [
            'agent_runtime_bypass' => true,
            'agent_run_id' => $runId,
            'agent_step_id' => $stepId,
            'agent_idempotency_key' => $idempotencyKey,
        ]);

        try {
            /** @var AiGatewayClient $gateway */
            $gateway = app(AiGatewayClient::class);
            $response = $gateway->executeStableTool($toolSlug, $arguments, $toolContext, $user);
            $toolResult = [
                'tool_slug' => $toolSlug,
                'status' => $this->resultStatus($toolSlug, $response),
                'result_kind' => $this->resultKind($toolSlug),
                'result_summary' => $this->summary($response),
                'result_data' => $response,
                'error_code' => null,
                'error_message' => null,
            ];

            $this->markToolFinished($stepId, $idempotencyKey, $toolResult, $this->latestLinkedRequestId($runId, $stepId, $toolSlug, $user));

            return $toolResult;
        } catch (\Throwable $exception) {
            $toolResult = [
                'tool_slug' => $toolSlug,
                'status' => $exception instanceof AiCoreException ? 'blocked' : 'failed',
                'result_kind' => $this->resultKind($toolSlug),
                'result_summary' => $exception instanceof AiCoreException ? $exception->reasonCode() : 'tool_execution_failed',
                'result_data' => [],
                'error_code' => $exception instanceof AiCoreException ? $exception->reasonCode() : 'tool_execution_failed',
                'error_message' => $exception instanceof AiCoreException ? $exception->getMessage() : 'AI Core tool execution failed.',
            ];

            $this->markToolFinished($stepId, $idempotencyKey, $toolResult, $this->latestLinkedRequestId($runId, $stepId, $toolSlug, $user));

            return $toolResult;
        }
    }

    /**
     * @return array<string, mixed>|null
     */
    private function existingResult(string $idempotencyKey): ?array
    {
        if (! Schema::hasTable('ai_core_agent_steps')) {
            return null;
        }

        $row = DB::table('ai_core_agent_steps')
            ->where('tool_idempotency_key', $idempotencyKey)
            ->whereNotNull('tool_result_payload')
            ->first();

        if (! $row || ! is_string($row->tool_result_payload ?? null)) {
            return null;
        }

        $decoded = json_decode((string) $row->tool_result_payload, true);

        return is_array($decoded) ? $decoded : null;
    }

    private function markToolStarted(string $runId, string $stepId, string $toolSlug, string $idempotencyKey, string $argumentsHash): void
    {
        if (! Schema::hasTable('ai_core_agent_steps')) {
            return;
        }

        DB::table('ai_core_agent_steps')->updateOrInsert(
            ['step_id' => $stepId],
            [
                'run_id' => $runId,
                'tool_slug' => $toolSlug,
                'tool_idempotency_key' => $idempotencyKey,
                'tool_arguments_hash' => $argumentsHash,
                'tool_result_status' => 'started',
                'updated_at' => now(),
                'created_at' => now(),
            ]
        );
    }

    /**
     * @param array<string, mixed> $toolResult
     */
    private function markToolFinished(string $stepId, string $idempotencyKey, array $toolResult, ?int $requestId): void
    {
        if (! Schema::hasTable('ai_core_agent_steps')) {
            return;
        }

        DB::table('ai_core_agent_steps')
            ->where('step_id', $stepId)
            ->orWhere('tool_idempotency_key', $idempotencyKey)
            ->update([
                'ai_core_request_id' => $requestId,
                'tool_result_status' => $toolResult['status'] ?? null,
                'tool_result_payload' => json_encode($toolResult, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE),
                'updated_at' => now(),
            ]);
    }

    private function latestLinkedRequestId(string $runId, string $stepId, string $toolSlug, ?Authenticatable $user): ?int
    {
        if (! Schema::hasTable('ai_core_requests')) {
            return null;
        }

        $query = DB::table('ai_core_requests')
            ->where('tool_slug', $toolSlug)
            ->when($user, fn ($query) => $query->where('user_id', $user->getAuthIdentifier()))
            ->latest('id')
            ->limit(5);

        foreach ($query->get() as $row) {
            $context = is_string($row->context ?? null) ? (string) $row->context : '';
            if (str_contains($context, $runId) && str_contains($context, $stepId)) {
                return (int) $row->id;
            }
        }

        return null;
    }

    /**
     * @param array<string, mixed> $response
     */
    private function resultStatus(string $toolSlug, array $response): string
    {
        $status = (string) (data_get($response, 'data.status') ?? data_get($response, 'status') ?? '');

        if (in_array($toolSlug, ['image_generate', 'image_fast_generate'], true)) {
            return data_get($response, 'data.job_id') ? 'job_created' : ($status === 'completed' ? 'job_completed' : 'job_failed');
        }

        if ($toolSlug === 'image_job_poll') {
            return match ($status) {
                'queued', 'running', 'processing', 'submitted' => 'job_polling',
                'completed', 'success' => 'job_completed',
                'failed', 'error' => 'job_failed',
                default => 'job_polling',
            };
        }

        return (($response['ok'] ?? true) === false) ? 'failed' : 'success';
    }

    private function resultKind(string $toolSlug): string
    {
        return match (AiToolSlug::canonical($toolSlug)) {
            'image_generate', 'image_fast_generate', 'image_job_poll' => 'image',
            'vision_analyze' => 'vision_analysis',
            'coding_chat' => 'coding',
            'rag_search' => 'platform_search',
            default => 'text',
        };
    }

    /**
     * @param array<string, mixed> $response
     */
    private function summary(array $response): string
    {
        foreach ([
            data_get($response, 'data.message'),
            data_get($response, 'message'),
            data_get($response, 'data.status'),
            data_get($response, 'status'),
            data_get($response, 'data.job_id'),
        ] as $candidate) {
            if (is_scalar($candidate) && trim((string) $candidate) !== '') {
                return mb_substr((string) $candidate, 0, 500);
            }
        }

        return 'Tool execution completed.';
    }

    /**
     * @param array<string, mixed> $payload
     */
    private function hash(array $payload): string
    {
        ksort($payload);

        return hash('sha256', json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE) ?: '{}');
    }
}
