<?php

namespace Modules\AiCore;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class AiAgentRuntimeConfig
{
    private const ACTIVE_BLOCKED_PLUGINS = [
        'ai-assistant',
        'professional-programmer',
    ];

    public function __construct(private readonly AiCoreSettings $settings)
    {
        //
    }

    public function enabled(): bool
    {
        return (bool) ($this->settings->values()['agent_runtime_enabled'] ?? false);
    }

    /**
     * @return array<string, mixed>
     */
    public function decisionFor(string $pluginSlug, string $toolSlug): array
    {
        $pluginSlug = $this->normalize($pluginSlug) ?: 'unknown';
        $toolSlug = AiToolSlug::canonical($toolSlug);

        if (! $this->enabled()) {
            return $this->decision('off', 'global_disabled', $pluginSlug, $toolSlug);
        }

        $binding = $this->binding($pluginSlug, $toolSlug);
        if (! $binding || ! (bool) ($binding['enabled'] ?? false)) {
            return $this->decision('off', 'binding_disabled', $pluginSlug, $toolSlug, $binding);
        }

        $requestedMode = (string) ($binding['mode'] ?? 'off');
        $mode = in_array($requestedMode, ['shadow', 'active'], true) ? $requestedMode : 'off';
        $reason = 'binding_'.$mode;

        if ($mode === 'active' && in_array($pluginSlug, self::ACTIVE_BLOCKED_PLUGINS, true)) {
            $mode = 'shadow';
            $reason = 'production_plugin_active_downgraded_to_shadow';
        }

        return $this->decision($mode, $reason, $pluginSlug, $toolSlug, $binding, $requestedMode);
    }

    public function agentModel(?array $binding = null): string
    {
        $bindingModel = is_array($binding) ? trim((string) ($binding['agent_model'] ?? '')) : '';

        return $bindingModel !== '' ? $bindingModel : (string) ($this->settings->values()['agent_model'] ?? 'qwen3:8b');
    }

    public function maxToolLoops(?array $binding = null): int
    {
        $bindingLoops = is_array($binding) && ! empty($binding['max_tool_loops']) ? (int) $binding['max_tool_loops'] : null;

        return max(1, min(10, $bindingLoops ?: (int) ($this->settings->values()['max_tool_loops'] ?? 4)));
    }

    public function contextWindow(): int
    {
        return max(1, min(30, (int) ($this->settings->values()['context_window'] ?? 8)));
    }

    public function repairAttempts(): int
    {
        return max(0, min(2, (int) ($this->settings->values()['protocol_repair_attempts'] ?? 1)));
    }

    public function shadowTimeoutMs(): int
    {
        return max(250, min(5000, (int) ($this->settings->values()['agent_shadow_timeout_ms'] ?? 1500)));
    }

    public function memorySummaryEnabled(): bool
    {
        return (bool) ($this->settings->values()['memory_summary_enabled'] ?? true);
    }

    public function toolResultFollowupEnabled(): bool
    {
        return (bool) ($this->settings->values()['tool_result_followup_enabled'] ?? true);
    }

    public function mayFallbackToStable(string $toolSlug): bool
    {
        return (bool) ($this->settings->values()['agent_runtime_fail_open_to_legacy'] ?? false)
            && AiToolSlug::canonical($toolSlug) === 'general_chat';
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function bindings(): array
    {
        if (! Schema::hasTable('ai_core_agent_runtime_bindings')) {
            return [];
        }

        return DB::table('ai_core_agent_runtime_bindings')
            ->orderBy('plugin_slug')
            ->orderBy('tool_slug')
            ->get()
            ->map(fn (object $row): array => (array) $row)
            ->all();
    }

    /**
     * @param array<int, array<string, mixed>> $bindings
     */
    public function updateBindings(array $bindings): void
    {
        if (! Schema::hasTable('ai_core_agent_runtime_bindings')) {
            return;
        }

        foreach ($bindings as $id => $input) {
            if (! is_numeric($id)) {
                continue;
            }

            $mode = (string) ($input['mode'] ?? 'off');
            if (! in_array($mode, ['off', 'shadow', 'active'], true)) {
                $mode = 'off';
            }

            DB::table('ai_core_agent_runtime_bindings')
                ->where('id', (int) $id)
                ->update([
                    'mode' => $mode,
                    'enabled' => in_array((string) ($input['enabled'] ?? '0'), ['1', 'true', 'on'], true),
                    'agent_model' => trim((string) ($input['agent_model'] ?? '')) ?: null,
                    'max_tool_loops' => ($input['max_tool_loops'] ?? '') === '' ? null : max(1, min(10, (int) $input['max_tool_loops'])),
                    'updated_at' => now(),
                ]);
        }
    }

    /**
     * @return array<string, mixed>|null
     */
    private function binding(string $pluginSlug, string $toolSlug): ?array
    {
        if (! Schema::hasTable('ai_core_agent_runtime_bindings')) {
            return null;
        }

        $row = DB::table('ai_core_agent_runtime_bindings')
            ->where('plugin_slug', $pluginSlug)
            ->where('tool_slug', $toolSlug)
            ->first();

        return $row ? (array) $row : null;
    }

    /**
     * @param array<string, mixed>|null $binding
     * @return array<string, mixed>
     */
    private function decision(string $mode, string $reason, string $pluginSlug, string $toolSlug, ?array $binding = null, ?string $requestedMode = null): array
    {
        return [
            'mode' => $mode,
            'reason' => $reason,
            'plugin_slug' => $pluginSlug,
            'tool_slug' => $toolSlug,
            'binding' => $binding,
            'requested_mode' => $requestedMode ?? $mode,
        ];
    }

    private function normalize(string $value): string
    {
        return str($value)->replace('_', '-')->slug('-')->toString();
    }
}
