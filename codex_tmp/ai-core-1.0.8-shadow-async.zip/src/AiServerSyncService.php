<?php

namespace Modules\AiCore;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Throwable;

class AiServerSyncService
{
    public function __construct(
        private readonly AiGatewayClient $gateway,
        private readonly AiCoreSettings $settings,
        private readonly AiAuditLogger $audit,
    ) {
        //
    }

    /**
     * @return array<string, mixed>
     */
    public function sync(?Authenticatable $user = null): array
    {
        $startedAt = now();
        $health = [];
        $models = [];
        $ok = true;
        $error = null;

        try {
            $health = $this->gateway->health();
            $models = $this->gateway->models();
            $this->updateModels($models, $health);
        } catch (Throwable $exception) {
            $ok = false;
            $error = $exception->getMessage();
        }

        $healthSummary = $this->summarizeHealth($health);

        $snapshot = [
            'ok' => $ok,
            'status' => $ok ? ($healthSummary['overall_status'] ?? 'degraded') : 'failed',
            'gateway_base_url' => $this->settings->gatewayBaseUrl(),
            'health_endpoint' => '/health',
            'models_endpoint' => '/models',
            'health' => $healthSummary,
            'models' => $this->summarizeModels($models),
            'error' => $error,
            'checked_at' => $startedAt->toDateTimeString(),
        ];

        $this->recordHealthSnapshot($snapshot, $user, $ok, $error);

        return $snapshot;
    }

    /**
     * Read the live /health endpoint for the admin panel without requiring a full /models sync.
     *
     * @return array<string, mixed>
     */
    public function freshHealthSnapshot(?Authenticatable $user = null): array
    {
        $startedAt = now();
        $models = $this->latestSnapshot()['models'] ?? [];

        try {
            $health = $this->gateway->health();
            $healthSummary = $this->summarizeHealth($health);

            $snapshot = [
                'ok' => true,
                'status' => $healthSummary['overall_status'] ?? 'degraded',
                'gateway_base_url' => $this->settings->gatewayBaseUrl(),
                'health_endpoint' => '/health',
                'models_endpoint' => '/models',
                'health' => $healthSummary,
                'models' => is_array($models) ? $models : [],
                'error' => null,
                'checked_at' => $startedAt->toDateTimeString(),
            ];

            $this->recordHealthSnapshot($snapshot, $user, true, null);

            return $snapshot;
        } catch (Throwable $exception) {
            $snapshot = $this->latestSnapshot();
            $snapshot['ok'] = false;
            $snapshot['status'] = 'failed';
            $snapshot['error'] = $exception->getMessage();
            $snapshot['checked_at'] = $startedAt->toDateTimeString();

            $this->recordHealthSnapshot($snapshot, $user, false, $exception->getMessage());

            return $snapshot;
        }
    }

    /**
     * @return array<string, mixed>
     */
    public function latestSnapshot(): array
    {
        if (! Schema::hasTable('ai_core_audit_logs')) {
            return [
                'ok' => false,
                'status' => 'failed',
                'gateway_base_url' => $this->settings->gatewayBaseUrl(),
                'health_endpoint' => '/health',
                'models_endpoint' => '/models',
                'health' => [],
                'models' => [],
                'error' => 'Audit table is missing.',
                'checked_at' => null,
            ];
        }

        $row = DB::table('ai_core_audit_logs')
            ->where('event_type', 'ai-core.health.checked')
            ->latest('id')
            ->first();

        if (! $row) {
            return [
                'ok' => null,
                'status' => 'not_synced',
                'gateway_base_url' => $this->settings->gatewayBaseUrl(),
                'health_endpoint' => '/health',
                'models_endpoint' => '/models',
                'health' => [],
                'models' => [],
                'error' => null,
                'checked_at' => null,
            ];
        }

        $metadata = is_string($row->metadata ?? null) ? json_decode($row->metadata, true) : [];

        return is_array($metadata) ? $metadata : [];
    }

    /**
     * @param array<string, mixed> $modelsResponse
     * @param array<string, mixed> $healthResponse
     */
    private function updateModels(array $modelsResponse, array $healthResponse): void
    {
        if (! Schema::hasTable('ai_core_models')) {
            return;
        }

        $encodedModels = json_encode($modelsResponse, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '';
        $runtimeModels = $this->flattenModels($modelsResponse);
        $now = now();
        $semanticEnabled = (bool) data_get($healthResponse, 'production_semantic', data_get($healthResponse, 'data.production_semantic', false));

        DB::table('ai_core_models')->orderBy('id')->get()->each(function (object $row) use ($runtimeModels, $encodedModels, $now, $semanticEnabled): void {
            $configured = (string) ($row->configured_model ?? data_get(json_decode((string) ($row->context_policy ?? '{}'), true), 'model', ''));
            $runtime = $this->matchingRuntimeModel((string) $row->slug, $configured, $runtimeModels, $encodedModels);
            $verified = $runtime !== null;

            DB::table('ai_core_models')
                ->where('id', $row->id)
                ->update([
                    'runtime_model' => $runtime ?: $configured,
                    'runtime_backend' => $this->runtimeBackend((string) $row->slug, (string) ($row->runtime_backend ?? $row->backend ?? '')),
                    'semantic_enabled' => $semanticEnabled || (bool) ($row->semantic_enabled ?? false),
                    'last_verified_at' => $now,
                    'verification_status' => $verified ? 'verified' : 'unverified',
                    'updated_at' => $now,
                ]);
        });
    }

    /**
     * @param array<string, mixed> $response
     * @return array<int, string>
     */
    private function flattenModels(array $response): array
    {
        $source = data_get($response, 'data.models', data_get($response, 'models', data_get($response, 'data', $response)));
        $models = [];

        $walk = function (mixed $value) use (&$walk, &$models): void {
            if (is_string($value) && $value !== '') {
                $models[] = $value;
                return;
            }

            if (is_array($value)) {
                foreach ($value as $key => $item) {
                    if (is_string($key) && ! is_numeric($key)) {
                        $models[] = $key;
                    }
                    $walk($item);
                }
            }
        };

        $walk($source);

        return array_values(array_unique($models));
    }

    /**
     * @param array<int, string> $runtimeModels
     */
    private function matchingRuntimeModel(string $slug, string $configured, array $runtimeModels, string $encodedModels): ?string
    {
        foreach (array_filter([$configured, $slug]) as $candidate) {
            foreach ($runtimeModels as $runtimeModel) {
                if ($runtimeModel === $candidate || str_contains($runtimeModel, $candidate) || str_contains($candidate, $runtimeModel)) {
                    return $runtimeModel;
                }
            }

            if ($candidate !== '' && str_contains($encodedModels, $candidate)) {
                return $candidate;
            }
        }

        return null;
    }

    private function runtimeBackend(string $slug, string $fallback): string
    {
        return match ($slug) {
            'vision_analysis' => 'vision-worker + ollama',
            'embedding' => 'embedding-worker',
            'image_generation', 'fast_image_generation' => 'comfyui',
            'artwork_similarity' => 'clip-worker',
            default => $fallback !== '' ? $fallback : 'ai-gateway',
        };
    }

    /**
     * @param array<string, mixed> $health
     * @return array<string, mixed>
     */
    private function summarizeHealth(array $health): array
    {
        $source = data_get($health, 'data', $health);

        $summary = [
            'gateway_status' => data_get($source, 'gateway.ok', data_get($source, 'gateway.status', data_get($source, 'status', data_get($source, 'ok')))),
            'ollama_status' => data_get($source, 'ollama.ok', data_get($source, 'ollama.status', data_get($source, 'services.ollama', data_get($source, 'ollama')))),
            'comfyui_status' => data_get($source, 'comfyui.ok', data_get($source, 'comfyui.status', data_get($source, 'services.comfyui', data_get($source, 'comfyui')))),
            'qdrant_status' => data_get($source, 'qdrant.ok', data_get($source, 'qdrant.status', data_get($source, 'services.qdrant', data_get($source, 'qdrant')))),
            'vision_worker_status' => data_get($source, 'vision_worker.ok', data_get($source, 'vision_worker.status', data_get($source, 'services.vision_worker', data_get($source, 'vision_worker')))),
            'embedding_worker_status' => data_get($source, 'embedding_worker.ok', data_get($source, 'embedding_worker.status', data_get($source, 'services.embedding_worker', data_get($source, 'embedding_worker')))),
            'production_semantic' => data_get($source, 'production_semantic', data_get($source, 'embedding_worker.data.production_semantic')),
        ];

        $summary['overall_status'] = $this->overallHealthStatus($summary);

        return $summary;
    }

    /**
     * @param array<string, mixed> $summary
     */
    private function overallHealthStatus(array $summary): string
    {
        $required = [
            'gateway_status',
            'ollama_status',
            'comfyui_status',
            'qdrant_status',
            'vision_worker_status',
            'embedding_worker_status',
        ];

        $states = array_map(fn (string $key): string => $this->serviceState($summary[$key] ?? null), $required);

        if (in_array('failed', $states, true)) {
            return 'failed';
        }

        if (in_array('unknown', $states, true) || in_array('degraded', $states, true)) {
            return 'degraded';
        }

        return 'healthy';
    }

    private function serviceState(mixed $value): string
    {
        if ($value === null || $value === '') {
            return 'unknown';
        }

        if (is_bool($value)) {
            return $value ? 'healthy' : 'failed';
        }

        if (is_array($value)) {
            return $this->serviceState(data_get($value, 'status', data_get($value, 'ok')));
        }

        $status = strtolower(trim((string) $value));

        return match (true) {
            in_array($status, ['1', 'true', 'ok', 'up', 'ready', 'healthy', 'running', 'available', 'connected'], true) => 'healthy',
            in_array($status, ['degraded', 'partial', 'warning', 'warn'], true) => 'degraded',
            in_array($status, ['0', 'false', 'failed', 'failure', 'error', 'down', 'offline', 'unhealthy'], true) => 'failed',
            default => 'unknown',
        };
    }

    /**
     * @param array<string, mixed> $models
     * @return array<int, string>
     */
    private function summarizeModels(array $models): array
    {
        return array_slice($this->flattenModels($models), 0, 40);
    }

    /**
     * @param array<string, mixed> $snapshot
     */
    private function recordHealthSnapshot(array $snapshot, ?Authenticatable $user, bool $allowed, ?string $reason): void
    {
        $this->audit->event('ai-core.health.checked', $snapshot, $user, 'ai-core.sync', $allowed, $reason);
    }
}
