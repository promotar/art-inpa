<?php

namespace Modules\AiCore;

class AiPolicyPackProvider
{
    public function __construct(
        private readonly AiToolRegistry $tools,
    ) {
        //
    }

    /**
     * @return array<string, mixed>
     */
    public function build(): array
    {
        return [
            'mode' => 'shadow_planner_only',
            'authority' => [
                'planner_advises_only' => true,
                'runtime_decision_owner' => 'AI Core Tool Registry, Permission Matrix, Usage Limits, Risk Policy, and existing execution flow',
                'planner_must_not_override_selected_tool' => true,
                'planner_must_not_override_permissions' => true,
                'planner_must_not_override_limits' => true,
            ],
            'privacy' => [
                'do_not_expose_chain_of_thought' => true,
                'return_decision_summary_only' => true,
                'do_not_include_secrets' => true,
                'do_not_request_or_emit_api_keys' => true,
                'database_direct_access_is_forbidden' => true,
            ],
            'tool_behavior' => [
                'answer_user' => 'Use when no platform tool is required.',
                'execute_tool' => 'Use when a registered tool is semantically appropriate, subject to AI Core runtime authority.',
                'ask_clarification' => 'Use when one concise clarification is needed before a tool can be recommended.',
                'plugin_action' => 'Use when the request belongs to a plugin workflow outside direct AI Gateway execution.',
                'refuse' => 'Use when the request is unsafe or policy-disallowed.',
            ],
            'available_tools' => $this->availableTools(),
            'output_contract' => [
                'strict_json_only' => true,
                'required_keys' => [
                    'input_language',
                    'user_response_language',
                    'semantic_intent',
                    'action',
                    'recommended_tool',
                    'tool_confidence',
                    'needs_clarification',
                    'clarification_question',
                    'is_correction_or_dissatisfaction',
                    'previous_result_relevance',
                    'should_reuse_previous_context',
                    'compiled_prompt_en',
                    'tool_payload',
                    'expected_result_type',
                    'risk_level',
                    'decision_summary',
                ],
            ],
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function availableTools(): array
    {
        return collect($this->tools->all())
            ->map(fn (array $tool): array => [
                'slug' => (string) ($tool['slug'] ?? ''),
                'endpoint' => (string) ($tool['endpoint'] ?? ''),
                'model_slug' => (string) ($tool['model_slug'] ?? ''),
                'required_permission' => (string) ($tool['required_permission'] ?? ''),
                'risk_level' => (string) ($tool['risk_level'] ?? 'low'),
                'requires_approval' => (bool) ($tool['requires_approval'] ?? false),
                'enabled' => (bool) ($tool['enabled'] ?? false),
                'allowed_roles' => (array) ($tool['allowed_roles'] ?? []),
                'plugin_owner' => (string) ($tool['plugin_owner'] ?? 'ai-core'),
            ])
            ->filter(fn (array $tool): bool => $tool['slug'] !== '')
            ->values()
            ->all();
    }

    /**
     * @return array<int, string>
     */
    public function availableToolSlugs(): array
    {
        return collect($this->availableTools())
            ->pluck('slug')
            ->filter()
            ->values()
            ->all();
    }
}
