<?php

namespace Modules\AiCore;

class AiToolExecutionContractRegistry
{
    /**
     * @return array<string, mixed>
     */
    public function forTool(string $toolSlug): array
    {
        $toolSlug = AiToolSlug::canonical($toolSlug);

        return match ($toolSlug) {
            'image_generate', 'image_fast_generate' => $this->imageContract($toolSlug),
            'image_job_poll' => $this->jobContract($toolSlug, 'image'),
            'vision_analyze' => $this->mediaContract($toolSlug, 'vision_analysis'),
            'rag_search' => $this->textContract($toolSlug, 'rag_result'),
            'coding_chat' => $this->textContract($toolSlug, 'coding_response'),
            'training_job_create' => $this->textContract($toolSlug, 'training_job'),
            'training_job_status', 'training_job_poll' => $this->jobContract($toolSlug, 'training_status'),
            'artwork_search' => $this->mediaContract($toolSlug, 'artwork_similarity'),
            'artwork_index', 'rag_index', 'text_embed' => $this->textContract($toolSlug, 'indexing_result'),
            'intent_classify' => $this->textContract($toolSlug, 'intent_result'),
            default => $this->textContract($toolSlug, 'assistant_response'),
        };
    }

    /**
     * @return array<string, mixed>
     */
    private function imageContract(string $toolSlug): array
    {
        return [
            'tool_slug' => $toolSlug,
            'required_input_fields' => ['prompt'],
            'minimum_semantic_completeness' => 'concrete_visual_brief',
            'required_context' => [],
            'expected_result_type' => 'image',
            'vague_requests_allowed' => false,
            'previous_context_may_be_reused' => true,
            'clarification_required_on_missing_data' => true,
            'requires_known_expected_result_type' => true,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function textContract(string $toolSlug, string $resultType): array
    {
        return [
            'tool_slug' => $toolSlug,
            'required_input_fields' => [],
            'minimum_semantic_completeness' => 'message_or_context',
            'required_context' => [],
            'expected_result_type' => $resultType,
            'vague_requests_allowed' => true,
            'previous_context_may_be_reused' => true,
            'clarification_required_on_missing_data' => false,
            'requires_known_expected_result_type' => true,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function mediaContract(string $toolSlug, string $resultType): array
    {
        return [
            'tool_slug' => $toolSlug,
            'required_input_fields' => [],
            'minimum_semantic_completeness' => 'media_or_visual_context',
            'required_context' => [],
            'expected_result_type' => $resultType,
            'vague_requests_allowed' => false,
            'previous_context_may_be_reused' => true,
            'clarification_required_on_missing_data' => true,
            'requires_known_expected_result_type' => true,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function jobContract(string $toolSlug, string $resultType): array
    {
        return [
            'tool_slug' => $toolSlug,
            'required_input_fields' => ['job_id'],
            'minimum_semantic_completeness' => 'job_identifier',
            'required_context' => [],
            'expected_result_type' => $resultType,
            'vague_requests_allowed' => false,
            'previous_context_may_be_reused' => false,
            'clarification_required_on_missing_data' => false,
            'requires_known_expected_result_type' => true,
        ];
    }
}
