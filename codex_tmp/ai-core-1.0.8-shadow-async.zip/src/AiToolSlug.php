<?php

namespace Modules\AiCore;

class AiToolSlug
{
    private const ALIASES = [
        'generate_image' => 'image_generate',
        'image_generation' => 'image_generate',
        'fast_generate_image' => 'image_fast_generate',
        'fast_image_generation' => 'image_fast_generate',
        'generate_fast_image' => 'image_fast_generate',
        'analyze_image' => 'vision_analyze',
        'image_analyze' => 'vision_analyze',
        'vision_analysis' => 'vision_analyze',
        'search_artwork' => 'artwork_search',
        'artwork_similarity' => 'artwork_search',
        'rag_question' => 'rag_search',
        'knowledge_search' => 'rag_search',
        'chat_general' => 'general_chat',
        'coding_assistant' => 'coding_chat',
    ];

    public static function canonical(string $toolSlug): string
    {
        $toolSlug = trim($toolSlug);
        $normalized = str_replace('-', '_', $toolSlug);

        return self::ALIASES[$normalized] ?? $normalized;
    }

    /**
     * @return array<int, string>
     */
    public static function aliasesFor(string $canonicalToolSlug): array
    {
        $canonicalToolSlug = self::canonical($canonicalToolSlug);
        $aliases = [$canonicalToolSlug];

        foreach (self::ALIASES as $alias => $canonical) {
            if ($canonical === $canonicalToolSlug) {
                $aliases[] = $alias;
            }
        }

        return array_values(array_unique($aliases));
    }
}
