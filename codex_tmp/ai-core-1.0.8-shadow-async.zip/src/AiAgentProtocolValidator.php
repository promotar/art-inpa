<?php

namespace Modules\AiCore;

class AiAgentProtocolValidator
{
    private const STEP_TYPES = ['final_response', 'clarification', 'tool_call', 'tool_result_evaluation', 'memory_update', 'refusal'];
    private const STATUSES = ['finish', 'retry', 'modify', 'ask_user', 'call_tool', 'call_another_tool', 'blocked', 'failed'];
    private const RESULT_KINDS = ['text', 'image', 'image_edit', 'vision_analysis', 'consultation', 'platform_search', 'coding', 'data_lookup', 'mixed', 'none'];
    private const USAGE_CATEGORIES = ['text_chat', 'image_generate', 'image_fast_generate', 'image_edit', 'vision_analyze', 'rag_search', 'coding_chat', 'consultation', 'none'];
    private const CONFIDENCE_BANDS = ['high', 'medium', 'low'];
    private const CONTEXT_STRATEGIES = ['none', 'use_recent_messages', 'use_memory_summary', 'use_latest_visual_context', 'use_previous_tool_result', 'use_previous_failed_result', 'ask_user_for_missing_context'];
    private const RISK_LEVELS = ['low', 'medium', 'high'];

    private const EXPENSIVE_OR_SENSITIVE_TOOLS = [
        'image_generate',
        'image_fast_generate',
        'image_job_poll',
        'vision_analyze',
        'rag_search',
        'rag_index',
        'artwork_search',
        'artwork_index',
        'coding_chat',
        'training_job_create',
        'training_job_status',
        'training_job_poll',
    ];

    /**
     * @param array<string, mixed> $step
     * @param array<int, array<string, mixed>> $availableTools
     * @return array{valid: bool, step: array<string, mixed>, errors: array<int, string>, reason: string|null}
     */
    public function validate(array $step, array $availableTools): array
    {
        $errors = [];
        $availableToolSlugs = collect($availableTools)->pluck('slug')->filter()->values()->all();

        foreach ($this->defaults() as $key => $default) {
            if (! array_key_exists($key, $step)) {
                $step[$key] = $default;
            }
        }

        $this->validateEnum($step, 'step_type', self::STEP_TYPES, $errors);
        $this->validateEnum($step, 'status', self::STATUSES, $errors);
        $this->validateEnum($step, 'result_kind', self::RESULT_KINDS, $errors);
        $this->validateEnum($step, 'usage_category', self::USAGE_CATEGORIES, $errors);
        $this->validateEnum($step, 'confidence_band', self::CONFIDENCE_BANDS, $errors);
        $this->validateEnum($step, 'context_strategy', self::CONTEXT_STRATEGIES, $errors);
        $this->validateEnum($step, 'risk_level', self::RISK_LEVELS, $errors);

        $toolSlug = $step['tool_slug'] === null || $step['tool_slug'] === '' ? null : AiToolSlug::canonical((string) $step['tool_slug']);
        $step['tool_slug'] = $toolSlug;

        if ($toolSlug !== null && ! in_array($toolSlug, $availableToolSlugs, true)) {
            $errors[] = 'unknown_tool';
        }

        if (! is_array($step['missing_slots'])) {
            $step['missing_slots'] = [];
        }
        if (! is_array($step['tool_arguments'])) {
            $step['tool_arguments'] = [];
        }

        $step['needs_user_input'] = (bool) $step['needs_user_input'];
        $step['should_continue_loop'] = (bool) $step['should_continue_loop'];

        $stepType = (string) $step['step_type'];
        if ($stepType === 'final_response') {
            if (trim((string) $step['final_message']) === '') {
                $errors[] = 'final_message_required';
            }
            if ((string) $step['status'] !== 'finish') {
                $errors[] = 'final_response_status_must_finish';
            }
            if ($toolSlug !== null) {
                $errors[] = 'final_response_must_not_include_tool';
            }
        }

        if ($stepType === 'clarification') {
            if (trim((string) $step['clarification_message']) === '') {
                $errors[] = 'clarification_message_required';
            }
            if ((string) $step['status'] !== 'ask_user') {
                $errors[] = 'clarification_status_must_ask_user';
            }
            if ($toolSlug !== null) {
                $errors[] = 'clarification_must_not_include_tool';
            }
        }

        if ($stepType === 'tool_call') {
            if ($toolSlug === null) {
                $errors[] = 'tool_slug_required';
            }
            if ($step['tool_arguments'] === []) {
                $errors[] = 'tool_arguments_required';
            }
            if (! in_array((string) $step['status'], ['call_tool', 'call_another_tool', 'retry', 'modify'], true)) {
                $errors[] = 'tool_call_status_invalid';
            }
            if ($toolSlug !== null && ! $this->usageMatchesTool((string) $step['usage_category'], $toolSlug)) {
                $errors[] = 'usage_category_tool_mismatch';
            }
        }

        if ($stepType === 'tool_result_evaluation') {
            if ((string) $step['status'] === 'finish' && trim((string) $step['final_message']) === '') {
                $errors[] = 'tool_result_evaluation_final_message_required';
            }
            if ((string) $step['status'] === 'ask_user' && trim((string) $step['clarification_message']) === '') {
                $errors[] = 'tool_result_evaluation_clarification_required';
            }
            if (in_array((string) $step['status'], ['retry', 'modify', 'call_another_tool'], true)) {
                if ($toolSlug === null) {
                    $errors[] = 'tool_slug_required';
                }
                if ($step['tool_arguments'] === []) {
                    $errors[] = 'tool_arguments_required';
                }
                if ($toolSlug !== null && ! $this->usageMatchesTool((string) $step['usage_category'], $toolSlug)) {
                    $errors[] = 'usage_category_tool_mismatch';
                }
            }
        }

        if ((string) $step['confidence_band'] === 'low' && $toolSlug !== null && in_array($toolSlug, self::EXPENSIVE_OR_SENSITIVE_TOOLS, true)) {
            $errors[] = 'low_confidence_expensive_tool_blocked';
        }

        return [
            'valid' => $errors === [],
            'step' => $step,
            'errors' => array_values(array_unique($errors)),
            'reason' => $errors[0] ?? null,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function defaults(): array
    {
        return [
            'step_type' => 'final_response',
            'status' => 'finish',
            'result_kind' => 'none',
            'tool_slug' => null,
            'usage_category' => 'none',
            'confidence_band' => 'low',
            'context_strategy' => 'none',
            'risk_level' => 'low',
            'missing_slots' => [],
            'needs_user_input' => false,
            'should_continue_loop' => false,
            'final_message' => null,
            'clarification_message' => null,
            'tool_arguments' => [],
            'execution_prompt' => null,
            'memory_summary_update' => null,
            'decision_summary' => '',
        ];
    }

    /**
     * @param array<string, mixed> $step
     * @param array<int, string> $allowed
     * @param array<int, string> $errors
     */
    private function validateEnum(array $step, string $key, array $allowed, array &$errors): void
    {
        if (! in_array((string) ($step[$key] ?? ''), $allowed, true)) {
            $errors[] = 'invalid_'.$key;
        }
    }

    private function usageMatchesTool(string $usageCategory, string $toolSlug): bool
    {
        return match (AiToolSlug::canonical($toolSlug)) {
            'general_chat', 'intent_classify' => in_array($usageCategory, ['text_chat', 'none'], true),
            'coding_chat' => $usageCategory === 'coding_chat',
            'image_generate' => $usageCategory === 'image_generate',
            'image_fast_generate' => $usageCategory === 'image_fast_generate',
            'vision_analyze' => $usageCategory === 'vision_analyze',
            'rag_search', 'rag_index', 'text_embed' => $usageCategory === 'rag_search',
            default => true,
        };
    }
}
