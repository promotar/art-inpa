<?php

namespace Modules\AiCore;

class AiAgentPromptBuilder
{
    public function systemPrompt(): string
    {
        return implode("\n", [
            'You are the reasoning brain of Art INPA AI Core.',
            'AI Core is the runtime host and the only tool executor.',
            'Decide the next step using the provided context envelope.',
            'Return strict JSON only. Do not include markdown, prose outside JSON, or hidden reasoning.',
            'Do not invent tools, permissions, limits, files, images, jobs, database rows, or results.',
            'Do not claim a tool was executed until AI Core returns a tool_result.',
            'Write natural replies only in final_message or clarification_message.',
            'Use the user response language from the current user message.',
            'Use tools only when needed and only from available_tools.',
            'Ask the user naturally if required information is missing.',
            'After tool results, decide whether to finish, retry, modify, ask the user, or call another allowed tool.',
            'Never expose chain-of-thought. Use decision_summary for a short operational summary.',
            'Return one compact JSON object. No markdown. No preface. No trailing explanation.',
        ]);
    }

    public function repairPrompt(string $invalidOutput): string
    {
        return implode("\n", [
            'Your previous output was not valid AI Core agent_step JSON.',
            'Return one valid JSON object only using the required protocol.',
            'Do not explain the repair.',
            'Invalid output excerpt:',
            mb_substr($invalidOutput, 0, 1200),
        ]);
    }

    /**
     * @param array<string, mixed> $contextEnvelope
     * @param array<string, mixed>|null $toolResult
     * @return array<string, mixed>
     */
    public function payload(string $model, array $contextEnvelope, ?array $toolResult = null, ?string $messageOverride = null): array
    {
        return [
            'model' => $model,
            'system' => $this->systemPrompt(),
            'message' => $messageOverride ?: 'Return the next AI Core agent_step JSON for this request.',
            'context' => [
                'agent_protocol' => $this->protocolSchema(),
                'context_envelope' => $contextEnvelope,
                'tool_result' => $toolResult,
            ],
            'temperature' => 0.05,
            'max_tokens' => 800,
            'response_format' => ['type' => 'json_object'],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function protocolSchema(): array
    {
        return [
            'required_fields' => [
                'step_type',
                'status',
                'result_kind',
                'tool_slug',
                'usage_category',
                'confidence_band',
                'context_strategy',
                'risk_level',
                'missing_slots',
                'needs_user_input',
                'should_continue_loop',
                'final_message',
                'clarification_message',
                'tool_arguments',
                'execution_prompt',
                'memory_summary_update',
                'decision_summary',
            ],
            'enums' => [
                'step_type' => ['final_response', 'clarification', 'tool_call', 'tool_result_evaluation', 'memory_update', 'refusal'],
                'status' => ['finish', 'retry', 'modify', 'ask_user', 'call_tool', 'call_another_tool', 'blocked', 'failed'],
                'result_kind' => ['text', 'image', 'image_edit', 'vision_analysis', 'consultation', 'platform_search', 'coding', 'data_lookup', 'mixed', 'none'],
                'usage_category' => ['text_chat', 'image_generate', 'image_fast_generate', 'image_edit', 'vision_analyze', 'rag_search', 'coding_chat', 'consultation', 'none'],
                'confidence_band' => ['high', 'medium', 'low'],
                'context_strategy' => ['none', 'use_recent_messages', 'use_memory_summary', 'use_latest_visual_context', 'use_previous_tool_result', 'use_previous_failed_result', 'ask_user_for_missing_context'],
                'risk_level' => ['low', 'medium', 'high'],
            ],
        ];
    }
}
