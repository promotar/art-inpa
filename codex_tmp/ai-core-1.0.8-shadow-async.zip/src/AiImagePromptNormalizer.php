<?php

namespace Modules\AiCore;

class AiImagePromptNormalizer
{
    /**
     * @param array<string, mixed> $payload
     * @return array{payload: array<string, mixed>, metadata: array<string, mixed>}
     */
    public function normalize(array $payload, bool $fast = false): array
    {
        $originalPrompt = $this->extractPrompt($payload);
        $cleanPrompt = $this->removeImageCommand($originalPrompt);
        $normalizedPrompt = $this->containsArabic($cleanPrompt)
            ? $this->translateArabicPrompt($cleanPrompt)
            : trim($cleanPrompt);

        if ($normalizedPrompt === '') {
            $normalizedPrompt = 'high quality realistic image';
        }

        $normalizedPrompt = $this->ensureQualityPrompt($normalizedPrompt);

        $finalPayload = [
            'prompt' => $normalizedPrompt,
            'negative_prompt' => (string) ($payload['negative_prompt'] ?? ''),
            'width' => $this->intInRange($payload['width'] ?? 1024, 256, 2048, 1024),
            'height' => $this->intInRange($payload['height'] ?? 1024, 256, 2048, 1024),
            'steps' => $this->intInRange($payload['steps'] ?? ($fast ? 8 : 25), 1, 80, $fast ? 8 : 25),
            'wait' => (bool) ($payload['wait'] ?? false),
        ];

        if (array_key_exists('seed', $payload) && $payload['seed'] !== null && $payload['seed'] !== '') {
            $finalPayload['seed'] = (int) $payload['seed'];
        }

        return [
            'payload' => $finalPayload,
            'metadata' => [
                'original_prompt' => $originalPrompt,
                'clean_prompt' => $cleanPrompt,
                'normalized_prompt' => $normalizedPrompt,
                'final_prompt' => $finalPayload['prompt'],
                'is_arabic_prompt' => $this->containsArabic($originalPrompt),
                'dropped_payload_keys' => array_values(array_diff(array_keys($payload), array_keys($finalPayload))),
                'width' => $finalPayload['width'],
                'height' => $finalPayload['height'],
                'steps' => $finalPayload['steps'],
                'seed' => $finalPayload['seed'] ?? null,
                'negative_prompt' => $finalPayload['negative_prompt'],
                'wait' => $finalPayload['wait'],
            ],
        ];
    }

    /**
     * @param array<string, mixed> $payload
     */
    private function extractPrompt(array $payload): string
    {
        foreach (['prompt', 'user_text', 'message', 'text', 'input', 'content'] as $key) {
            $value = $payload[$key] ?? null;
            if (is_string($value) && trim($value) !== '') {
                return trim($this->cleanUtf8($value));
            }
        }

        return '';
    }

    private function removeImageCommand(string $prompt): string
    {
        $prompt = trim($prompt);
        $patterns = [
            '/^(?:اعمل|اعملي|اعطني|اعطيني|صمم|صممي|ارسم|ارسمي|ولد|ولّد|انشئ|أنشئ)\s+(?:لي\s+)?(?:صورة|صوره)\s*/u',
            '/^(?:اعمل|اعملي|اعطني|اعطيني|صمم|صممي|ارسم|ارسمي|ولد|ولّد|انشئ|أنشئ)\s*/u',
            '/^(?:generate|create|design|draw)\s+(?:an?\s+)?(?:image|picture|poster)\s*/i',
        ];

        return trim((string) preg_replace($patterns, '', $prompt));
    }

    private function containsArabic(string $value): bool
    {
        return preg_match('/\p{Arabic}/u', $value) === 1;
    }

    private function translateArabicPrompt(string $prompt): string
    {
        $text = $this->normalizeArabicText($prompt);
        $phrases = [
            'سلحفاة تمشي على الماء بجانب النهر في الغابة' => 'a turtle walking on the surface of water beside a river in a dense green forest',
            'سلحفاة تمشي علي الماء بجانب النهر في الغابة' => 'a turtle walking on the surface of water beside a river in a dense green forest',
            'سلحفاه تمشي على الماء بجانب النهر في الغابة' => 'a turtle walking on the surface of water beside a river in a dense green forest',
            'سلحفاه تمشي علي الماء بجانب النهر في الغابة' => 'a turtle walking on the surface of water beside a river in a dense green forest',
            'سلحفاه تمشي على الماء بجانب الهر في الغابة' => 'a turtle walking on the surface of water beside a river in a dense green forest',
            'سلحفاه تمشي علي الماء بجانب الهر في الغابة' => 'a turtle walking on the surface of water beside a river in a dense green forest',
            'سيارة سباق خارقة في شارع' => 'a supercar racing car in a city street',
            'سياره سباق خارقه في شارع' => 'a supercar racing car in a city street',
            'راقصة ترقص في حفل غنائي' => 'a dancer dancing at a live concert on a music stage',
            'راقصه ترقص في حفل غنائي' => 'a dancer dancing at a live concert on a music stage',
            '3 أطفال يلعبون في حديقة عامة' => 'three children playing in a public park garden',
            '3 اطفال يلعبون في حديقة عامة' => 'three children playing in a public park garden',
            'ثلاثة أطفال يلعبون في حديقة عامة' => 'three children playing in a public park garden',
            'ثلاثة اطفال يلعبون في حديقة عامة' => 'three children playing in a public park garden',
        ];

        foreach ($phrases as $arabic => $english) {
            if (str_contains($text, $arabic)) {
                return $english;
            }
        }

        $dictionary = [
            'سلحفاة' => 'turtle',
            'سلحفاه' => 'turtle',
            'تمشي' => 'walking',
            'تسير' => 'walking',
            'على' => 'on',
            'علي' => 'on',
            'سطح' => 'surface',
            'الماء' => 'water',
            'ماء' => 'water',
            'بجانب' => 'beside',
            'قرب' => 'near',
            'النهر' => 'river',
            'نهر' => 'river',
            'الهر' => 'river',
            'الغابة' => 'forest',
            'غابة' => 'forest',
            'كثيفة' => 'dense',
            'خضراء' => 'green',
            'سيارة' => 'car',
            'سياره' => 'car',
            'سباق' => 'racing',
            'خارقة' => 'supercar',
            'خارقه' => 'supercar',
            'شارع' => 'street',
            'سريع' => 'fast',
            'راقصة' => 'dancer',
            'راقصه' => 'dancer',
            'ترقص' => 'dancing',
            'حفل' => 'concert',
            'غنائي' => 'music',
            'مسرح' => 'stage',
            'أطفال' => 'children',
            'اطفال' => 'children',
            'طفل' => 'child',
            'ثلاثة' => 'three',
            'يلعبون' => 'playing',
            'يلعب' => 'playing',
            'حديقة' => 'park garden',
            'حديقه' => 'park garden',
            'عامة' => 'public',
            'عامه' => 'public',
            'واقعية' => 'realistic',
            'واقعيه' => 'realistic',
            'تفاصيل' => 'details',
            'عالية' => 'high',
            'سينمائي' => 'cinematic',
            'اضاءة' => 'lighting',
            'إضاءة' => 'lighting',
            '?لحفاة' => 'turtle',
            '?لحفاه' => 'turtle',
            '?مشي' => 'walking',
            '?سير' => 'walking',
            '?لي' => 'on',
            '?لماء' => 'water',
            '?اء' => 'water',
            '?جانب' => 'beside',
            '?رب' => 'near',
            '?لنهر' => 'river',
            '?هر' => 'river',
            '?لغابة' => 'forest',
            '?ابة' => 'forest',
        ];

        $tokens = preg_split('/\s+/u', $text) ?: [];
        $translated = [];

        foreach ($tokens as $token) {
            $clean = $this->cleanToken($token);
            if ($clean === '') {
                continue;
            }

            if (preg_match('/^\d+$/', $clean) === 1) {
                $translated[] = $clean === '3' ? 'three' : $clean;
                continue;
            }

            $translated[] = $dictionary[$clean] ?? $this->stripArabicArticle($dictionary, $clean);
        }

        return trim(implode(' ', array_filter($translated)));
    }

    private function cleanToken(string $token): string
    {
        $clean = preg_replace('/^[\s\p{P}\p{S}]+|[\s\p{P}\p{S}]+$/u', '', $token);

        return is_string($clean) ? $clean : '';
    }

    private function normalizeArabicText(string $text): string
    {
        $text = $this->repairQuestionMarkArabicText($text);
        $text = str_replace(['أ', 'إ', 'آ'], 'ا', $text);
        $text = str_replace('ى', 'ي', $text);

        return trim(preg_replace('/\s+/u', ' ', $text) ?: $text);
    }

    private function repairQuestionMarkArabicText(string $text): string
    {
        $repairs = [
            '?لحفاة' => 'سلحفاة',
            '?لحفاه' => 'سلحفاه',
            '?مشي' => 'تمشي',
            '?سير' => 'تسير',
            '?لي' => 'على',
            '?لماء' => 'الماء',
            '?اء' => 'ماء',
            '?جانب' => 'بجانب',
            '?رب' => 'قرب',
            '?لنهر' => 'النهر',
            '?هر' => 'نهر',
            '?لغابة' => 'الغابة',
            '?ابة' => 'غابة',
        ];

        return str_replace(array_keys($repairs), array_values($repairs), $text);
    }

    /**
     * @param array<string, string> $dictionary
     */
    private function stripArabicArticle(array $dictionary, string $token): string
    {
        if (str_starts_with($token, 'ال')) {
            $withoutArticle = mb_substr($token, 2);

            return $dictionary[$withoutArticle] ?? $withoutArticle;
        }

        return $token;
    }

    private function ensureQualityPrompt(string $prompt): string
    {
        $prompt = trim($this->cleanUtf8($prompt));
        $quality = 'realistic, cinematic lighting, high detail';

        return str_contains(strtolower($prompt), 'realistic')
            ? $prompt
            : $prompt.', '.$quality;
    }

    private function cleanUtf8(string $value): string
    {
        if (mb_check_encoding($value, 'UTF-8')) {
            return $value;
        }

        foreach (['UTF-8', 'CP1256', 'ISO-8859-1', 'Windows-1252'] as $encoding) {
            try {
                $converted = @mb_convert_encoding($value, 'UTF-8', $encoding);
                if (is_string($converted) && mb_check_encoding($converted, 'UTF-8')) {
                    return $converted;
                }
            } catch (\Throwable) {
                continue;
            }
        }

        $ignored = @iconv('UTF-8', 'UTF-8//IGNORE', $value);

        return is_string($ignored) ? $ignored : '';
    }

    private function intInRange(mixed $value, int $min, int $max, int $default): int
    {
        $integer = is_numeric($value) ? (int) $value : $default;

        return max($min, min($max, $integer));
    }
}
