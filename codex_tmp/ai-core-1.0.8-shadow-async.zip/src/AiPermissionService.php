<?php

namespace Modules\AiCore;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

class AiPermissionService
{
    private const ADMIN_APPROVED_INDEXING_TOOLS = [
        'rag_index',
        'artwork_index',
        'text_embed',
    ];

    /**
     * @param array<string, mixed> $context
     * @return array{allowed: bool, reason: string}
     */
    public function authorizeTool(string $toolSlug, ?Authenticatable $user = null, array $context = []): array
    {
        $toolSlug = AiToolSlug::canonical($toolSlug);
        $pluginSlug = $this->normalizeIdentifier((string) ($context['plugin'] ?? $context['plugin_slug'] ?? '')) ?? '';
        $roles = $this->roles($user);

        if (! Schema::hasTable('ai_core_tool_permissions')) {
            return ['allowed' => true, 'reason' => 'ai_core_tool_permissions_table_missing_fallback_allowed'];
        }

        if ($this->isAdminApprovedIndexingContext($toolSlug, $pluginSlug, $user, $context)) {
            return ['allowed' => true, 'reason' => 'allowed_ai_core_admin_approved_indexing_context'];
        }

        $query = DB::table('ai_core_tool_permissions')->where('tool_slug', $toolSlug);
        if ($pluginSlug !== '') {
            $query->where(function ($nested) use ($pluginSlug): void {
                $nested->whereNull('plugin_slug')->orWhere('plugin_slug', $pluginSlug);
            });
        }

        $rows = $query->get();
        if ($rows->isEmpty()) {
            return ['allowed' => false, 'reason' => 'tool_not_allowed_for_plugin'];
        }

        foreach ($rows as $row) {
            $role = $row->role_slug ? (string) $row->role_slug : null;
            if (($role === null || in_array($role, $roles, true)) && (bool) $row->allowed) {
                return ['allowed' => true, 'reason' => 'allowed_by_ai_core_permission_matrix'];
            }
        }

        return ['allowed' => false, 'reason' => 'user_role_not_allowed_for_tool'];
    }

    /**
     * @return array<int, string>
     */
    public function roles(?Authenticatable $user): array
    {
        if (! $user) {
            return ['guest'];
        }

        $roles = ['user'];
        foreach (['role', 'role_slug', 'type'] as $field) {
            if (isset($user->{$field}) && is_string($user->{$field}) && $user->{$field} !== '') {
                $roles[] = $this->normalizeIdentifier($user->{$field});
            }
        }

        if (method_exists($user, 'hasRole')) {
            foreach (['developer', 'admin', 'super_admin', 'super-admin'] as $role) {
                try {
                    if ($user->hasRole($role)) {
                        $roles[] = $this->normalizeIdentifier($role);
                    }
                } catch (\Throwable) {
                    //
                }
            }
        }

        if (method_exists($user, 'getRoleNames')) {
            try {
                foreach ($user->getRoleNames() as $role) {
                    if (is_string($role) && $role !== '') {
                        $roles[] = $this->normalizeIdentifier($role);
                    }
                }
            } catch (\Throwable) {
                //
            }
        }

        if (isset($user->is_admin) && $user->is_admin) {
            $roles[] = 'admin';
        }

        return array_values(array_unique(array_filter($this->normalizeIdentifiers($roles))));
    }

    public function normalizeIdentifier(?string $value): ?string
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }

        return Str::slug(str_replace('_', '-', $value), '-');
    }

    /**
     * @param array<int, mixed> $values
     * @return array<int, string>
     */
    public function normalizeIdentifiers(array $values): array
    {
        return array_values(array_unique(array_filter(array_map(
            fn (mixed $value): ?string => is_scalar($value) ? $this->normalizeIdentifier((string) $value) : null,
            $values,
        ))));
    }

    /**
     * @param array<string, mixed> $context
     */
    private function isAdminApprovedIndexingContext(string $toolSlug, string $pluginSlug, ?Authenticatable $user, array $context): bool
    {
        if (! in_array($toolSlug, self::ADMIN_APPROVED_INDEXING_TOOLS, true) || $pluginSlug !== 'ai-core') {
            return false;
        }

        $approved = filter_var($context['admin_approved'] ?? false, FILTER_VALIDATE_BOOLEAN)
            || str_starts_with((string) ($context['source'] ?? ''), 'admin.plugins.ai-core');

        if (! $approved || ! $user) {
            return false;
        }

        if (method_exists($user, 'hasPermissionTo')) {
            foreach (['ai-core.manage', 'ai-core.settings.update'] as $permission) {
                try {
                    if ($user->hasPermissionTo($permission)) {
                        return true;
                    }
                } catch (\Throwable) {
                    //
                }
            }
        }

        return array_intersect($this->roles($user), ['admin', 'super-admin', 'staff', 'developer']) !== [];
    }
}
