<?php

namespace Modules\AiCore;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

class AiGatewayClient
{
    private const FINAL_ENDPOINTS = [
        '/health',
        '/models',
        '/v1/router/intent',
        '/v1/general/chat',
        '/v1/coding/chat',
        '/v1/images/generate',
        '/v1/images/fast-generate',
        '/v1/images/jobs/{job_id}',
        '/v1/vision/analyze',
        '/v1/text/embed',
        '/v1/rag/index',
        '/v1/rag/search',
        '/v1/artwork/index',
        '/v1/artwork/search',
        '/v1/coding/training/status',
        '/v1/coding/training/jobs',
        '/v1/coding/training/jobs/{job_id}',
    ];

    public function __construct(
        private readonly AiCoreSettings $settings,
        private readonly AiToolRegistry $tools,
        private readonly AiModelRegistry $models,
        private readonly AiPermissionService $permissions,
        private readonly AiUsageLimiter $usage,
        private readonly AiAuditLogger $audit,
        private readonly AiToolReadinessService $readiness,
        private readonly AiImagePromptNormalizer $imagePrompts,
        private readonly AiSemanticPlanner $semanticPlanner,
        private readonly AiToolExecutionGate $executionGate,
        private readonly AiAgentRuntimeConfig $agentRuntimeConfig,
        private readonly AiAgentResponseAdapter $agentResponseAdapter,
    ) {
        //
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function executeTool(string $toolSlug, array $payload = [], array $context = [], ?Authenticatable $user = null): array
    {
        $toolSlug = AiToolSlug::canonical($toolSlug);
        $plugin = (string) ($context['plugin'] ?? $context['plugin_slug'] ?? $payload['plugin'] ?? 'unknown');
        $context['plugin'] = $context['plugin'] ?? $plugin;

        if (! (bool) ($context['agent_runtime_bypass'] ?? false)) {
            $agentDecision = $this->agentRuntimeConfig->decisionFor($plugin, $toolSlug);
            $agentMode = (string) ($agentDecision['mode'] ?? 'off');

            if ($agentMode === 'shadow') {
                $this->scheduleShadowRun($toolSlug, $payload, $context, $user, $agentDecision);

                return $this->executeStableTool($toolSlug, $payload, $context, $user);
            }

            if ($agentMode === 'active') {
                try {
                    $runResult = app(AiAgentRuntime::class)->runActive($toolSlug, $payload, $context, $user, $agentDecision);
                    if (($runResult['status'] ?? null) === 'completed') {
                        return $this->agentResponseAdapter->toLegacyResponse($toolSlug, $runResult);
                    }

                    throw new AiCoreException('agent_runtime_failed', 'AI Core Agent Runtime failed before safe completion.');
                } catch (\Throwable $exception) {
                    $reasonCode = $exception instanceof AiCoreException ? $exception->reasonCode() : 'agent_runtime_failed';
                    $this->audit->event('agent_runtime.active_failed', [
                        'plugin' => $plugin,
                        'tool_slug' => $toolSlug,
                        'reason_code' => $reasonCode,
                        'fallback_allowed' => $this->agentRuntimeConfig->mayFallbackToStable($toolSlug),
                    ], $user, $toolSlug, false, $reasonCode);

                    if ($this->agentRuntimeConfig->mayFallbackToStable($toolSlug)) {
                        return $this->executeStableTool($toolSlug, $payload, $context, $user);
                    }

                    if ($exception instanceof AiCoreException) {
                        throw $exception;
                    }

                    throw new AiCoreException('agent_runtime_failed', 'AI Core Agent Runtime failed closed for this tool.', previous: $exception);
                }
            }
        }

        return $this->executeStableTool($toolSlug, $payload, $context, $user);
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @param array<string, mixed> $agentDecision
     */
    private function scheduleShadowRun(string $toolSlug, array $payload, array $context, ?Authenticatable $user, array $agentDecision): void
    {
        $plugin = (string) ($context['plugin'] ?? $context['plugin_slug'] ?? $payload['plugin'] ?? $agentDecision['plugin_slug'] ?? 'unknown');

        try {
            app()->terminating(function () use ($toolSlug, $payload, $context, $user, $agentDecision, $plugin): void {
                try {
                    app(AiAgentRuntime::class)->runShadow($toolSlug, $payload, $context, $user, $agentDecision);
                } catch (\Throwable $exception) {
                    app(AiAgentAuditLogger::class)->shadowFailure(
                        $plugin,
                        $toolSlug,
                        $exception instanceof AiCoreException ? $exception->reasonCode() : 'agent_shadow_failed',
                        [
                            'error' => 'Agent shadow planning failed after the stable response path.',
                            'stable_runtime_unaffected' => true,
                            'non_blocking' => true,
                        ],
                        $user,
                    );
                }
            });
        } catch (\Throwable $exception) {
            app(AiAgentAuditLogger::class)->shadowFailure(
                $plugin,
                $toolSlug,
                $exception instanceof AiCoreException ? $exception->reasonCode() : 'agent_shadow_schedule_failed',
                [
                    'error' => 'Agent shadow planning could not be scheduled.',
                    'stable_runtime_unaffected' => true,
                    'non_blocking' => true,
                ],
                $user,
            );
        }
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function executeStableTool(string $toolSlug, array $payload = [], array $context = [], ?Authenticatable $user = null): array
    {
        $toolSlug = AiToolSlug::canonical($toolSlug);
        $tool = $this->tools->find($toolSlug);
        if (! $tool || ! (bool) ($tool['enabled'] ?? false)) {
            throw new AiCoreException('tool_disabled', 'AI Core tool is not available.');
        }

        $model = $this->models->forTool($toolSlug);
        if ($model && ! (bool) ($model['enabled'] ?? false)) {
            throw new AiCoreException('backend_unavailable', 'AI Core model is not available for this tool.');
        }

        $context['model_slug'] = $context['model_slug'] ?? ($model['slug'] ?? null);
        $context['method'] = $context['method'] ?? 'POST';

        $plannerPlan = $this->semanticPlanner->plan($toolSlug, $payload, $context, $user);
        if (is_array($plannerPlan)) {
            $context['semantic_planner'] = [
                'status' => $plannerPlan['status'] ?? 'ok',
                'semantic_intent' => $plannerPlan['semantic_intent'] ?? '',
                'action' => $plannerPlan['action'] ?? '',
                'recommended_tool' => $plannerPlan['recommended_tool'] ?? null,
                'tool_confidence' => $plannerPlan['tool_confidence'] ?? 0.0,
                'needs_clarification' => $plannerPlan['needs_clarification'] ?? false,
                'previous_result_relevance' => $plannerPlan['previous_result_relevance'] ?? 'none',
                'should_reuse_previous_context' => $plannerPlan['should_reuse_previous_context'] ?? false,
                'expected_result_type' => $plannerPlan['expected_result_type'] ?? '',
                'risk_level' => $plannerPlan['risk_level'] ?? 'low',
                'decision_summary' => $plannerPlan['decision_summary'] ?? '',
                'shadow_mode' => true,
                'runtime_unchanged' => true,
            ];
        }

        $gate = $this->executionGate->validate($toolSlug, $tool, $payload, $context, $plannerPlan, $user);
        $context['execution_contract'] = $gate['audit'];

        if (! $gate['allowed']) {
            $this->audit->event(
                'execution_blocked_by_contract',
                $gate['audit'],
                $user,
                $toolSlug,
                false,
                $gate['reason_blocked'],
            );

            throw new AiCoreException(
                $gate['reason_blocked'] ?: 'execution_contract_failed',
                $gate['clarification_question'] ?: 'AI Core blocked this tool request because it did not satisfy the execution contract.'
            );
        }

        $payload = $gate['payload'];
        $context = $gate['context'];
        $context['execution_contract'] = $gate['audit'];

        $permission = $this->permissions->authorizeTool($toolSlug, $user, $context);
        $this->audit->event('permission.checked', $context, $user, $toolSlug, $permission['allowed'], $permission['reason']);
        if (! $permission['allowed']) {
            throw new AiCoreException('role_not_allowed', 'AI Core tool is not allowed for this role.');
        }

        $usageDecision = $this->usage->decision($toolSlug, $user, $context);
        if (! $usageDecision['allowed']) {
            $this->audit->event('usage.denied', array_merge($context, [
                'selected_limit_id' => $usageDecision['selected_limit_id'],
                'role' => $usageDecision['role'],
                'roles' => $usageDecision['roles'],
                'plan' => $usageDecision['plan'],
                'tool' => $usageDecision['tool'],
                'used_today' => $usageDecision['used_today'],
                'daily_limit' => $usageDecision['daily_limit'],
                'used_month' => $usageDecision['used_month'],
                'monthly_limit' => $usageDecision['monthly_limit'],
                'cooldown_seconds' => $usageDecision['cooldown_seconds'],
                'reason_code' => $usageDecision['reason'],
            ]), $user, $toolSlug, false, $usageDecision['reason']);
            throw new AiCoreException('limit_exceeded', 'AI Core usage limit exceeded for this tool.');
        }

        $readiness = $this->readiness->check($toolSlug);
        $this->audit->event('readiness.checked', array_merge($context, [
            'reason_code' => $readiness['reason_code'],
            'message' => $readiness['message'],
        ]), $user, $toolSlug, $readiness['ready'], $readiness['reason_code']);

        if (! $readiness['ready']) {
            throw new AiCoreException($readiness['reason_code'] ?? 'dependency_degraded', $readiness['message']);
        }

        $this->audit->event(
            'execution_contract.passed',
            $context['execution_contract'],
            $user,
            $toolSlug,
            true,
        );

        $endpoint = $this->resolveEndpoint((string) $tool['endpoint'], $payload, $context);
        $this->assertFinalEndpoint((string) $tool['endpoint']);
        $requestId = $this->audit->startRequest($toolSlug, $endpoint, $payload, $context, $user);

        try {
            $response = strtoupper((string) $context['method']) === 'GET'
                ? $this->get($endpoint, $toolSlug)
                : $this->post($endpoint, $payload, $toolSlug);

            $this->audit->finishRequest($requestId, true, $response, 200);
            $this->storeToolResult($requestId, $toolSlug, $response, $context, $user);

            return $response;
        } catch (\Throwable $exception) {
            $reasonCode = $exception instanceof AiCoreException ? $exception->reasonCode() : 'backend_unavailable';
            $message = $this->safeExceptionMessage($exception);
            $this->audit->finishRequest($requestId, false, ['error' => $message, 'reason_code' => $reasonCode], null, $message);
            $this->audit->event('request.failed', array_merge($context, [
                'error' => $message,
                'reason_code' => $reasonCode,
            ]), $user, $toolSlug, false, $reasonCode);

            if ($exception instanceof AiCoreException) {
                throw $exception;
            }

            throw new AiCoreException($reasonCode, $message, previous: $exception);
        }
    }

    public function chatGeneral(array $payload, array $context = [], ?Authenticatable $user = null): array
    {
        return $this->executeTool('general_chat', $payload, array_merge(['plugin' => $payload['plugin'] ?? 'unknown'], $context), $user);
    }

    public function chatCoding(array $payload, array $context = [], ?Authenticatable $user = null): array
    {
        return $this->executeTool('coding_chat', $payload, array_merge(['plugin' => $payload['plugin'] ?? 'professional-programmer'], $context), $user);
    }

    public function classifyIntent(array $payload, array $context = [], ?Authenticatable $user = null): array
    {
        return $this->executeTool('intent_classify', $payload, array_merge(['plugin' => $payload['plugin'] ?? 'unknown'], $context), $user);
    }

    public function generateImage(array $payload, array $context = [], ?Authenticatable $user = null): array
    {
        [$payload, $context] = $this->prepareImageGenerationPayload($payload, $context, false, $user);

        return $this->executeTool('image_generate', $payload, array_merge(['plugin' => $payload['plugin'] ?? 'unknown'], $context), $user);
    }

    public function generateFastImage(array $payload, array $context = [], ?Authenticatable $user = null): array
    {
        [$payload, $context] = $this->prepareImageGenerationPayload($payload, $context, true, $user);

        return $this->executeTool('image_fast_generate', $payload, array_merge(['plugin' => $payload['plugin'] ?? 'unknown'], $context), $user);
    }

    public function imageJobStatus(string $jobId, array $context = [], ?Authenticatable $user = null): array
    {
        $response = $this->executeTool('image_job_poll', ['job_id' => $jobId], array_merge(['method' => 'GET', 'plugin' => 'ai-assistant', 'job_id' => $jobId], $context), $user);
        $returnedJobId = (string) (data_get($response, 'data.job_id') ?? '');

        if ($returnedJobId !== '' && $returnedJobId !== $jobId) {
            $this->audit->event('image.job.mismatch', [
                'requested_job_id' => $jobId,
                'returned_job_id' => $returnedJobId,
                'plugin' => $context['plugin'] ?? 'ai-assistant',
            ], $user, 'image_job_poll', false, 'job_result_mismatch');

            throw new AiCoreException('backend_unavailable', 'AI Core image job response did not match the requested job.');
        }

        return $response;
    }

    public function analyzeVision(array $payload, array $context = [], ?Authenticatable $user = null): array
    {
        return $this->executeTool('vision_analyze', $payload, array_merge(['plugin' => $payload['plugin'] ?? 'unknown'], $context), $user);
    }

    public function searchArtwork(array $payload, array $context = [], ?Authenticatable $user = null): array
    {
        return $this->executeTool('artwork_search', $payload, array_merge(['plugin' => $payload['plugin'] ?? 'unknown'], $context), $user);
    }

    public function ragSearch(array $payload, array $context = [], ?Authenticatable $user = null): array
    {
        return $this->executeTool('rag_search', $payload, array_merge(['plugin' => $payload['plugin'] ?? 'unknown'], $context), $user);
    }

    public function textEmbed(array $payload, array $context = [], ?Authenticatable $user = null): array
    {
        return $this->executeTool('text_embed', $payload, array_merge(['plugin' => $payload['plugin'] ?? 'ai-core'], $context), $user);
    }

    public function ragIndex(array $payload, array $context = [], ?Authenticatable $user = null): array
    {
        return $this->executeTool('rag_index', $payload, array_merge(['plugin' => $payload['plugin'] ?? 'unknown'], $context), $user);
    }

    public function artworkIndex(array $payload, array $context = [], ?Authenticatable $user = null): array
    {
        return $this->executeTool('artwork_index', $payload, array_merge(['plugin' => $payload['plugin'] ?? 'unknown'], $context), $user);
    }

    public function trainingJobCreate(array $payload, array $context = [], ?Authenticatable $user = null): array
    {
        return $this->executeTool('training_job_create', $payload, array_merge(['plugin' => 'professional-programmer'], $context), $user);
    }

    public function trainingJobStatus(array $context = [], ?Authenticatable $user = null): array
    {
        return $this->executeTool('training_job_status', [], array_merge(['method' => 'GET', 'plugin' => 'professional-programmer'], $context), $user);
    }

    public function trainingJobPoll(string $jobId, array $context = [], ?Authenticatable $user = null): array
    {
        return $this->executeTool('training_job_poll', ['job_id' => $jobId], array_merge(['method' => 'GET', 'plugin' => 'professional-programmer'], $context), $user);
    }

    /**
     * @return array<string, mixed>
     */
    public function health(): array
    {
        return $this->get('/health', 'health_check');
    }

    /**
     * @return array<string, mixed>
     */
    public function models(): array
    {
        return $this->get('/models', 'models_sync');
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function post(string $endpoint, array $payload, string $toolSlug): array
    {
        $response = $this->baseRequest($toolSlug)->post($this->settings->gatewayBaseUrl().$endpoint, $payload);

        return $this->validatedJson($response, $endpoint);
    }

    /**
     * @return array<string, mixed>
     */
    private function get(string $endpoint, string $toolSlug): array
    {
        $response = $this->baseRequest($toolSlug)->get($this->settings->gatewayBaseUrl().$endpoint);

        return $this->validatedJson($response, $endpoint);
    }

    private function baseRequest(string $toolSlug): \Illuminate\Http\Client\PendingRequest
    {
        $baseUrl = $this->settings->gatewayBaseUrl();
        if ($baseUrl === '') {
            throw new AiCoreException('gateway_unreachable', 'AI Core Gateway base URL is not configured.');
        }

        $apiKey = $this->settings->gatewayApiKey();

        return Http::timeout($this->settings->timeout($toolSlug))
            ->retry(2, 250)
            ->acceptJson()
            ->when($apiKey !== '', fn ($request) => $request->withHeaders(['X-AI-API-KEY' => $apiKey]));
    }

    /**
     * @return array<string, mixed>
     */
    private function validatedJson(Response $response, string $endpoint): array
    {
        if (! $response->successful()) {
            throw new AiCoreException('backend_unavailable', 'AI Gateway request failed with HTTP '.$response->status().'.');
        }

        $data = $response->json();
        if (! is_array($data)) {
            throw new AiCoreException('backend_unavailable', 'AI Gateway returned invalid JSON.');
        }

        return $data;
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     */
    private function resolveEndpoint(string $endpoint, array $payload, array $context): string
    {
        if (str_contains($endpoint, '{job_id}')) {
            $jobId = (string) ($payload['job_id'] ?? $context['job_id'] ?? '');
            if ($jobId === '') {
                throw new AiCoreException('dependency_degraded', 'AI Core tool endpoint requires job_id.');
            }

            return str_replace('{job_id}', rawurlencode($jobId), $endpoint);
        }

        return $endpoint;
    }

    private function assertFinalEndpoint(string $endpoint): void
    {
        if (! in_array($endpoint, self::FINAL_ENDPOINTS, true)) {
            throw new AiCoreException('tool_disabled', 'AI Core blocked deprecated or unknown AI Gateway endpoint.');
        }
    }

    private function safeExceptionMessage(\Throwable $exception): string
    {
        if ($exception instanceof AiCoreException) {
            return $exception->getMessage();
        }

        return 'AI Core tool execution failed.';
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @return array{0: array<string, mixed>, 1: array<string, mixed>}
     */
    private function prepareImageGenerationPayload(array $payload, array $context, bool $fast, ?Authenticatable $user): array
    {
        $normalized = $this->imagePrompts->normalize($payload, $fast);
        $finalPayload = $normalized['payload'];
        $context['plugin'] = $context['plugin'] ?? $payload['plugin'] ?? 'ai-assistant';

        $context['image_prompt'] = $normalized['metadata'];
        $context['original_prompt'] = $normalized['metadata']['original_prompt'];
        $context['normalized_prompt'] = $normalized['metadata']['normalized_prompt'];
        $context['final_prompt'] = $normalized['metadata']['final_prompt'];

        $this->audit->event('image.prompt.normalized', array_merge($context, [
            'tool' => $fast ? 'image_fast_generate' : 'image_generate',
            'original_prompt' => $normalized['metadata']['original_prompt'],
            'clean_prompt' => $normalized['metadata']['clean_prompt'],
            'normalized_prompt' => $normalized['metadata']['normalized_prompt'],
            'final_prompt' => $normalized['metadata']['final_prompt'],
            'negative_prompt' => $normalized['metadata']['negative_prompt'],
            'width' => $normalized['metadata']['width'],
            'height' => $normalized['metadata']['height'],
            'steps' => $normalized['metadata']['steps'],
            'seed' => $normalized['metadata']['seed'],
            'dropped_payload_keys' => $normalized['metadata']['dropped_payload_keys'],
        ]), $user, $fast ? 'image_fast_generate' : 'image_generate', true);

        return [$finalPayload, $context];
    }

    /**
     * @param array<string, mixed> $response
     * @param array<string, mixed> $context
     */
    private function storeToolResult(?int $requestId, string $toolSlug, array $response, array $context, ?Authenticatable $user): void
    {
        if (! Schema::hasTable('ai_core_tool_results')) {
            return;
        }

        $resultType = match ($toolSlug) {
            'image_generate', 'image_fast_generate', 'image_job_poll' => 'image',
            'vision_analyze' => 'vision',
            'rag_search' => 'rag',
            'artwork_search' => 'artwork_similarity',
            default => 'message',
        };

        DB::table('ai_core_tool_results')->insert([
            'request_id' => $requestId,
            'conversation_id' => $context['conversation_id'] ?? null,
            'user_id' => $user?->getAuthIdentifier(),
            'tool_slug' => $toolSlug,
            'result_type' => $resultType,
            'status' => 'stored',
            'source_url' => data_get($response, 'data.image_url') ?? data_get($response, 'data.images.0.url'),
            'result_payload' => json_encode($response, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        if (Schema::hasTable('ai_core_jobs') && in_array($toolSlug, ['image_generate', 'image_fast_generate'], true)) {
            DB::table('ai_core_jobs')->insert([
                'job_uuid' => (string) Str::uuid(),
                'external_job_id' => data_get($response, 'data.job_id'),
                'tool_slug' => $toolSlug,
                'user_id' => $user?->getAuthIdentifier(),
                'plugin_slug' => $context['plugin'] ?? $context['plugin_slug'] ?? null,
                'status' => (string) (data_get($response, 'data.status') ?? 'submitted'),
                'payload' => json_encode([
                    'prompt' => $context['final_prompt'] ?? data_get($response, 'data.prompt'),
                    'original_prompt' => $context['original_prompt'] ?? null,
                    'normalized_prompt' => $context['normalized_prompt'] ?? null,
                    'negative_prompt' => data_get($response, 'data.negative_prompt'),
                    'width' => data_get($response, 'data.width'),
                    'height' => data_get($response, 'data.height'),
                    'steps' => data_get($response, 'data.steps'),
                    'seed' => data_get($response, 'data.seed'),
                ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                'result' => json_encode($response, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        if (Schema::hasTable('ai_core_jobs') && $toolSlug === 'image_job_poll') {
            $jobId = (string) (data_get($response, 'data.job_id') ?? $context['job_id'] ?? '');
            if ($jobId !== '') {
                DB::table('ai_core_jobs')
                    ->where('external_job_id', $jobId)
                    ->update([
                        'status' => (string) (data_get($response, 'data.status') ?? 'updated'),
                        'result' => json_encode($response, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                        'error_message' => data_get($response, 'data.error_message') ?? data_get($response, 'data.error'),
                        'finished_at' => data_get($response, 'data.status') === 'completed' ? now() : null,
                        'updated_at' => now(),
                    ]);
            }
        }
    }
}
