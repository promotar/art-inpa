<?php

namespace Modules\AiCore;

class AiIntentRouter
{
    public function __construct(private readonly AiGatewayClient $gateway)
    {
        //
    }

    /**
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function classify(string $message, array $context = []): array
    {
        if ($this->isImageGenerationRequest($message, $context)) {
            return [
                'intent' => 'generate_image',
                'tool_slug' => 'image_generate',
                'confidence' => 1.0,
                'requires_confirmation' => false,
                'reason' => 'ai_core_hard_match_image_generation',
            ];
        }

        return $this->gateway->classifyIntent([
            'message' => $message,
            'plugin' => $context['plugin'] ?? 'unknown',
            'context' => $context,
            'has_image' => (bool) ($context['has_image'] ?? false),
            'allowed_intents' => $context['allowed_intents'] ?? [],
        ], $context);
    }

    /**
     * @param array<string, mixed> $context
     */
    private function isImageGenerationRequest(string $message, array $context): bool
    {
        $action = strtolower(trim((string) ($context['action'] ?? '')));
        if (in_array($action, ['generate_image', 'image_generate', 'create_image', 'design_image'], true)) {
            return true;
        }

        $normalized = mb_strtolower(trim($message));

        foreach ([
            'اعمل صورة',
            'اعملي صورة',
            'اعطني صورة',
            'اعطيني صورة',
            'صمم صورة',
            'صممي صورة',
            'ارسم',
            'ارسمي',
            'ولد صورة',
            'ولّد صورة',
            'انشئ صورة',
            'أنشئ صورة',
            'generate image',
            'create image',
            'design image',
            'draw',
        ] as $trigger) {
            if (str_contains($normalized, mb_strtolower($trigger))) {
                return true;
            }
        }

        return false;
    }
}
