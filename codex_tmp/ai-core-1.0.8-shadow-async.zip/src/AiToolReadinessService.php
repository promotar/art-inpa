<?php

namespace Modules\AiCore;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Schema;

class AiToolReadinessService
{
    /**
     * @var array<string, mixed>|null
     */
    private ?array $currentHealthCache = null;

    public function __construct(
        private readonly AiCoreSettings $settings,
    ) {
        //
    }

    /**
     * @return array{ready: bool, reason_code: string|null, message: string}
     */
    public function check(string $toolSlug): array
    {
        $toolSlug = AiToolSlug::canonical($toolSlug);

        if (! $this->aiCoreEnabled()) {
            return $this->deny('tool_disabled', 'AI Core is disabled.');
        }

        if ($this->settings->gatewayBaseUrl() === '' || $this->settings->gatewayApiKey() === '') {
            return $this->deny('gateway_unreachable', 'AI Gateway is not configured.');
        }

        $health = $this->currentHealth();

        if (! $this->gatewayReachable($health)) {
            return $this->deny('gateway_unreachable', 'AI Gateway is unreachable.');
        }

        return match ($toolSlug) {
            'image_generate', 'image_fast_generate' => $this->requireHealthy($health, ['comfyui_status']),
            'rag_search', 'rag_index', 'text_embed' => $this->requireHealthy($health, ['embedding_worker_status', 'qdrant_status', 'production_semantic']),
            'vision_analyze' => $this->requireHealthy($health, ['vision_worker_status']),
            'general_chat', 'intent_classify' => $this->requireHealthy($health, ['ollama_status']),
            'coding_chat', 'training_job_create', 'training_job_status', 'training_job_poll' => $this->requireHealthy($health, ['ollama_status']),
            default => ['ready' => true, 'reason_code' => null, 'message' => 'Tool dependencies are ready.'],
        };
    }

    private function aiCoreEnabled(): bool
    {
        $values = $this->settings->values();

        foreach (['enabled', 'ai_core_enabled'] as $key) {
            if (array_key_exists($key, $values)) {
                return (bool) $values[$key];
            }
        }

        return true;
    }

    /**
     * @param array<string, mixed> $health
     */
    private function gatewayReachable(array $health): bool
    {
        if ($this->state($health['gateway_status'] ?? null) === 'healthy') {
            return true;
        }

        try {
            $response = Http::timeout(5)
                ->acceptJson()
                ->when($this->settings->gatewayApiKey() !== '', fn ($request) => $request->withHeaders([
                    'X-AI-API-KEY' => $this->settings->gatewayApiKey(),
                ]))
                ->get($this->settings->gatewayBaseUrl().'/health');

            return $response->successful();
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * @return array<string, mixed>
     */
    private function currentHealth(): array
    {
        if ($this->currentHealthCache !== null) {
            return $this->currentHealthCache;
        }

        try {
            $response = Http::timeout(8)
                ->acceptJson()
                ->when($this->settings->gatewayApiKey() !== '', fn ($request) => $request->withHeaders([
                    'X-AI-API-KEY' => $this->settings->gatewayApiKey(),
                ]))
                ->get($this->settings->gatewayBaseUrl().'/health');

            $data = $response->json();
            if ($response->successful() && is_array($data)) {
                return $this->currentHealthCache = $this->summarizeHealth($data);
            }
        } catch (\Throwable) {
            //
        }

        return $this->currentHealthCache = $this->latestHealth();
    }

    /**
     * @param array<string, mixed> $health
     * @return array<string, mixed>
     */
    private function summarizeHealth(array $health): array
    {
        $source = data_get($health, 'data', $health);

        return [
            'gateway_status' => data_get($source, 'gateway.ok', data_get($source, 'gateway.status', data_get($source, 'status', data_get($source, 'ok')))),
            'ollama_status' => data_get($source, 'ollama.ok', data_get($source, 'ollama.status', data_get($source, 'services.ollama', data_get($source, 'ollama')))),
            'comfyui_status' => data_get($source, 'comfyui.ok', data_get($source, 'comfyui.status', data_get($source, 'services.comfyui', data_get($source, 'comfyui')))),
            'qdrant_status' => data_get($source, 'qdrant.ok', data_get($source, 'qdrant.status', data_get($source, 'services.qdrant', data_get($source, 'qdrant')))),
            'vision_worker_status' => data_get($source, 'vision_worker.ok', data_get($source, 'vision_worker.status', data_get($source, 'services.vision_worker', data_get($source, 'vision_worker')))),
            'embedding_worker_status' => data_get($source, 'embedding_worker.ok', data_get($source, 'embedding_worker.status', data_get($source, 'services.embedding_worker', data_get($source, 'embedding_worker')))),
            'production_semantic' => data_get($source, 'production_semantic', data_get($source, 'embedding_worker.data.production_semantic')),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function latestHealth(): array
    {
        if (! Schema::hasTable('ai_core_audit_logs')) {
            return [];
        }

        $row = DB::table('ai_core_audit_logs')
            ->where('event_type', 'ai-core.health.checked')
            ->latest('id')
            ->first();

        if (! $row) {
            return [];
        }

        $metadata = is_string($row->metadata ?? null) ? json_decode($row->metadata, true) : [];

        return is_array($metadata) && is_array($metadata['health'] ?? null) ? $metadata['health'] : [];
    }

    /**
     * @param array<string, mixed> $health
     * @param array<int, string> $requiredKeys
     * @return array{ready: bool, reason_code: string|null, message: string}
     */
    private function requireHealthy(array $health, array $requiredKeys): array
    {
        foreach ($requiredKeys as $key) {
            $state = $this->state($health[$key] ?? null);
            if ($state === 'failed') {
                return $this->deny('backend_unavailable', $this->label($key).' is unavailable.');
            }

            if ($state !== 'healthy') {
                return $this->deny('dependency_degraded', $this->label($key).' is not ready.');
            }
        }

        return ['ready' => true, 'reason_code' => null, 'message' => 'Tool dependencies are ready.'];
    }

    private function state(mixed $value): string
    {
        if ($value === null || $value === '') {
            return 'unknown';
        }

        if (is_bool($value)) {
            return $value ? 'healthy' : 'failed';
        }

        if (is_array($value)) {
            return $this->state(data_get($value, 'status', data_get($value, 'ok')));
        }

        $status = strtolower(trim((string) $value));

        return match (true) {
            in_array($status, ['1', 'true', 'ok', 'up', 'ready', 'healthy', 'running', 'available', 'connected'], true) => 'healthy',
            in_array($status, ['0', 'false', 'failed', 'failure', 'error', 'down', 'offline', 'unhealthy'], true) => 'failed',
            in_array($status, ['degraded', 'partial', 'warning', 'warn', 'unknown'], true) => 'degraded',
            default => 'unknown',
        };
    }

    private function label(string $key): string
    {
        return match ($key) {
            'comfyui_status' => 'ComfyUI',
            'embedding_worker_status' => 'Embedding worker',
            'qdrant_status' => 'Qdrant',
            'vision_worker_status' => 'Vision worker',
            'ollama_status' => 'Ollama',
            default => $key,
        };
    }

    /**
     * @return array{ready: false, reason_code: string, message: string}
     */
    private function deny(string $reasonCode, string $message): array
    {
        return [
            'ready' => false,
            'reason_code' => $reasonCode,
            'message' => $message,
        ];
    }
}
