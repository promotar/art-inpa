<?php

namespace Modules\AiCore;

class AiPlanValidator
{
    private const ACTIONS = ['answer_user', 'execute_tool', 'ask_clarification', 'plugin_action', 'refuse'];
    private const PREVIOUS_RESULT_RELEVANCE = ['none', 'related', 'wrong_tool', 'weak_prompt', 'failed_execution', 'unclear'];
    private const RISK_LEVELS = ['low', 'medium', 'high'];

    /**
     * @param array<string, mixed> $input
     * @param array<int, string> $availableTools
     * @return array<string, mixed>
     */
    public function validate(array $input, array $availableTools = []): array
    {
        $action = $this->enum((string) ($input['action'] ?? ''), self::ACTIONS, 'ask_clarification');
        $recommendedTool = $input['recommended_tool'] ?? null;
        if (! is_string($recommendedTool) || trim($recommendedTool) === '') {
            $recommendedTool = null;
        } else {
            $recommendedTool = AiToolSlug::canonical(trim($recommendedTool));
            if ($availableTools !== [] && ! in_array($recommendedTool, $availableTools, true)) {
                $recommendedTool = null;
            }
        }

        $confidence = $this->floatInRange($input['tool_confidence'] ?? 0.0, 0.0, 1.0);
        $toolPayload = is_array($input['tool_payload'] ?? null) ? $this->sanitizePayload($input['tool_payload']) : [];

        return [
            'input_language' => $this->text($input['input_language'] ?? '', 40),
            'user_response_language' => $this->text($input['user_response_language'] ?? '', 40),
            'semantic_intent' => $this->text($input['semantic_intent'] ?? '', 120),
            'action' => $action,
            'recommended_tool' => $recommendedTool,
            'tool_confidence' => $confidence,
            'needs_clarification' => (bool) ($input['needs_clarification'] ?? false),
            'clarification_question' => $this->nullableText($input['clarification_question'] ?? null, 300),
            'is_correction_or_dissatisfaction' => (bool) ($input['is_correction_or_dissatisfaction'] ?? false),
            'previous_result_relevance' => $this->enum((string) ($input['previous_result_relevance'] ?? ''), self::PREVIOUS_RESULT_RELEVANCE, 'none'),
            'should_reuse_previous_context' => (bool) ($input['should_reuse_previous_context'] ?? false),
            'compiled_prompt_en' => $this->nullableText($input['compiled_prompt_en'] ?? null, 1200),
            'tool_payload' => $toolPayload,
            'expected_result_type' => $this->text($input['expected_result_type'] ?? '', 80),
            'risk_level' => $this->enum((string) ($input['risk_level'] ?? ''), self::RISK_LEVELS, 'low'),
            'decision_summary' => $this->text($input['decision_summary'] ?? '', 600),
        ];
    }

    public function fallbackPlan(string $summary = 'Planner output was unavailable. Runtime execution used the existing AI Core flow.'): array
    {
        return $this->validate([
            'action' => 'ask_clarification',
            'previous_result_relevance' => 'unclear',
            'risk_level' => 'low',
            'decision_summary' => $summary,
        ]);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function sanitizePayload(array $payload): array
    {
        $safe = [];
        foreach ($payload as $key => $value) {
            $key = $this->text($key, 80);
            if ($key === '') {
                continue;
            }

            $lower = strtolower($key);
            if (str_contains($lower, 'api_key') || str_contains($lower, 'token') || str_contains($lower, 'password') || str_contains($lower, 'secret')) {
                $safe[$key] = '[redacted]';
                continue;
            }

            if (is_array($value)) {
                $safe[$key] = $this->sanitizePayload(array_slice($value, 0, 30, true));
                continue;
            }

            if (is_bool($value) || is_int($value) || is_float($value) || $value === null) {
                $safe[$key] = $value;
                continue;
            }

            $safe[$key] = $this->text($value, 1000);
        }

        return $safe;
    }

    /**
     * @param array<int, string> $allowed
     */
    private function enum(string $value, array $allowed, string $default): string
    {
        return in_array($value, $allowed, true) ? $value : $default;
    }

    private function floatInRange(mixed $value, float $min, float $max): float
    {
        $number = is_numeric($value) ? (float) $value : $min;

        return max($min, min($max, $number));
    }

    private function nullableText(mixed $value, int $limit): ?string
    {
        if ($value === null) {
            return null;
        }

        $text = $this->text($value, $limit);

        return $text === '' ? null : $text;
    }

    private function text(mixed $value, int $limit): string
    {
        $text = is_scalar($value) ? trim((string) $value) : '';
        $text = preg_replace('/\s+/u', ' ', $text) ?: $text;

        return mb_substr($text, 0, $limit);
    }
}
