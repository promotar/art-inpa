<?php

namespace Modules\AiCore;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\ValidationException;
use Throwable;

class AiCoreAdminController extends Controller
{
    private const UPDATE_PERMISSION = 'ai-core.settings.update';
    private const LEGACY_AI_ASSISTANT_GATEWAY_SETTINGS = [
        'ai_assistant_ai_gateway_url',
        'ai_assistant_chat_endpoint',
        'ai_assistant_api_key',
    ];

    public function index(
        Request $request,
        AiModelRegistry $models,
        AiToolRegistry $tools,
        AiCoreSettings $settings,
        AiServerSyncService $sync,
        AiUsageLimiter $usageLimiter,
        AiToolReadinessService $readiness,
        AiAgentRuntimeConfig $agentRuntimeConfig,
    ): View {
        $usageFilters = [
            'role_slug' => (string) $request->query('usage_role_slug', ''),
            'plan_slug' => (string) $request->query('usage_plan_slug', ''),
            'tool_slug' => (string) $request->query('usage_tool_slug', ''),
        ];

        return view('ai-core::admin.index', [
            'settings' => $settings->publicValues(),
            'models' => $models->all(),
            'tools' => $tools->all(),
            'datasets' => $this->datasets(),
            'usageLimits' => $usageLimiter->editableLimits($usageFilters),
            'agentRuntimeBindings' => $agentRuntimeConfig->bindings(),
            'usageFilters' => $usageFilters,
            'healthSnapshot' => $sync->freshHealthSnapshot($request->user()),
            'toolReadiness' => $this->toolReadiness($readiness),
            'requestCount' => Schema::hasTable('ai_core_requests') ? DB::table('ai_core_requests')->count() : 0,
            'auditCount' => Schema::hasTable('ai_core_audit_logs') ? DB::table('ai_core_audit_logs')->count() : 0,
            'aiCoreSettingGroups' => $aiCoreSettingGroups = $this->aiCoreSettingGroups(),
            'pluginSettingsOverview' => $this->pluginSettingsOverview(),
            'compatibilityChecks' => $this->compatibilityChecks(),
            'settingsStats' => $this->settingsStats($aiCoreSettingGroups),
            'canUpdateSettings' => $this->canUpdateSettings($request),
        ]);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function toolReadiness(AiToolReadinessService $readiness): array
    {
        $tools = [
            'image_generate' => 'gateway + comfyui',
            'image_fast_generate' => 'gateway + comfyui',
            'rag_search' => 'gateway + qdrant + embedding_worker + production_semantic',
            'vision_analyze' => 'gateway + vision_worker',
            'general_chat' => 'gateway + ollama',
            'coding_chat' => 'gateway + ollama',
        ];

        return collect($tools)
            ->map(function (string $dependencies, string $tool) use ($readiness): array {
                $check = $readiness->check($tool);

                return [
                    'tool' => $tool,
                    'dependencies' => $dependencies,
                    'ready' => (bool) ($check['ready'] ?? false),
                    'reason_code' => $check['reason_code'] ?? null,
                    'message' => $check['message'] ?? '',
                ];
            })
            ->values()
            ->all();
    }

    public function updateSettings(
        Request $request,
        AiCoreSettings $aiCoreSettings,
    ): RedirectResponse {
        abort_unless($this->canUpdateSettings($request), 403);

        $request->validate([
            'ai_core_settings' => ['nullable', 'array'],
        ]);

        $aiCoreInput = $this->editableAiCoreSettingsInput((array) $request->input('ai_core_settings', []));

        if ($aiCoreInput !== []) {
            $aiCoreSettings->update(
                $aiCoreInput,
                $request->user()?->id,
                'admin.plugins.ai-core.settings',
            );
        }

        return back()->with('status', 'AI Core settings saved successfully.');
    }

    public function syncFromServer(Request $request, AiServerSyncService $sync): RedirectResponse
    {
        abort_unless($this->canUpdateSettings($request), 403);

        $snapshot = $sync->sync($request->user());

        return back()->with(
            $snapshot['ok'] ? 'status' : 'error',
            $snapshot['ok'] ? 'AI Core synced from AI Server successfully.' : 'AI Core sync failed: '.($snapshot['error'] ?? 'unknown error')
        );
    }

    public function updateUsageLimits(Request $request, AiUsageLimiter $usageLimiter): RedirectResponse
    {
        abort_unless($this->canUpdateSettings($request), 403);

        $request->validate([
            'limits' => ['nullable', 'array'],
        ]);

        $usageLimiter->updateLimits((array) $request->input('limits', []));

        return back()->with('status', 'AI Core usage limits saved successfully.');
    }

    public function updateAgentBindings(Request $request, AiAgentRuntimeConfig $agentRuntimeConfig): RedirectResponse
    {
        abort_unless($this->canUpdateSettings($request), 403);

        $request->validate([
            'bindings' => ['nullable', 'array'],
        ]);

        $agentRuntimeConfig->updateBindings((array) $request->input('bindings', []));

        return back()->with('status', 'AI Core Agent Runtime bindings saved successfully.');
    }

    public function indexDataset(Request $request, AiGatewayClient $gateway, string $dataset): RedirectResponse
    {
        return $this->runDatasetIndexAction($request, $gateway, $dataset, false);
    }

    public function reindexDataset(Request $request, AiGatewayClient $gateway, string $dataset): RedirectResponse
    {
        return $this->runDatasetIndexAction($request, $gateway, $dataset, true);
    }

    public function clearDatasetIndex(Request $request, string $dataset): RedirectResponse
    {
        abort_unless($this->canUpdateSettings($request), 403);

        if (! Schema::hasTable('ai_core_datasets')) {
            return back()->with('error', 'AI Core datasets table is missing.');
        }

        DB::table('ai_core_datasets')
            ->where('slug', $dataset)
            ->update($this->datasetUpdates([
                'indexing_status' => 'not_indexed',
                'chunks_count' => 0,
                'last_error' => null,
                'last_indexed_at' => null,
                'updated_at' => now(),
            ]));

        return back()->with('status', 'Dataset index state cleared.');
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function aiCoreSettingGroups(): array
    {
        if (! Schema::hasTable('ai_core_settings')) {
            return [];
        }

        return $this->groupSettings($this->aiCoreSettingsRows());
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function pluginSettingsOverview(): array
    {
        $settings = collect();

        if (Schema::hasTable('platform_settings')) {
            $settings = $settings->merge($this->platformSettingsRows());
        }

        if (Schema::hasTable('ai_core_settings')) {
            $settings = $settings->merge($this->aiCoreSettingsRows());
        }

        return $settings
            ->reject(fn (array $setting): bool => in_array($setting['setting_key'] ?? '', self::LEGACY_AI_ASSISTANT_GATEWAY_SETTINGS, true))
            ->sortBy([
                ['module', 'asc'],
            ])
            ->groupBy(fn (array $setting): string => $setting['module'])
            ->map(function (Collection $rows): array {
                $first = $rows->first();
                $module = (string) ($first['module'] ?? 'core');
                $activeCount = $rows->where('status', 'active')->count();

                return [
                    'module' => $module,
                    'plugin_name' => $this->pluginDisplayName($module),
                    'count' => $rows->count(),
                    'editable_count' => $rows->where('editable', true)->count(),
                    'sensitive_count' => $rows->where('sensitive_flag', true)->count(),
                    'status' => $activeCount > 0 ? 'active' : 'inactive',
                    'settings_url' => $this->settingsUrlForModule($module),
                ];
            })
            ->values()
            ->all();
    }

    /**
     * @param  Collection<int, array<string, mixed>>  $settings
     * @return array<int, array<string, mixed>>
     */
    private function groupSettings(Collection $settings): array
    {
        return $settings
            ->sortBy([
                ['module', 'asc'],
                ['group_key', 'asc'],
                ['sort_order', 'asc'],
                ['setting_key', 'asc'],
            ])
            ->groupBy(fn (array $setting): string => $setting['module'].'|'.$setting['group_key'])
            ->map(function (Collection $rows): array {
                $first = $rows->first();

                return [
                    'module' => $first['module'] ?? 'ai-core',
                    'group_key' => $first['group_key'] ?? 'general',
                    'category' => $first['category'] ?? 'general',
                    'settings' => $rows->values()->all(),
                    'count' => $rows->count(),
                    'editable_count' => $rows->where('editable', true)->count(),
                    'sensitive_count' => $rows->where('sensitive_flag', true)->count(),
                ];
            })
            ->values()
            ->all();
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function datasets(): array
    {
        if (! Schema::hasTable('ai_core_datasets')) {
            return [];
        }

        return DB::table('ai_core_datasets')
            ->orderBy('slug')
            ->get()
            ->map(function (object $row): array {
                $dataset = (array) $row;
                foreach (['allowed_roles', 'allowed_tools'] as $key) {
                    $dataset[$key] = is_string($dataset[$key] ?? null) ? (json_decode($dataset[$key], true) ?: []) : ($dataset[$key] ?? []);
                }

                return $dataset;
            })
            ->all();
    }

    private function runDatasetIndexAction(Request $request, AiGatewayClient $gateway, string $dataset, bool $force): RedirectResponse
    {
        abort_unless($this->canUpdateSettings($request), 403);

        if (! Schema::hasTable('ai_core_datasets')) {
            return back()->with('error', 'AI Core datasets table is missing.');
        }

        $row = DB::table('ai_core_datasets')->where('slug', $dataset)->first();
        if (! $row) {
            return back()->with('error', 'Dataset was not found.');
        }

        $documents = $this->ragDocumentsForDataset($dataset);
        if ($documents->isEmpty()) {
            DB::table('ai_core_datasets')->where('id', $row->id)->update($this->datasetUpdates([
                'indexing_status' => 'not_indexed',
                'last_error' => 'No RAG documents are registered for this dataset yet.',
                'updated_at' => now(),
            ]));

            return back()->with('error', 'No RAG documents are registered for this dataset yet.');
        }

        DB::table('ai_core_datasets')->where('id', $row->id)->update($this->datasetUpdates([
            'indexing_status' => 'indexing',
            'last_error' => null,
            'updated_at' => now(),
        ]));

        try {
            $chunksCount = 0;

            foreach ($documents as $document) {
                $response = $gateway->ragIndex(
                    $this->documentIndexPayload($row, $document, $force),
                    [
                        'plugin' => 'ai-core',
                        'admin_approved' => true,
                        'dataset_slug' => $dataset,
                        'source' => 'admin.plugins.ai-core.datasets.index',
                    ],
                    $request->user(),
                );

                $chunksCount += max(1, (int) (data_get($response, 'data.chunks_count') ?? data_get($response, 'chunks_count') ?? 1));

                DB::table('ai_core_rag_documents')->where('id', $document->id)->update($this->ragDocumentUpdates([
                    'indexing_status' => 'indexed',
                    'updated_at' => now(),
                ]));
            }

            DB::table('ai_core_datasets')->where('id', $row->id)->update($this->datasetUpdates([
                'indexing_status' => 'indexed',
                'chunks_count' => $chunksCount,
                'last_indexed_at' => now(),
                'last_error' => null,
                'updated_at' => now(),
            ]));

            return back()->with('status', 'Dataset indexing request completed.');
        } catch (Throwable $exception) {
            DB::table('ai_core_datasets')->where('id', $row->id)->update($this->datasetUpdates([
                'indexing_status' => 'failed',
                'last_error' => $exception->getMessage(),
                'updated_at' => now(),
            ]));

            return back()->with('error', 'Dataset indexing failed: '.$exception->getMessage());
        }
    }

    /**
     * @return Collection<int, object>
     */
    private function ragDocumentsForDataset(string $dataset): Collection
    {
        if (! Schema::hasTable('ai_core_rag_documents')) {
            return collect();
        }

        return DB::table('ai_core_rag_documents')
            ->where('dataset_slug', $dataset)
            ->where(function ($query): void {
                $query->whereNull('indexing_status')
                    ->orWhereIn('indexing_status', ['pending', 'failed', 'not_indexed', 'indexed']);
            })
            ->orderBy('id')
            ->get()
            ->filter(fn (object $document): bool => trim((string) ($document->content_excerpt ?? '')) !== '')
            ->values();
    }

    /**
     * @return array<string, mixed>
     */
    private function documentIndexPayload(object $dataset, object $document, bool $force): array
    {
        $metadata = is_string($document->metadata ?? null) ? json_decode($document->metadata, true) : [];
        $metadata = is_array($metadata) ? $metadata : [];

        $content = (string) ($document->content_excerpt ?? '');
        $documentId = (string) ($document->document_hash ?? '');
        if ($documentId === '') {
            $documentId = 'ai-core-rag-document-'.$document->id;
        }

        return [
            'dataset' => (string) $dataset->slug,
            'collection' => $dataset->qdrant_collection ?? $dataset->rag_collection ?? $dataset->slug,
            'document_id' => $documentId,
            'title' => (string) ($document->title ?? $documentId),
            'content' => $content,
            'text' => $content,
            'metadata' => array_merge($metadata, [
                'dataset_slug' => (string) $dataset->slug,
                'document_id' => $documentId,
                'document_row_id' => $document->id,
                'owner_plugin' => (string) ($dataset->owner_plugin ?? 'ai-core'),
            ]),
            'force' => $force,
        ];
    }

    /**
     * @param array<string, mixed> $updates
     * @return array<string, mixed>
     */
    private function datasetUpdates(array $updates): array
    {
        return collect($updates)
            ->filter(fn (mixed $value, string $key): bool => Schema::hasColumn('ai_core_datasets', $key))
            ->all();
    }

    /**
     * @param array<string, mixed> $updates
     * @return array<string, mixed>
     */
    private function ragDocumentUpdates(array $updates): array
    {
        return collect($updates)
            ->filter(fn (mixed $value, string $key): bool => Schema::hasColumn('ai_core_rag_documents', $key))
            ->all();
    }

    /**
     * @return Collection<int, array<string, mixed>>
     */
    private function platformSettingsRows(): Collection
    {
        $columns = $this->availableColumns('platform_settings', [
            'id',
            'group_key',
            'setting_key',
            'label',
            'type',
            'value',
            'default_value',
            'help_text',
            'description',
            'category',
            'module',
            'visibility_level',
            'admin_access_level',
            'editable',
            'required',
            'sensitive_flag',
            'public_exposure_allowed',
            'frontend_available',
            'cache_enabled',
            'cache_ttl',
            'ui_component',
            'ui_label',
            'allowed_values',
            'min_value',
            'max_value',
            'unit',
            'depends_on',
            'restart_required',
            'approval_required',
            'status',
            'version',
            'sort_order',
            'updated_at',
        ]);

        return DB::table('platform_settings')
            ->select($columns)
            ->get()
            ->map(fn (object $row): array => $this->normalizeSettingRow($row, 'platform_settings'));
    }

    /**
     * @return Collection<int, array<string, mixed>>
     */
    private function aiCoreSettingsRows(): Collection
    {
        $columns = $this->availableColumns('ai_core_settings', [
            'id',
            'key',
            'type',
            'value',
            'default_value',
            'description',
            'category',
            'module',
            'visibility_level',
            'admin_access_level',
            'editable',
            'required',
            'sensitive_flag',
            'public_exposure_allowed',
            'frontend_available',
            'cache_enabled',
            'cache_ttl',
            'ui_component',
            'ui_label',
            'allowed_values',
            'min_value',
            'max_value',
            'unit',
            'depends_on',
            'restart_required',
            'approval_required',
            'status',
            'version',
            'updated_at',
        ]);

        return DB::table('ai_core_settings')
            ->select($columns)
            ->get()
            ->map(fn (object $row): array => $this->normalizeSettingRow($row, 'ai_core_settings'));
    }

    /**
     * @param  array<string, mixed>  $submitted
     * @return array<string, mixed>
     */
    private function editableAiCoreSettingsInput(array $submitted): array
    {
        if (! Schema::hasTable('ai_core_settings')) {
            return [];
        }

        $input = [];

        DB::table('ai_core_settings')
            ->where('editable', true)
            ->where('status', 'active')
            ->get(['key', 'type', 'sensitive_flag'])
            ->each(function (object $setting) use ($submitted, &$input): void {
                $key = (string) $setting->key;

                if (! array_key_exists($key, $submitted)) {
                    return;
                }

                $value = $submitted[$key];
                if ((bool) ($setting->sensitive_flag ?? false) && trim((string) $value) === '') {
                    return;
                }

                $input[$key] = $this->validateSubmittedValue($value, (string) $setting->type, 'ai_core.'.$key);
            });

        return $input;
    }

    private function validateSubmittedValue(mixed $value, string $type, string $key): mixed
    {
        if (is_array($value)) {
            throw ValidationException::withMessages([$key => 'Array values are not supported for this setting.']);
        }

        $text = is_string($value) ? trim($value) : (string) $value;

        if (strlen($text) > 10000) {
            throw ValidationException::withMessages([$key => 'Setting value is too long.']);
        }

        if ($type === 'integer' && ! preg_match('/^-?\d+$/', $text)) {
            throw ValidationException::withMessages([$key => 'Setting value must be an integer.']);
        }

        if (in_array($type, ['decimal', 'float'], true) && ! is_numeric($text)) {
            throw ValidationException::withMessages([$key => 'Setting value must be numeric.']);
        }

        if ($type === 'json' && $text !== '' && json_decode($text, true) === null && json_last_error() !== JSON_ERROR_NONE) {
            throw ValidationException::withMessages([$key => 'Setting value must be valid JSON.']);
        }

        return $value;
    }

    /**
     * @param  array<int, string>  $columns
     * @return array<int, string>
     */
    private function availableColumns(string $table, array $columns): array
    {
        return collect($columns)
            ->filter(fn (string $column): bool => Schema::hasColumn($table, $column))
            ->values()
            ->all();
    }

    /**
     * @return array<string, mixed>
     */
    private function normalizeSettingRow(object $row, string $source): array
    {
        $key = (string) ($row->setting_key ?? $row->key ?? '');
        $group = (string) ($row->group_key ?? $row->category ?? 'ai_core');
        $module = (string) ($row->module ?? ($source === 'ai_core_settings' ? 'ai-core' : 'core'));
        $sensitive = (bool) ($row->sensitive_flag ?? false);

        return [
            'source_table' => $source,
            'id' => $row->id ?? null,
            'group_key' => $group !== '' ? $group : 'general',
            'setting_key' => $key,
            'label' => (string) ($row->ui_label ?? $row->label ?? $key),
            'type' => (string) ($row->type ?? 'string'),
            'value_summary' => $this->settingValueSummary($row->value ?? null, $sensitive),
            'form_value' => $sensitive ? '' : (string) ($row->value ?? $row->default_value ?? ''),
            'default_summary' => $this->settingValueSummary($row->default_value ?? null, $sensitive),
            'description' => (string) ($row->description ?? $row->help_text ?? ''),
            'category' => (string) ($row->category ?? $group),
            'module' => $module !== '' ? $module : 'core',
            'visibility_level' => (string) ($row->visibility_level ?? 'admin'),
            'admin_access_level' => (string) ($row->admin_access_level ?? 'admin'),
            'editable' => (bool) ($row->editable ?? false),
            'required' => (bool) ($row->required ?? false),
            'sensitive_flag' => $sensitive,
            'public_exposure_allowed' => (bool) ($row->public_exposure_allowed ?? false),
            'frontend_available' => (bool) ($row->frontend_available ?? false),
            'cache_enabled' => (bool) ($row->cache_enabled ?? false),
            'cache_ttl' => $row->cache_ttl ?? null,
            'ui_component' => (string) ($row->ui_component ?? $row->type ?? 'text'),
            'unit' => $row->unit ?? null,
            'restart_required' => (bool) ($row->restart_required ?? false),
            'approval_required' => (bool) ($row->approval_required ?? false),
            'status' => (string) ($row->status ?? 'active'),
            'version' => $row->version ?? 1,
            'sort_order' => (int) ($row->sort_order ?? 0),
            'updated_at' => $row->updated_at ?? null,
        ];
    }

    private function settingValueSummary(mixed $value, bool $sensitive): string
    {
        if ($sensitive) {
            return filled((string) $value) ? 'configured' : 'empty';
        }

        if ($value === null || $value === '') {
            return 'empty';
        }

        $text = is_scalar($value) ? (string) $value : json_encode($value);

        return str($text)->limit(80)->toString();
    }

    private function pluginDisplayName(string $module): string
    {
        return str($module)->replace(['-', '_'], ' ')->title()->toString();
    }

    private function settingsUrlForModule(string $module): ?string
    {
        $slug = str($module)->replace('_', '-')->toString();

        foreach ([
            'admin.plugins.'.$slug.'.settings',
            'admin.plugins.'.$slug.'.index',
        ] as $routeName) {
            if (Route::has($routeName)) {
                return route($routeName);
            }
        }

        return null;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function compatibilityChecks(): array
    {
        $requirements = [
            'ai-assistant' => [
                'tools' => ['general_chat', 'intent_classify', 'image_generate', 'image_fast_generate', 'image_job_poll', 'vision_analyze', 'rag_search', 'artwork_search'],
                'permissions' => ['ai-core.tools.execute'],
                'datasets' => ['assistant_public_knowledge'],
            ],
            'professional-programmer' => [
                'tools' => ['coding_chat', 'training_job_create', 'training_job_status', 'training_job_poll', 'rag_search'],
                'permissions' => ['professional-programmer.chat', 'professional-programmer.manage'],
                'datasets' => ['programmer_laravel_knowledge'],
            ],
        ];

        $toolRows = Schema::hasTable('ai_core_tools')
            ? DB::table('ai_core_tools')->get(['slug', 'enabled'])->keyBy('slug')
            : collect();
        $datasetRows = Schema::hasTable('ai_core_datasets')
            ? DB::table('ai_core_datasets')->get(['slug'])->keyBy('slug')
            : collect();
        $permissionRows = Schema::hasTable('permissions')
            ? DB::table('permissions')->pluck('name')->flip()
            : collect();
        $pluginRows = $this->installedPluginsBySlug();

        return collect($requirements)->map(function (array $requirement, string $plugin) use ($toolRows, $datasetRows, $permissionRows, $pluginRows): array {
            $missingTools = collect($requirement['tools'])
                ->filter(function (string $tool) use ($toolRows): bool {
                    $row = $toolRows->get($tool);

                    return ! $row || ! (bool) ($row->enabled ?? false);
                })
                ->values()
                ->all();

            $missingPermissions = collect($requirement['permissions'])
                ->reject(fn (string $permission): bool => $permissionRows->has($permission))
                ->values()
                ->all();

            $missingDatasets = collect($requirement['datasets'])
                ->reject(fn (string $dataset): bool => $datasetRows->has($dataset))
                ->values()
                ->all();

            $installed = $pluginRows->isEmpty() || $pluginRows->has($plugin);
            $status = ! $installed
                ? 'not_installed'
                : ($missingTools === [] && $missingPermissions === [] && $missingDatasets === [] ? 'ok' : 'warning');

            return [
                'plugin_name' => $this->pluginDisplayName($plugin),
                'plugin_slug' => $plugin,
                'required_tools' => $requirement['tools'],
                'missing_tools' => $missingTools,
                'required_permissions' => $requirement['permissions'],
                'missing_permissions' => $missingPermissions,
                'required_datasets' => $requirement['datasets'],
                'missing_datasets' => $missingDatasets,
                'status' => $status,
                'recommended_action' => $this->compatibilityRecommendation($status, $missingTools, $missingPermissions, $missingDatasets),
            ];
        })->values()->all();
    }

    /**
     * @return Collection<string, object>
     */
    private function installedPluginsBySlug(): Collection
    {
        if (! Schema::hasTable('plugins')) {
            return collect();
        }

        $columns = $this->availableColumns('plugins', ['slug', 'status', 'name']);

        if (! in_array('slug', $columns, true)) {
            return collect();
        }

        return DB::table('plugins')->select($columns)->get()->keyBy('slug');
    }

    /**
     * @param  array<int, string>  $missingTools
     * @param  array<int, string>  $missingPermissions
     * @param  array<int, string>  $missingDatasets
     */
    private function compatibilityRecommendation(string $status, array $missingTools, array $missingPermissions, array $missingDatasets): string
    {
        if ($status === 'not_installed') {
            return 'Plugin is not installed or the plugins table is unavailable.';
        }

        if ($missingTools === [] && $missingPermissions === [] && $missingDatasets === []) {
            return 'No action required.';
        }

        $parts = [];
        if ($missingTools !== []) {
            $parts[] = 'Enable/register missing tools in AI Core.';
        }
        if ($missingPermissions !== []) {
            $parts[] = 'Register or assign the missing permissions.';
        }
        if ($missingDatasets !== []) {
            $parts[] = 'Register the missing datasets before RAG/data workflows.';
        }

        return implode(' ', $parts);
    }

    /**
     * @param  array<int, array<string, mixed>>  $groups
     * @return array<string, int>
     */
    private function settingsStats(array $groups): array
    {
        $settings = collect($groups)->flatMap(fn (array $group): array => $group['settings']);

        return [
            'total' => $settings->count(),
            'modules' => $settings->pluck('module')->unique()->count(),
            'editable' => $settings->where('editable', true)->count(),
            'sensitive' => $settings->where('sensitive_flag', true)->count(),
        ];
    }

    private function canUpdateSettings(Request $request): bool
    {
        $user = $request->user() ?: auth()->user();

        return $user !== null
            && method_exists($user, 'hasPermissionTo')
            && $user->hasPermissionTo(self::UPDATE_PERMISSION);
    }
}
