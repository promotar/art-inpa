<?php

namespace Modules\AiCore;

use Illuminate\Contracts\Auth\Authenticatable;

class AiAgentContextBuilder
{
    public function __construct(
        private readonly AiToolRegistry $tools,
        private readonly AiPermissionService $permissions,
        private readonly AiAgentRuntimeConfig $config,
        private readonly AiAgentMemoryManager $memory,
    ) {
        //
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function build(string $toolSlug, array $payload, array $context, ?Authenticatable $user, string $runId): array
    {
        $plugin = (string) ($context['plugin'] ?? $context['plugin_slug'] ?? $payload['plugin'] ?? 'unknown');
        $conversationId = (string) ($context['conversation_id'] ?? $payload['conversation_id'] ?? '');

        return $this->sanitize([
            'plugin' => $plugin,
            'conversation_id' => $conversationId,
            'run_id' => $runId,
            'requested_tool' => AiToolSlug::canonical($toolSlug),
            'user' => [
                'id' => $user?->getAuthIdentifier(),
                'role' => implode(',', $this->permissions->roles($user)),
                'roles' => $this->permissions->roles($user),
                'plan' => $context['plan'] ?? $context['plan_slug'] ?? $payload['plan'] ?? null,
            ],
            'permissions_summary' => [
                'roles' => $this->permissions->roles($user),
                'enforced_by' => 'ai_core_permission_matrix',
            ],
            'usage_limits_summary' => [
                'enforced_by' => 'ai_core_usage_limits',
                'deduction_policy' => 'deduct_once_after_tool_execution_approval',
            ],
            'available_tools' => $this->availableTools(AiToolSlug::canonical($toolSlug)),
            'recent_messages' => $this->recentMessages($payload, $context),
            'conversation_memory_summary' => $this->memory->summary($plugin, $conversationId, $user),
            'previous_tool_calls' => $this->listValue($context['previous_tool_calls'] ?? $payload['previous_tool_calls'] ?? []),
            'previous_tool_results' => $this->listValue($context['previous_tool_results'] ?? $payload['previous_tool_results'] ?? []),
            'latest_visual_context' => $this->mapValue($context['latest_visual_context'] ?? $context['visual_context'] ?? []),
            'attachments' => $this->listValue($payload['attachments'] ?? $context['attachments'] ?? []),
            'current_user_message' => $this->currentUserMessage($payload, $context),
            'runtime_policy' => [
                'shadow_never_blocks_production' => true,
                'active_production_plugins_blocked' => ['ai-assistant', 'professional-programmer'],
                'stable_runtime_is_source_of_truth_for_permissions_limits_and_tools' => true,
            ],
        ]);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function availableTools(string $requestedTool): array
    {
        $allowed = $this->relatedToolSlugs($requestedTool);

        return collect($this->tools->all())
            ->where('enabled', true)
            ->filter(fn (array $tool): bool => in_array(AiToolSlug::canonical((string) ($tool['slug'] ?? '')), $allowed, true))
            ->map(fn (array $tool): array => [
                'slug' => (string) ($tool['slug'] ?? ''),
                'risk_level' => (string) ($tool['risk_level'] ?? 'medium'),
                'requires_approval' => (bool) ($tool['requires_approval'] ?? false),
                'audit_required' => (bool) ($tool['audit_required'] ?? true),
                'expected_usage_category' => $this->usageCategoryFor((string) ($tool['slug'] ?? '')),
            ])
            ->filter(fn (array $tool): bool => $tool['slug'] !== '')
            ->values()
            ->all();
    }

    /**
     * @return array<int, string>
     */
    private function relatedToolSlugs(string $requestedTool): array
    {
        return match (AiToolSlug::canonical($requestedTool)) {
            'image_generate', 'image_fast_generate' => ['image_generate', 'image_fast_generate', 'image_job_poll'],
            'image_job_poll' => ['image_job_poll'],
            'vision_analyze' => ['vision_analyze'],
            'rag_search' => ['rag_search'],
            'coding_chat' => ['coding_chat', 'rag_search'],
            'training_job_create', 'training_job_status', 'training_job_poll' => ['training_job_create', 'training_job_status', 'training_job_poll'],
            default => [AiToolSlug::canonical($requestedTool)],
        };
    }

    private function usageCategoryFor(string $toolSlug): string
    {
        return match (AiToolSlug::canonical($toolSlug)) {
            'general_chat', 'intent_classify' => 'text_chat',
            'coding_chat' => 'coding_chat',
            'image_generate' => 'image_generate',
            'image_fast_generate' => 'image_fast_generate',
            'vision_analyze' => 'vision_analyze',
            'rag_search', 'rag_index', 'text_embed' => 'rag_search',
            default => 'none',
        };
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @return array<int, mixed>
     */
    private function recentMessages(array $payload, array $context): array
    {
        foreach (['recent_messages', 'history', 'messages', 'conversation'] as $key) {
            $value = $context[$key] ?? $payload[$key] ?? null;
            if (is_array($value)) {
                return array_slice($this->listValue($value), -$this->config->contextWindow());
            }
        }

        return [];
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     */
    private function currentUserMessage(array $payload, array $context): string
    {
        foreach (['message', 'prompt', 'user_text', 'text', 'input', 'content'] as $key) {
            $value = $payload[$key] ?? $context[$key] ?? null;
            if (is_string($value) && trim($value) !== '') {
                return mb_substr(trim($value), 0, 4000);
            }
        }

        return '';
    }

    /**
     * @param array<int|string, mixed> $value
     * @return array<int, mixed>
     */
    private function listValue(array $value): array
    {
        return collect($value)
            ->take(30)
            ->map(fn (mixed $item): mixed => is_array($item) ? $this->sanitize($item) : $this->excerpt($item))
            ->values()
            ->all();
    }

    /**
     * @param array<int|string, mixed> $value
     * @return array<string, mixed>
     */
    private function mapValue(array $value): array
    {
        return $this->sanitize($value);
    }

    /**
     * @param array<int|string, mixed> $payload
     * @return array<string, mixed>
     */
    private function sanitize(array $payload): array
    {
        $safe = [];
        foreach (array_slice($payload, 0, 80, true) as $key => $value) {
            $key = mb_substr((string) $key, 0, 100);
            $lower = strtolower($key);
            if (str_contains($lower, 'api_key') || str_contains($lower, 'token') || str_contains($lower, 'password') || str_contains($lower, 'secret')) {
                $safe[$key] = '[redacted]';
                continue;
            }

            if (is_array($value)) {
                $safe[$key] = array_is_list($value) ? $this->sanitizeListArray($value) : $this->sanitize($value);
            } else {
                $safe[$key] = $this->excerpt($value);
            }
        }

        return $safe;
    }

    /**
     * @param array<int, mixed> $items
     * @return array<int, mixed>
     */
    private function sanitizeListArray(array $items): array
    {
        return collect($items)
            ->take(40)
            ->map(fn (mixed $item): mixed => is_array($item) ? $this->sanitize($item) : $this->excerpt($item))
            ->values()
            ->all();
    }

    private function excerpt(mixed $value): mixed
    {
        if (is_bool($value) || is_int($value) || is_float($value) || $value === null) {
            return $value;
        }

        if (! is_scalar($value)) {
            return '';
        }

        return mb_substr(trim((string) $value), 0, 1500);
    }
}
