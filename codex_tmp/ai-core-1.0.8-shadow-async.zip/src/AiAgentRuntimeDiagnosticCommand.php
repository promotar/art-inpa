<?php

namespace Modules\AiCore;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

class AiAgentRuntimeDiagnosticCommand extends Command
{
    protected $signature = 'ai-core:agent-runtime-diagnostic
        {--plugin=ai-assistant : Plugin slug used for the diagnostic context}
        {--tool=general_chat : AI Core tool slug}
        {--message=Hello from AI Core diagnostic. : Sample user message}
        {--conversation-id=diagnostic : Conversation id}
        {--user-id= : Optional user id}';

    protected $description = 'Run a direct AI Core Agent Runtime diagnostic without production plugin chat.';

    public function handle(AiAgentRuntime $runtime): int
    {
        $plugin = (string) $this->option('plugin');
        $toolSlug = AiToolSlug::canonical((string) $this->option('tool'));
        $message = (string) $this->option('message');
        $conversationId = (string) $this->option('conversation-id');
        $runId = 'diagnostic-'.Str::uuid()->toString();
        $started = microtime(true);
        $user = $this->resolveUser();

        $context = [
            'plugin' => $plugin,
            'conversation_id' => $conversationId,
            'agent_run_id' => $runId,
            'diagnostic' => true,
        ];

        $payload = [
            'plugin' => $plugin,
            'message' => $message,
            'conversation_id' => $conversationId,
        ];

        $decision = [
            'mode' => 'shadow',
            'requested_mode' => 'diagnostic',
            'reason' => 'manual_diagnostic_command',
            'plugin_slug' => $plugin,
            'tool_slug' => $toolSlug,
            'binding' => null,
        ];

        $result = [
            'run_id' => $runId,
            'status' => 'failed',
            'stop_reason' => null,
        ];

        try {
            $result = $runtime->runShadow($toolSlug, $payload, $context, $user, $decision);
        } catch (\Throwable $exception) {
            $result['stop_reason'] = $exception instanceof AiCoreException ? $exception->reasonCode() : 'agent_runtime_failed';
        }

        $latencyMs = (int) round((microtime(true) - $started) * 1000);
        $run = $this->runRow($runId);
        $step = $this->latestStep($runId);
        $stepJson = is_string($step->agent_step_json ?? null) ? json_decode((string) $step->agent_step_json, true) : [];

        $this->line(json_encode([
            'run_id' => $runId,
            'tool_slug' => $toolSlug,
            'plugin' => $plugin,
            'latency_ms' => $latencyMs,
            'run_status' => $run->status ?? ($result['status'] ?? null),
            'stop_reason' => $run->stop_reason ?? ($result['stop_reason'] ?? null),
            'step_id' => $step->step_id ?? null,
            'step_status' => $step->status ?? null,
            'validation_status' => $step->validation_status ?? null,
            'step_type' => $step->step_type ?? null,
            'raw_response_summary' => is_array($stepJson) ? ($stepJson['_agent_raw_response_summary'] ?? null) : null,
            'repair_attempts_used' => is_array($stepJson) ? ($stepJson['_agent_repair_attempts_used'] ?? null) : null,
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE));

        return self::SUCCESS;
    }

    private function resolveUser(): mixed
    {
        $userId = trim((string) $this->option('user-id'));
        if ($userId === '' || ! class_exists(\App\Models\User::class)) {
            return null;
        }

        return \App\Models\User::query()->find((int) $userId);
    }

    private function latestStep(string $runId): ?object
    {
        if (! Schema::hasTable('ai_core_agent_steps')) {
            return null;
        }

        return DB::table('ai_core_agent_steps')
            ->where('run_id', $runId)
            ->orderByDesc('id')
            ->first();
    }

    private function runRow(string $runId): ?object
    {
        if (! Schema::hasTable('ai_core_agent_runs')) {
            return null;
        }

        return DB::table('ai_core_agent_runs')
            ->where('run_id', $runId)
            ->first();
    }
}
