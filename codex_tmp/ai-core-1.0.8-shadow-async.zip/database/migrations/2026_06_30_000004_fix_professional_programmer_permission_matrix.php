<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    private const PLUGIN = 'professional-programmer';

    /**
     * @var array<string, array<string, mixed>>
     */
    private array $tools = [
        'coding_chat' => [
            'endpoint' => '/v1/coding/chat',
            'model_slug' => 'coding_chat',
            'required_permission' => 'professional-programmer.chat',
            'risk_level' => 'high',
            'requires_approval' => true,
            'daily_limit' => 100,
            'cooldown_seconds' => 0,
        ],
        'training_job_create' => [
            'endpoint' => '/v1/coding/training/jobs',
            'model_slug' => 'coding_chat',
            'required_permission' => 'professional-programmer.manage',
            'risk_level' => 'high',
            'requires_approval' => true,
            'daily_limit' => 5,
            'cooldown_seconds' => 300,
        ],
        'training_job_status' => [
            'endpoint' => '/v1/coding/training/status',
            'model_slug' => 'coding_chat',
            'required_permission' => 'professional-programmer.manage',
            'risk_level' => 'medium',
            'requires_approval' => false,
            'daily_limit' => 200,
            'cooldown_seconds' => 0,
        ],
        'training_job_poll' => [
            'endpoint' => '/v1/coding/training/jobs/{job_id}',
            'model_slug' => 'coding_chat',
            'required_permission' => 'professional-programmer.manage',
            'risk_level' => 'medium',
            'requires_approval' => false,
            'daily_limit' => 200,
            'cooldown_seconds' => 0,
        ],
        'rag_search' => [
            'endpoint' => '/v1/rag/search',
            'model_slug' => 'embedding',
            'required_permission' => 'ai-core.tools.execute',
            'risk_level' => 'medium',
            'requires_approval' => false,
            'daily_limit' => 100,
            'cooldown_seconds' => 0,
        ],
    ];

    /**
     * @var array<int, string>
     */
    private array $roles = [
        'super-admin',
        'super_admin',
        'admin',
        'staff',
        'developer',
    ];

    public function up(): void
    {
        $this->syncTools();
        $this->syncPermissionMatrix();
        $this->syncUsageLimits();
        $this->syncProgrammerDataset();
    }

    public function down(): void
    {
        //
    }

    private function syncTools(): void
    {
        if (! Schema::hasTable('ai_core_tools')) {
            return;
        }

        $now = now();

        foreach ($this->tools as $slug => $tool) {
            $updates = [
                'slug' => $slug,
                'plugin_owner' => in_array($slug, ['coding_chat', 'training_job_create', 'training_job_status', 'training_job_poll'], true)
                    ? self::PLUGIN
                    : 'ai-core',
                'endpoint' => $tool['endpoint'],
                'input_schema' => json_encode(['type' => 'object']),
                'output_schema' => json_encode(['type' => 'object']),
                'required_permission' => $tool['required_permission'],
                'risk_level' => $tool['risk_level'],
                'requires_approval' => $tool['requires_approval'],
                'enabled' => true,
                'updated_at' => $now,
            ];

            if (Schema::hasColumn('ai_core_tools', 'model_slug')) {
                $updates['model_slug'] = $tool['model_slug'];
            }
            if (Schema::hasColumn('ai_core_tools', 'allowed_roles')) {
                $updates['allowed_roles'] = json_encode(['admin', 'staff', 'super-admin', 'developer']);
            }
            if (Schema::hasColumn('ai_core_tools', 'daily_limit')) {
                $updates['daily_limit'] = $tool['daily_limit'];
            }
            if (Schema::hasColumn('ai_core_tools', 'cooldown_seconds')) {
                $updates['cooldown_seconds'] = $tool['cooldown_seconds'];
            }
            if (Schema::hasColumn('ai_core_tools', 'audit_required')) {
                $updates['audit_required'] = true;
            }

            DB::table('ai_core_tools')->updateOrInsert(
                ['slug' => $slug],
                array_merge($updates, ['created_at' => $now])
            );
        }
    }

    private function syncPermissionMatrix(): void
    {
        if (! Schema::hasTable('ai_core_tool_permissions')) {
            return;
        }

        $now = now();

        foreach ($this->tools as $toolSlug => $tool) {
            foreach ($this->roles as $role) {
                DB::table('ai_core_tool_permissions')->updateOrInsert(
                    [
                        'tool_slug' => $toolSlug,
                        'plugin_slug' => self::PLUGIN,
                        'role_slug' => $role,
                    ],
                    [
                        'permission' => null,
                        'allowed' => true,
                        'requires_approval' => (bool) $tool['requires_approval'],
                        'limits' => json_encode([]),
                        'updated_at' => $now,
                        'created_at' => $now,
                    ]
                );
            }
        }
    }

    private function syncUsageLimits(): void
    {
        if (! Schema::hasTable('ai_core_usage_limits')) {
            return;
        }

        $now = now();

        foreach ($this->tools as $toolSlug => $tool) {
            foreach ($this->roles as $role) {
                $identity = [
                    'tool_slug' => $toolSlug,
                    'role_slug' => $role,
                    'plugin_slug' => self::PLUGIN,
                ];

                if (Schema::hasColumn('ai_core_usage_limits', 'plan_slug')) {
                    $identity['plan_slug'] = null;
                }

                $updates = [
                    'daily_limit' => $tool['daily_limit'],
                    'enabled' => true,
                    'updated_at' => $now,
                    'created_at' => $now,
                ];

                if (Schema::hasColumn('ai_core_usage_limits', 'monthly_limit')) {
                    $updates['monthly_limit'] = null;
                }
                if (Schema::hasColumn('ai_core_usage_limits', 'cooldown_seconds')) {
                    $updates['cooldown_seconds'] = $tool['cooldown_seconds'];
                }

                DB::table('ai_core_usage_limits')->updateOrInsert($identity, $updates);
            }
        }
    }

    private function syncProgrammerDataset(): void
    {
        if (! Schema::hasTable('ai_core_datasets')) {
            return;
        }

        $now = now();
        $updates = [
            'owner_plugin' => self::PLUGIN,
            'source_type' => 'codebase_metadata',
            'allowed_roles' => json_encode(['admin', 'staff', 'super-admin', 'developer']),
            'allowed_tools' => json_encode(['coding_chat', 'training_job_create', 'training_job_status', 'training_job_poll', 'rag_search']),
            'rag_collection' => 'programmer_laravel_knowledge',
            'privacy_level' => 'restricted',
            'indexing_status' => 'not_indexed',
            'updated_at' => $now,
        ];

        if (Schema::hasColumn('ai_core_datasets', 'qdrant_collection')) {
            $updates['qdrant_collection'] = 'programmer_laravel_knowledge';
        }

        DB::table('ai_core_datasets')->updateOrInsert(
            ['slug' => 'programmer_laravel_knowledge'],
            array_merge($updates, ['created_at' => $now])
        );
    }
};
