<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    private const ROLES = [
        'admin',
        'User Basic',
        'employee',
        'staff',
        'super-admin',
        'user',
        'User Elite',
        'User Plus',
        'User Pro',
    ];

    public function up(): void
    {
        $this->upgradeModels();
        $this->upgradeDatasets();
        $this->upgradeTools();
        $this->upgradeUsageLimits();
        $this->seedControlCenterDefaults();
    }

    public function down(): void
    {
        //
    }

    private function upgradeModels(): void
    {
        if (! Schema::hasTable('ai_core_models')) {
            return;
        }

        Schema::table('ai_core_models', function (Blueprint $table): void {
            $this->stringColumn($table, 'configured_model');
            $this->stringColumn($table, 'runtime_model');
            $this->stringColumn($table, 'runtime_backend');
            $this->booleanColumn($table, 'semantic_enabled');
            $this->integerColumn($table, 'dimensions');
            $this->stringColumn($table, 'collection');
            $this->timestampColumn($table, 'last_verified_at');
            $this->stringColumn($table, 'verification_status');
        });
    }

    private function upgradeDatasets(): void
    {
        if (! Schema::hasTable('ai_core_datasets')) {
            return;
        }

        Schema::table('ai_core_datasets', function (Blueprint $table): void {
            $this->stringColumn($table, 'qdrant_collection');
            $this->integerColumn($table, 'chunks_count', true, 0);
            $this->textColumn($table, 'last_error');
        });
    }

    private function upgradeTools(): void
    {
        if (! Schema::hasTable('ai_core_tools')) {
            return;
        }

        Schema::table('ai_core_tools', function (Blueprint $table): void {
            $this->stringColumn($table, 'model_slug');
            $this->jsonColumn($table, 'allowed_roles');
            $this->integerColumn($table, 'daily_limit');
            $this->integerColumn($table, 'cooldown_seconds', true, 0);
            $this->booleanColumn($table, 'audit_required', true, true);
        });
    }

    private function upgradeUsageLimits(): void
    {
        if (! Schema::hasTable('ai_core_usage_limits')) {
            return;
        }

        Schema::table('ai_core_usage_limits', function (Blueprint $table): void {
            $this->stringColumn($table, 'plan_slug');
            $this->integerColumn($table, 'monthly_limit');
            $this->integerColumn($table, 'cooldown_seconds', true, 0);
        });

        try {
            Schema::table('ai_core_usage_limits', function (Blueprint $table): void {
                $table->dropUnique('ai_core_usage_unique');
            });
        } catch (Throwable) {
            //
        }

        try {
            Schema::table('ai_core_usage_limits', function (Blueprint $table): void {
                $table->unique(['tool_slug', 'role_slug', 'plugin_slug', 'plan_slug'], 'ai_core_usage_role_plan_unique');
            });
        } catch (Throwable) {
            //
        }
    }

    private function seedControlCenterDefaults(): void
    {
        $now = now();

        foreach ($this->models() as $row) {
            DB::table('ai_core_models')->updateOrInsert(
                ['slug' => $row['slug']],
                array_merge($row, ['updated_at' => $now, 'created_at' => $now])
            );
        }

        foreach ($this->tools() as $row) {
            DB::table('ai_core_tools')->updateOrInsert(
                ['slug' => $row['slug']],
                array_merge($row, ['updated_at' => $now, 'created_at' => $now])
            );
        }

        foreach ($this->datasets() as $row) {
            DB::table('ai_core_datasets')->updateOrInsert(
                ['slug' => $row['slug']],
                array_merge($row, ['updated_at' => $now, 'created_at' => $now])
            );
        }

        foreach ($this->usageLimits() as $row) {
            DB::table('ai_core_usage_limits')->updateOrInsert(
                [
                    'tool_slug' => $row['tool_slug'],
                    'role_slug' => $row['role_slug'],
                    'plugin_slug' => $row['plugin_slug'],
                    'plan_slug' => $row['plan_slug'],
                ],
                array_merge($row, ['updated_at' => $now, 'created_at' => $now])
            );
        }
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function models(): array
    {
        return [
            $this->model('general_chat', 'chat', 'ollama', 'qwen3:8b', '/v1/general/chat', 'ollama', true, null, null),
            $this->model('coding_chat', 'coding', 'ollama', 'qwen2.5-coder:7b-instruct', '/v1/coding/chat', 'ollama', true, null, null),
            $this->model('image_generation', 'image', 'comfyui', 'SDXL / ComfyUI', '/v1/images/generate', 'comfyui', false, null, null),
            $this->model('fast_image_generation', 'image', 'comfyui', 'SDXL-Lightning', '/v1/images/fast-generate', 'comfyui', false, null, null),
            $this->model('vision_analysis', 'vision', 'vision-worker + ollama', 'llava:7b', '/v1/vision/analyze', 'vision-worker + ollama', true, null, null),
            $this->model('embedding', 'embedding', 'sentence-transformers', 'paraphrase-multilingual-MiniLM-L12-v2', '/v1/text/embed', 'embedding-worker', true, 384, 'assistant_public_knowledge'),
            $this->model('artwork_similarity', 'similarity', 'clip', 'clip-ViT-B-32', '/v1/artwork/search', 'clip-worker', true, 512, 'artwork_market_knowledge'),
        ];
    }

    private function model(string $slug, string $type, string $backend, string $configured, string $endpoint, string $runtimeBackend, bool $semantic, ?int $dimensions, ?string $collection): array
    {
        return [
            'slug' => $slug,
            'type' => $type,
            'backend' => $backend,
            'configured_model' => $configured,
            'runtime_model' => $configured,
            'runtime_backend' => $runtimeBackend,
            'endpoint' => $endpoint,
            'semantic_enabled' => $semantic,
            'dimensions' => $dimensions,
            'collection' => $collection,
            'verification_status' => 'pending',
            'enabled' => true,
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function tools(): array
    {
        return [
            $this->tool('general_chat', '/v1/general/chat', 'general_chat', 'ai-core.tools.execute', 'low', false, self::ROLES, 100, 0, true),
            $this->tool('coding_chat', '/v1/coding/chat', 'coding_chat', 'professional-programmer.chat', 'high', true, ['admin', 'staff', 'super-admin'], 100, 0, true),
            $this->tool('intent_classify', '/v1/router/intent', 'general_chat', 'ai-core.tools.execute', 'low', false, self::ROLES, 200, 0, true),
            $this->tool('image_generate', '/v1/images/generate', 'image_generation', 'ai-core.tools.execute', 'medium', false, self::ROLES, 4, 15, true),
            $this->tool('image_fast_generate', '/v1/images/fast-generate', 'fast_image_generation', 'ai-core.tools.execute', 'medium', false, self::ROLES, 10, 10, true),
            $this->tool('image_job_poll', '/v1/images/jobs/{job_id}', 'image_generation', 'ai-core.tools.execute', 'low', false, self::ROLES, 500, 0, false),
            $this->tool('vision_analyze', '/v1/vision/analyze', 'vision_analysis', 'ai-core.tools.execute', 'medium', false, self::ROLES, 20, 0, true),
            $this->tool('text_embed', '/v1/text/embed', 'embedding', 'ai-core.manage', 'medium', true, ['admin', 'staff', 'super-admin'], 200, 0, true),
            $this->tool('rag_index', '/v1/rag/index', 'embedding', 'ai-core.manage', 'high', true, ['admin', 'staff', 'super-admin'], 20, 60, true),
            $this->tool('rag_search', '/v1/rag/search', 'embedding', 'ai-core.tools.execute', 'medium', false, self::ROLES, 100, 0, true),
            $this->tool('artwork_index', '/v1/artwork/index', 'artwork_similarity', 'ai-core.manage', 'high', true, ['admin', 'staff', 'super-admin'], 20, 60, true),
            $this->tool('artwork_search', '/v1/artwork/search', 'artwork_similarity', 'ai-core.tools.execute', 'medium', false, self::ROLES, 20, 0, true),
            $this->tool('training_job_create', '/v1/coding/training/jobs', 'coding_chat', 'professional-programmer.manage', 'high', true, ['admin', 'staff', 'super-admin'], 5, 300, true),
            $this->tool('training_job_status', '/v1/coding/training/status', 'coding_chat', 'professional-programmer.manage', 'medium', false, ['admin', 'staff', 'super-admin'], 200, 0, true),
            $this->tool('training_job_poll', '/v1/coding/training/jobs/{job_id}', 'coding_chat', 'professional-programmer.manage', 'medium', false, ['admin', 'staff', 'super-admin'], 200, 0, true),
        ];
    }

    private function tool(string $slug, string $endpoint, string $modelSlug, string $permission, string $risk, bool $approval, array $roles, int $dailyLimit, int $cooldown, bool $audit): array
    {
        return [
            'slug' => $slug,
            'plugin_owner' => 'ai-core',
            'endpoint' => $endpoint,
            'model_slug' => $modelSlug,
            'required_permission' => $permission,
            'risk_level' => $risk,
            'requires_approval' => $approval,
            'allowed_roles' => json_encode($roles),
            'daily_limit' => $dailyLimit,
            'cooldown_seconds' => $cooldown,
            'audit_required' => $audit,
            'enabled' => true,
            'input_schema' => json_encode(['type' => 'object']),
            'output_schema' => json_encode(['type' => 'object']),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function datasets(): array
    {
        return [
            $this->dataset('assistant_public_knowledge', 'ai-assistant', 'platform_content', 'assistant_public_knowledge', 'public', ['guest', 'user', 'admin', 'super-admin'], ['general_chat', 'rag_search']),
            $this->dataset('programmer_laravel_knowledge', 'professional-programmer', 'codebase_metadata', 'programmer_laravel_knowledge', 'restricted', ['admin', 'staff', 'super-admin'], ['coding_chat', 'rag_index', 'rag_search', 'training_job_create']),
            $this->dataset('artwork_market_knowledge', 'artwork-commerce-ai', 'market_data', 'artwork_market_knowledge', 'internal', ['user', 'admin', 'super-admin'], ['rag_search', 'artwork_search', 'artwork_index']),
            $this->dataset('staff_reports_knowledge', 'staff-reports-ai', 'reports', 'staff_reports_knowledge', 'confidential', ['admin', 'staff', 'super-admin'], ['rag_search', 'general_chat']),
        ];
    }

    private function dataset(string $slug, string $owner, string $source, string $collection, string $privacy, array $roles, array $tools): array
    {
        return [
            'slug' => $slug,
            'owner_plugin' => $owner,
            'source_type' => $source,
            'rag_collection' => $collection,
            'qdrant_collection' => $collection,
            'privacy_level' => $privacy,
            'allowed_roles' => json_encode($roles),
            'allowed_tools' => json_encode($tools),
            'indexing_status' => 'not_indexed',
            'chunks_count' => 0,
            'last_error' => null,
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function usageLimits(): array
    {
        $rows = [];
        $dailyByRole = [
            'admin' => 200,
            'User Basic' => 40,
            'employee' => 120,
            'staff' => 160,
            'super-admin' => 1000,
            'user' => 50,
            'User Elite' => 250,
            'User Plus' => 120,
            'User Pro' => 200,
        ];

        foreach (self::ROLES as $role) {
            foreach (['general_chat', 'rag_search', 'vision_analyze', 'artwork_search', 'image_generate', 'image_fast_generate'] as $tool) {
                $rows[] = [
                    'tool_slug' => $tool,
                    'role_slug' => $role,
                    'plugin_slug' => null,
                    'plan_slug' => null,
                    'daily_limit' => $tool === 'image_generate' ? 4 : ($tool === 'image_fast_generate' ? 10 : $dailyByRole[$role]),
                    'monthly_limit' => $tool === 'image_generate' ? 100 : null,
                    'cooldown_seconds' => str_contains($tool, 'image') ? 15 : 0,
                    'enabled' => true,
                ];
            }
        }

        return $rows;
    }

    private function stringColumn(Blueprint $table, string $column): void
    {
        if (! Schema::hasColumn($table->getTable(), $column)) {
            $table->string($column)->nullable();
        }
    }

    private function textColumn(Blueprint $table, string $column): void
    {
        if (! Schema::hasColumn($table->getTable(), $column)) {
            $table->text($column)->nullable();
        }
    }

    private function jsonColumn(Blueprint $table, string $column): void
    {
        if (! Schema::hasColumn($table->getTable(), $column)) {
            $table->json($column)->nullable();
        }
    }

    private function integerColumn(Blueprint $table, string $column, bool $default = false, int $defaultValue = 0): void
    {
        if (! Schema::hasColumn($table->getTable(), $column)) {
            $definition = $table->unsignedInteger($column)->nullable();
            if ($default) {
                $definition->default($defaultValue);
            }
        }
    }

    private function booleanColumn(Blueprint $table, string $column, bool $default = false, bool $defaultValue = false): void
    {
        if (! Schema::hasColumn($table->getTable(), $column)) {
            $definition = $table->boolean($column)->nullable();
            if ($default) {
                $definition->default($defaultValue);
            }
        }
    }

    private function timestampColumn(Blueprint $table, string $column): void
    {
        if (! Schema::hasColumn($table->getTable(), $column)) {
            $table->timestamp($column)->nullable();
        }
    }
};
