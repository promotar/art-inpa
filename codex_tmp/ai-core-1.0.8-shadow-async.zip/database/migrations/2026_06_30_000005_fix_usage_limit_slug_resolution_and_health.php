<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * @var array<string, string>
     */
    private array $aliases = [
        'generate_image' => 'image_generate',
        'image_generation' => 'image_generate',
        'fast_generate_image' => 'image_fast_generate',
        'fast_image_generation' => 'image_fast_generate',
        'generate_fast_image' => 'image_fast_generate',
        'analyze_image' => 'vision_analyze',
        'image_analyze' => 'vision_analyze',
        'vision_analysis' => 'vision_analyze',
        'search_artwork' => 'artwork_search',
        'artwork_similarity' => 'artwork_search',
        'rag_question' => 'rag_search',
        'knowledge_search' => 'rag_search',
        'chat_general' => 'general_chat',
        'coding_assistant' => 'coding_chat',
    ];

    public function up(): void
    {
        $this->canonicalizeToolSlugs('ai_core_tools', 'slug');
        $this->canonicalizeToolSlugs('ai_core_tool_permissions', 'tool_slug');
        $this->canonicalizeToolSlugs('ai_core_usage_limits', 'tool_slug');
        $this->deduplicateUsageLimits();
        $this->ensureSuperAdminImageLimits();
    }

    public function down(): void
    {
        //
    }

    private function canonicalizeToolSlugs(string $table, string $column): void
    {
        if (! Schema::hasTable($table) || ! Schema::hasColumn($table, $column)) {
            return;
        }

        foreach ($this->aliases as $alias => $canonical) {
            $aliasRows = DB::table($table)->where($column, $alias)->get();
            if ($aliasRows->isEmpty()) {
                continue;
            }

            if ($table === 'ai_core_tools' && DB::table($table)->where($column, $canonical)->exists()) {
                DB::table($table)->where($column, $alias)->delete();
                continue;
            }

            DB::table($table)
                ->where($column, $alias)
                ->update(array_filter([
                    $column => $canonical,
                    'updated_at' => Schema::hasColumn($table, 'updated_at') ? now() : null,
                ], fn (mixed $value): bool => $value !== null));
        }
    }

    private function deduplicateUsageLimits(): void
    {
        if (! Schema::hasTable('ai_core_usage_limits')) {
            return;
        }

        $hasPlan = Schema::hasColumn('ai_core_usage_limits', 'plan_slug');
        $rows = DB::table('ai_core_usage_limits')->orderBy('id')->get();

        $rows
            ->groupBy(function (object $row) use ($hasPlan): string {
                return implode('|', [
                    (string) ($row->tool_slug ?? ''),
                    (string) ($row->role_slug ?? ''),
                    (string) ($row->plugin_slug ?? ''),
                    $hasPlan ? (string) ($row->plan_slug ?? '') : '',
                ]);
            })
            ->each(function ($group): void {
                if ($group->count() < 2) {
                    return;
                }

                $ordered = $group->sortByDesc(function (object $row): int {
                    $daily = $row->daily_limit === null ? 1000000000 : (int) $row->daily_limit;
                    $monthly = property_exists($row, 'monthly_limit') && $row->monthly_limit === null ? 1000000000 : (int) ($row->monthly_limit ?? 0);
                    $cooldown = property_exists($row, 'cooldown_seconds') ? (int) ($row->cooldown_seconds ?? 0) : 0;

                    return ((bool) ($row->enabled ?? false) ? 1000000000000 : 0)
                        + ($daily * 1000000)
                        + ($monthly * 10)
                        - $cooldown
                        + (int) $row->id;
                })->values();

                $keep = $ordered->first();
                $deleteIds = $ordered->skip(1)->pluck('id')->all();

                $updates = [
                    'enabled' => $group->contains(fn (object $row): bool => (bool) ($row->enabled ?? false)),
                    'daily_limit' => $group->contains(fn (object $row): bool => $row->daily_limit === null)
                        ? null
                        : $group->max(fn (object $row): int => (int) ($row->daily_limit ?? 0)),
                    'updated_at' => now(),
                ];

                if (Schema::hasColumn('ai_core_usage_limits', 'monthly_limit')) {
                    $updates['monthly_limit'] = $group->contains(fn (object $row): bool => property_exists($row, 'monthly_limit') && $row->monthly_limit === null)
                        ? null
                        : $group->max(fn (object $row): int => (int) ($row->monthly_limit ?? 0));
                }

                if (Schema::hasColumn('ai_core_usage_limits', 'cooldown_seconds')) {
                    $updates['cooldown_seconds'] = $group->min(fn (object $row): int => (int) ($row->cooldown_seconds ?? 0));
                }

                DB::table('ai_core_usage_limits')->where('id', $keep->id)->update($updates);
                DB::table('ai_core_usage_limits')->whereIn('id', $deleteIds)->delete();
            });
    }

    private function ensureSuperAdminImageLimits(): void
    {
        if (! Schema::hasTable('ai_core_usage_limits')) {
            return;
        }

        foreach (['image_generate', 'image_fast_generate'] as $toolSlug) {
            $identity = [
                'tool_slug' => $toolSlug,
                'role_slug' => 'super-admin',
                'plugin_slug' => null,
            ];

            if (Schema::hasColumn('ai_core_usage_limits', 'plan_slug')) {
                $identity['plan_slug'] = null;
            }

            $updates = [
                'daily_limit' => 100000,
                'enabled' => true,
                'updated_at' => now(),
                'created_at' => now(),
            ];

            if (Schema::hasColumn('ai_core_usage_limits', 'monthly_limit')) {
                $updates['monthly_limit'] = 1000000;
            }

            if (Schema::hasColumn('ai_core_usage_limits', 'cooldown_seconds')) {
                $updates['cooldown_seconds'] = 0;
            }

            DB::table('ai_core_usage_limits')->updateOrInsert($identity, $updates);
        }
    }
};
