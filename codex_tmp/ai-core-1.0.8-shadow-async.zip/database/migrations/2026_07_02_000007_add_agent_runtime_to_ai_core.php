<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('ai_core_agent_runtime_bindings') === false) {
            Schema::create('ai_core_agent_runtime_bindings', function (Blueprint $table): void {
                $table->id();
                $table->string('plugin_slug')->index();
                $table->string('tool_slug')->index();
                $table->string('mode')->default('off')->index();
                $table->boolean('enabled')->default(false);
                $table->string('agent_model')->nullable();
                $table->unsignedInteger('max_tool_loops')->nullable();
                $table->text('notes')->nullable();
                $table->timestamps();
                $table->unique(['plugin_slug', 'tool_slug'], 'ai_core_agent_binding_unique');
            });
        }

        if (Schema::hasTable('ai_core_agent_runs') === false) {
            Schema::create('ai_core_agent_runs', function (Blueprint $table): void {
                $table->id();
                $table->string('run_id')->unique();
                $table->foreignId('ai_core_request_id')->nullable()->index();
                $table->foreignId('ai_core_audit_log_id')->nullable()->index();
                $table->foreignId('user_id')->nullable()->index();
                $table->string('plugin_slug')->nullable()->index();
                $table->string('root_tool_slug')->nullable()->index();
                $table->string('mode')->default('shadow')->index();
                $table->string('agent_model')->nullable();
                $table->string('status')->default('started')->index();
                $table->unsignedInteger('loop_count')->default(0);
                $table->string('stop_reason')->nullable();
                $table->string('context_hash')->nullable()->index();
                $table->unsignedInteger('latency_ms')->nullable();
                $table->text('final_message_summary')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamp('started_at')->nullable();
                $table->timestamp('finished_at')->nullable();
                $table->timestamps();
            });
        }

        if (Schema::hasTable('ai_core_agent_steps') === false) {
            Schema::create('ai_core_agent_steps', function (Blueprint $table): void {
                $table->id();
                $table->string('run_id')->index();
                $table->string('step_id')->unique();
                $table->foreignId('ai_core_request_id')->nullable()->index();
                $table->foreignId('ai_core_audit_log_id')->nullable()->index();
                $table->unsignedInteger('loop_index')->default(0);
                $table->string('step_type')->nullable()->index();
                $table->string('status')->nullable()->index();
                $table->string('tool_slug')->nullable()->index();
                $table->string('validation_status')->nullable();
                $table->string('tool_idempotency_key')->nullable()->unique();
                $table->string('tool_arguments_hash')->nullable()->index();
                $table->string('tool_result_status')->nullable()->index();
                $table->json('agent_step_json')->nullable();
                $table->json('tool_result_payload')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
            });
        }

        if (Schema::hasTable('ai_core_agent_memories') === false) {
            Schema::create('ai_core_agent_memories', function (Blueprint $table): void {
                $table->id();
                $table->foreignId('user_id')->nullable()->index();
                $table->string('plugin_slug')->nullable()->index();
                $table->string('conversation_id')->nullable()->index();
                $table->longText('memory_summary')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->unique(['user_id', 'plugin_slug', 'conversation_id'], 'ai_core_agent_memory_unique');
            });
        }

        $this->seedSettings();
        $this->seedBindings();
    }

    public function down(): void
    {
        foreach ([
            'ai_core_agent_memories',
            'ai_core_agent_steps',
            'ai_core_agent_runs',
            'ai_core_agent_runtime_bindings',
        ] as $table) {
            Schema::dropIfExists($table);
        }
    }

    private function seedSettings(): void
    {
        if (! Schema::hasTable('ai_core_settings')) {
            return;
        }

        $now = now();
        foreach ($this->settings() as $setting) {
            DB::table('ai_core_settings')->updateOrInsert(
                ['key' => $setting['key']],
                array_merge($setting, ['created_at' => $now, 'updated_at' => $now])
            );
        }
    }

    private function seedBindings(): void
    {
        if (! Schema::hasTable('ai_core_agent_runtime_bindings')) {
            return;
        }

        $now = now();
        foreach ([
            [
                'plugin_slug' => 'agent-runtime-test',
                'tool_slug' => 'general_chat',
                'mode' => 'active',
                'enabled' => true,
                'notes' => 'Controlled test binding only. Global agent_runtime_enabled remains false by default.',
            ],
            [
                'plugin_slug' => 'ai-assistant',
                'tool_slug' => 'general_chat',
                'mode' => 'shadow',
                'enabled' => false,
                'notes' => 'Production plugin shadow binding. Active mode is blocked by AI Core in this phase.',
            ],
            [
                'plugin_slug' => 'professional-programmer',
                'tool_slug' => 'coding_chat',
                'mode' => 'shadow',
                'enabled' => false,
                'notes' => 'Production plugin shadow binding. Active mode is blocked by AI Core in this phase.',
            ],
        ] as $binding) {
            DB::table('ai_core_agent_runtime_bindings')->updateOrInsert(
                [
                    'plugin_slug' => $binding['plugin_slug'],
                    'tool_slug' => $binding['tool_slug'],
                ],
                array_merge($binding, ['updated_at' => $now, 'created_at' => $now])
            );
        }
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function settings(): array
    {
        return [
            $this->setting('agent_runtime_enabled', '0', 'boolean', 'Master switch for AI Core Agent Runtime. When disabled, AI Core uses the stable runtime only.', 'Agent Runtime Enabled', 'toggle'),
            $this->setting('agent_model', 'qwen3:8b', 'string', 'Model used for Agent Runtime protocol decisions.', 'Agent Model', 'text'),
            $this->setting('max_tool_loops', '4', 'integer', 'Maximum tool loops allowed inside one active agent run.', 'Max Tool Loops', 'number', 'loops', 1, 10),
            $this->setting('context_window', '8', 'integer', 'Recent conversation messages included in the agent context envelope.', 'Context Window', 'number', 'messages', 1, 30),
            $this->setting('memory_summary_enabled', '1', 'boolean', 'Allow AI Core to store short agent memory summaries in the database.', 'Memory Summary Enabled', 'toggle'),
            $this->setting('protocol_repair_attempts', '1', 'integer', 'Maximum strict JSON repair attempts after an invalid agent protocol response.', 'Protocol Repair Attempts', 'number', 'attempts', 0, 2),
            $this->setting('tool_result_followup_enabled', '1', 'boolean', 'Send tool results back to the model for one or more follow-up decisions in active test runs.', 'Tool Result Follow-up Enabled', 'toggle'),
            $this->setting('debug_for_super_admin', '0', 'boolean', 'Allow super-admin-only agent runtime debug visibility.', 'Agent Debug For Super Admin', 'toggle'),
            $this->setting('agent_runtime_fail_open_to_legacy', '0', 'boolean', 'Allow safe non-expensive general_chat active-agent failures to fall back to the stable runtime. High-risk and expensive tools fail closed.', 'Fail Open To Legacy', 'toggle'),
            $this->setting('agent_shadow_timeout_ms', '1500', 'integer', 'Maximum time for non-blocking shadow planning before stable runtime continues.', 'Shadow Timeout', 'number', 'milliseconds', 250, 5000),
        ];
    }

    private function setting(
        string $key,
        string $value,
        string $type,
        string $description,
        string $label,
        string $component,
        ?string $unit = null,
        int|float|null $min = null,
        int|float|null $max = null,
    ): array {
        return [
            'key' => $key,
            'value' => $value,
            'type' => $type,
            'default_value' => $value,
            'validation_rules' => json_encode([]),
            'description' => $description,
            'category' => 'agent_runtime',
            'module' => 'ai-core',
            'visibility_level' => 'admin',
            'admin_access_level' => 'super_admin',
            'editable' => true,
            'required' => true,
            'sensitive_flag' => false,
            'public_exposure_allowed' => false,
            'frontend_available' => false,
            'cache_enabled' => true,
            'cache_ttl' => 300,
            'ui_component' => $component,
            'ui_label' => $label,
            'allowed_values' => null,
            'min_value' => $min,
            'max_value' => $max,
            'unit' => $unit,
            'depends_on' => null,
            'restart_required' => false,
            'approval_required' => false,
            'status' => 'active',
            'version' => 1,
        ];
    }
};
