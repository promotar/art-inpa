<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('ai_core_settings')) {
            return;
        }

        $now = now();
        foreach ($this->settings() as $setting) {
            DB::table('ai_core_settings')->updateOrInsert(
                ['key' => $setting['key']],
                array_merge($setting, ['created_at' => $now, 'updated_at' => $now])
            );
        }
    }

    public function down(): void
    {
        //
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function settings(): array
    {
        return [
            $this->setting(
                'planner_enabled',
                '1',
                'boolean',
                'Enable AI Core Semantic Planner audit-only analysis before tool execution.',
                'Planner Enabled',
                'toggle'
            ),
            $this->setting(
                'planner_shadow_mode',
                '1',
                'boolean',
                'Keep planner advisory only. Planner output must not control runtime execution.',
                'Planner Shadow Mode',
                'toggle'
            ),
            $this->setting(
                'planner_model',
                'qwen3:8b',
                'string',
                'Model name sent to the AI Gateway for semantic planning.',
                'Planner Model',
                'text'
            ),
            $this->setting(
                'planner_context_window',
                '8',
                'integer',
                'Maximum recent conversation messages included in the planner input.',
                'Planner Context Window',
                'number',
                'messages',
                1,
                20
            ),
            $this->setting(
                'planner_confidence_threshold',
                '0.70',
                'decimal',
                'Planner confidence reference threshold for audit review only.',
                'Planner Confidence Threshold',
                'number',
                null,
                0,
                1
            ),
            $this->setting(
                'planner_debug_for_super_admin',
                '0',
                'boolean',
                'Allow super-admin-only debug visibility for planner audit review. Runtime remains unchanged.',
                'Planner Debug For Super Admin',
                'toggle'
            ),
        ];
    }

    private function setting(
        string $key,
        string $value,
        string $type,
        string $description,
        string $label,
        string $component,
        ?string $unit = null,
        int|float|null $min = null,
        int|float|null $max = null,
    ): array {
        return [
            'key' => $key,
            'value' => $value,
            'type' => $type,
            'default_value' => $value,
            'validation_rules' => json_encode([]),
            'description' => $description,
            'category' => 'planner',
            'module' => 'ai-core',
            'visibility_level' => 'admin',
            'admin_access_level' => 'super_admin',
            'editable' => true,
            'required' => true,
            'sensitive_flag' => false,
            'public_exposure_allowed' => false,
            'frontend_available' => false,
            'cache_enabled' => true,
            'cache_ttl' => 300,
            'ui_component' => $component,
            'ui_label' => $label,
            'allowed_values' => null,
            'min_value' => $min,
            'max_value' => $max,
            'unit' => $unit,
            'depends_on' => null,
            'restart_required' => false,
            'approval_required' => false,
            'status' => 'active',
            'version' => 1,
        ];
    }
};
