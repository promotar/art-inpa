<x-app-layout>
    @php
        $aiCoreValue = function (mixed $value): string {
            if ($value === null || $value === '') {
                return 'unknown';
            }

            if (is_bool($value)) {
                return $value ? 'true' : 'false';
            }

            if (is_scalar($value)) {
                return (string) $value;
            }

            return str(json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE))->limit(120)->toString();
        };

        $aiCoreHealthValue = null;
        $aiCoreHealthValue = function (mixed $value) use (&$aiCoreHealthValue): string {
            if ($value === null || $value === '') {
                return 'Unknown';
            }

            if (is_bool($value)) {
                return $value ? 'OK' : 'Failed';
            }

            if (is_array($value)) {
                $candidate = data_get($value, 'ok')
                    ?? data_get($value, 'healthy')
                    ?? data_get($value, 'status')
                    ?? data_get($value, 'state');

                return $candidate === null ? 'Unknown' : $aiCoreHealthValue($candidate);
            }

            $text = strtolower((string) $value);

            if (in_array($text, ['ok', 'healthy', 'up', 'running', 'available', 'true', '1', 'ready'], true)) {
                return 'OK';
            }

            if (in_array($text, ['failed', 'fail', 'down', 'error', 'unavailable', 'false', '0', 'offline'], true)) {
                return 'Failed';
            }

            if (str_contains($text, 'fail') || str_contains($text, 'error') || str_contains($text, 'down')) {
                return 'Failed';
            }

            if (str_contains($text, 'ok') || str_contains($text, 'healthy') || str_contains($text, 'running')) {
                return 'OK';
            }

            return ucfirst((string) $value);
        };

        $aiCoreHealthClass = fn (mixed $value): string => match ($aiCoreHealthValue($value)) {
            'OK' => 'is-ok',
            'Failed' => 'is-danger',
            default => 'is-warn',
        };

        $healthStatus = (string) ($healthSnapshot['status'] ?? data_get($healthSnapshot, 'health.overall_status', 'not_synced'));
        $healthBadgeClass = match ($healthStatus) {
            'healthy' => 'is-ok',
            'failed' => 'is-danger',
            default => 'is-warn',
        };
        $healthLabel = match ($healthStatus) {
            'healthy' => 'Healthy',
            'failed' => 'Failed',
            'degraded' => 'Degraded',
            default => 'Not synced',
        };
    @endphp

    <x-slot name="header">
        <div class="ai-core-hero">
            <div>
                <p class="ai-core-eyebrow">Central AI Control Center</p>
                <h1>AI Core</h1>
                <p>Official gateway, model runtime, tool, dataset, limits, permissions, and audit control layer for Laravel AI plugins.</p>
            </div>
            <div class="ai-core-actions">
                @if($canUpdateSettings)
                    <form method="POST" action="{{ route('admin.plugins.ai-core.sync') }}">
                        @csrf
                        <button class="ai-core-button" type="submit">Sync From AI Server</button>
                    </form>
                @endif
                <span class="ai-core-status">
                    <span class="ai-core-dot"></span>
                    <span>Installed</span>
                </span>
            </div>
        </div>
    </x-slot>

    <div class="ai-core-page">
        @if(session('status'))
            <div class="ai-core-alert is-success">{{ session('status') }}</div>
        @endif

        @if(session('error'))
            <div class="ai-core-alert is-error">{{ session('error') }}</div>
        @endif

        @if(isset($errors) && $errors->any())
            <div class="ai-core-alert is-error">
                <strong>Request failed.</strong>
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <section class="ai-core-kpis" aria-label="AI Core overview">
            <article>
                <span>Registered Settings</span>
                <strong>{{ $settingsStats['total'] ?? 0 }}</strong>
                <small>{{ $settingsStats['modules'] ?? 0 }} modules</small>
            </article>
            <article>
                <span>Editable Settings</span>
                <strong>{{ $settingsStats['editable'] ?? 0 }}</strong>
                <small>database-backed</small>
            </article>
            <article>
                <span>Runtime Models</span>
                <strong>{{ count($models) }}</strong>
                <small>{{ collect($models)->where('verification_status', 'verified')->count() }} verified</small>
            </article>
            <article>
                <span>Audit Events</span>
                <strong>{{ $auditCount }}</strong>
                <small>{{ $requestCount }} requests</small>
            </article>
        </section>

        <section class="ai-core-panel">
            <div class="ai-core-panel__head">
                <div>
                    <h2>Health Check</h2>
                    <p>Last known AI Server runtime state from <code>/health</code> and <code>/models</code>.</p>
                </div>
                <span class="ai-core-badge {{ $healthBadgeClass }}">
                    {{ $healthLabel }}
                </span>
            </div>

            <dl class="ai-core-detail-grid">
                <div>
                    <dt>AI Server URL</dt>
                    <dd>{{ $healthSnapshot['gateway_base_url'] ?? ($settings['gateway_base_url'] ?? 'Not configured') }}</dd>
                </div>
                <div>
                    <dt>Gateway Status</dt>
                    <dd><span class="ai-core-badge {{ $aiCoreHealthClass(data_get($healthSnapshot, 'health.gateway_status')) }}">{{ $aiCoreHealthValue(data_get($healthSnapshot, 'health.gateway_status')) }}</span></dd>
                </div>
                <div>
                    <dt>Ollama</dt>
                    <dd><span class="ai-core-badge {{ $aiCoreHealthClass(data_get($healthSnapshot, 'health.ollama_status')) }}">{{ $aiCoreHealthValue(data_get($healthSnapshot, 'health.ollama_status')) }}</span></dd>
                </div>
                <div>
                    <dt>ComfyUI</dt>
                    <dd><span class="ai-core-badge {{ $aiCoreHealthClass(data_get($healthSnapshot, 'health.comfyui_status')) }}">{{ $aiCoreHealthValue(data_get($healthSnapshot, 'health.comfyui_status')) }}</span></dd>
                </div>
                <div>
                    <dt>Qdrant</dt>
                    <dd><span class="ai-core-badge {{ $aiCoreHealthClass(data_get($healthSnapshot, 'health.qdrant_status')) }}">{{ $aiCoreHealthValue(data_get($healthSnapshot, 'health.qdrant_status')) }}</span></dd>
                </div>
                <div>
                    <dt>Vision Worker</dt>
                    <dd><span class="ai-core-badge {{ $aiCoreHealthClass(data_get($healthSnapshot, 'health.vision_worker_status')) }}">{{ $aiCoreHealthValue(data_get($healthSnapshot, 'health.vision_worker_status')) }}</span></dd>
                </div>
                <div>
                    <dt>Embedding Worker</dt>
                    <dd><span class="ai-core-badge {{ $aiCoreHealthClass(data_get($healthSnapshot, 'health.embedding_worker_status')) }}">{{ $aiCoreHealthValue(data_get($healthSnapshot, 'health.embedding_worker_status')) }}</span></dd>
                </div>
                <div>
                    <dt>production_semantic</dt>
                    @php
                        $productionSemantic = data_get($healthSnapshot, 'health.production_semantic');
                    @endphp
                    <dd><span class="ai-core-badge {{ $aiCoreHealthClass($productionSemantic) }}">{{ $productionSemantic === null ? 'Unknown' : ($productionSemantic ? 'true' : 'false') }}</span></dd>
                </div>
                <div>
                    <dt>Overall Status</dt>
                    <dd>{{ $healthLabel }}</dd>
                </div>
                <div>
                    <dt>Last Health Check</dt>
                    <dd>{{ $healthSnapshot['checked_at'] ?? 'Never' }}</dd>
                </div>
            </dl>

            @if(!empty($healthSnapshot['models']))
                <div class="ai-core-runtime-list">
                    <strong>Current runtime models</strong>
                    <div class="ai-core-badges">
                        @foreach($healthSnapshot['models'] as $runtimeModel)
                            <span class="ai-core-badge is-info">{{ $runtimeModel }}</span>
                        @endforeach
                    </div>
                </div>
            @endif
        </section>

        <section class="ai-core-panel">
            <div class="ai-core-panel__head">
                <div>
                    <h2>Tool Readiness</h2>
                    <p>Runtime readiness is checked per tool so unrelated degraded services do not block healthy workflows.</p>
                </div>
            </div>

            <div class="ai-core-table-wrap">
                <table class="ai-core-table">
                    <thead>
                        <tr>
                            <th>Tool</th>
                            <th>Required runtime</th>
                            <th>Status</th>
                            <th>Reason</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($toolReadiness ?? [] as $tool)
                            <tr>
                                <td><strong>{{ $tool['tool'] }}</strong></td>
                                <td>{{ $tool['dependencies'] }}</td>
                                <td>
                                    <span class="ai-core-badge {{ $tool['ready'] ? 'is-ok' : 'is-danger' }}">
                                        {{ $tool['ready'] ? 'Ready' : 'Blocked' }}
                                    </span>
                                </td>
                                <td>
                                    <code>{{ $tool['reason_code'] ?? 'ready' }}</code>
                                    <small>{{ $tool['message'] }}</small>
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="4">No tool readiness checks available.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </section>

        <section class="ai-core-panel">
            <div class="ai-core-panel__head">
                <div>
                    <h2>Gateway Settings</h2>
                    <p>AI Core is the only approved storage owner for AI Gateway URL and API key.</p>
                </div>
            </div>

            <dl class="ai-core-detail-grid">
                <div>
                    <dt>Base URL</dt>
                    <dd>{{ $settings['gateway_base_url'] ?? 'Not configured' }}</dd>
                </div>
                <div>
                    <dt>API Key</dt>
                    <dd>
                        <span class="ai-core-badge {{ ($settings['gateway_api_key'] ?? 'missing') === 'configured' ? 'is-ok' : 'is-warn' }}">
                            {{ $settings['gateway_api_key'] ?? 'missing' }}
                        </span>
                    </dd>
                </div>
                <div>
                    <dt>Default Timeout</dt>
                    <dd>{{ $settings['default_timeout'] ?? 60 }} seconds</dd>
                </div>
                <div>
                    <dt>Image Timeout</dt>
                    <dd>{{ $settings['image_timeout'] ?? 300 }} seconds</dd>
                </div>
            </dl>
        </section>

        <section class="ai-core-panel">
            <div class="ai-core-panel__head">
                <div>
                    <h2>Agent Runtime Bindings</h2>
                    <p>Agent Runtime is opt-in per plugin/tool. Production plugins are limited to shadow mode in this phase.</p>
                </div>
                @if($canUpdateSettings)
                    <button class="ai-core-button" form="ai-core-agent-bindings-form" type="submit">Save Agent Bindings</button>
                @endif
            </div>
            <form id="ai-core-agent-bindings-form" method="POST" action="{{ route('admin.plugins.ai-core.agent-bindings.update') }}">
                @csrf
                <div class="ai-core-table-wrap">
                    <table class="ai-core-table">
                        <thead>
                            <tr>
                                <th>Plugin</th>
                                <th>Tool</th>
                                <th>Mode</th>
                                <th>Enabled</th>
                                <th>Agent Model</th>
                                <th>Max Loops</th>
                                <th>Policy Note</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($agentRuntimeBindings as $binding)
                                @php
                                    $isProductionAgentPlugin = in_array($binding['plugin_slug'], ['ai-assistant', 'professional-programmer'], true);
                                @endphp
                                <tr>
                                    <td><strong>{{ $binding['plugin_slug'] }}</strong></td>
                                    <td><code>{{ $binding['tool_slug'] }}</code></td>
                                    <td>
                                        <select class="ai-core-control is-small" name="bindings[{{ $binding['id'] }}][mode]" @disabled(! $canUpdateSettings)>
                                            <option value="off" @selected($binding['mode'] === 'off')>off</option>
                                            <option value="shadow" @selected($binding['mode'] === 'shadow')>shadow</option>
                                            <option value="active" @selected($binding['mode'] === 'active')>active</option>
                                        </select>
                                        @if($isProductionAgentPlugin)
                                            <small>Active is downgraded to shadow by AI Core.</small>
                                        @endif
                                    </td>
                                    <td>
                                        <input type="hidden" name="bindings[{{ $binding['id'] }}][enabled]" value="0">
                                        <input type="checkbox" name="bindings[{{ $binding['id'] }}][enabled]" value="1" @checked($binding['enabled']) @disabled(! $canUpdateSettings)>
                                    </td>
                                    <td>
                                        <input class="ai-core-control" type="text" name="bindings[{{ $binding['id'] }}][agent_model]" value="{{ $binding['agent_model'] ?? '' }}" placeholder="{{ $settings['agent_model'] ?? 'qwen3:8b' }}" @disabled(! $canUpdateSettings)>
                                    </td>
                                    <td>
                                        <input class="ai-core-control is-small" type="number" min="1" max="10" name="bindings[{{ $binding['id'] }}][max_tool_loops]" value="{{ $binding['max_tool_loops'] ?? '' }}" @disabled(! $canUpdateSettings)>
                                    </td>
                                    <td>{{ $binding['notes'] ?? '-' }}</td>
                                </tr>
                            @empty
                                <tr><td colspan="7">No Agent Runtime bindings registered yet.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
                @if($canUpdateSettings && $agentRuntimeBindings !== [])
                    <div class="ai-core-form-footer"><button class="ai-core-button" type="submit">Save Agent Bindings</button></div>
                @endif
            </form>
        </section>

        <section class="ai-core-panel">
            <div class="ai-core-panel__head">
                <div>
                    <h2>Plugin Settings Registry / Overview</h2>
                    <p>AI Core lists other plugin settings as registry metadata only. Editing stays in each plugin settings page.</p>
                </div>
            </div>

            <div class="ai-core-table-wrap">
                <table class="ai-core-table">
                    <thead>
                        <tr>
                            <th>Plugin / Module</th>
                            <th>Settings Count</th>
                            <th>Sensitive Count</th>
                            <th>Editable Count</th>
                            <th>Status</th>
                            <th>Settings Page</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($pluginSettingsOverview as $pluginSetting)
                            <tr>
                                <td><strong>{{ $pluginSetting['plugin_name'] }}</strong><code>{{ $pluginSetting['module'] }}</code></td>
                                <td>{{ $pluginSetting['count'] }}</td>
                                <td>{{ $pluginSetting['sensitive_count'] }}</td>
                                <td>{{ $pluginSetting['editable_count'] }}</td>
                                <td>
                                    <span class="ai-core-badge {{ $pluginSetting['status'] === 'active' ? 'is-ok' : 'is-warn' }}">
                                        {{ $pluginSetting['status'] }}
                                    </span>
                                </td>
                                <td>
                                    @if($pluginSetting['settings_url'])
                                        <a class="ai-core-button is-light" href="{{ $pluginSetting['settings_url'] }}">Open Settings</a>
                                    @else
                                        <span class="ai-core-badge is-warn">No settings route</span>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="6">No plugin settings registered yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </section>

        <section class="ai-core-panel">
            <div class="ai-core-panel__head">
                <div>
                    <h2>AI Core Settings</h2>
                    <p>Only AI Core-owned editable settings can be changed here. Values are saved in `ai_core_settings`.</p>
                </div>
                @if($canUpdateSettings)
                    <button class="ai-core-button" form="ai-core-settings-form" type="submit">Save AI Core Settings</button>
                @else
                    <span class="ai-core-badge is-warn">Requires ai-core.settings.update</span>
                @endif
            </div>

            <form id="ai-core-settings-form" method="POST" action="{{ route('admin.plugins.ai-core.settings.update') }}">
                @csrf
                @forelse($aiCoreSettingGroups as $group)
                    <details class="ai-core-accordion" {{ $loop->first ? 'open' : '' }}>
                        <summary>
                            <span>
                                <strong>{{ $group['module'] }}</strong>
                                <small>{{ $group['group_key'] }} · {{ $group['category'] }}</small>
                            </span>
                            <span class="ai-core-accordion__meta">
                                {{ $group['count'] }} settings
                                @if($group['sensitive_count'] > 0)
                                    · {{ $group['sensitive_count'] }} sensitive
                                @endif
                            </span>
                        </summary>

                        <div class="ai-core-table-wrap">
                            <table class="ai-core-table">
                                <thead>
                                    <tr>
                                        <th>Setting</th>
                                        <th>Type</th>
                                        <th>Value</th>
                                        <th>Policy</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($group['settings'] as $setting)
                                        <tr>
                                            <td>
                                                <strong>{{ $setting['label'] }}</strong>
                                                <code>{{ $setting['group_key'] }}.{{ $setting['setting_key'] }}</code>
                                                @if($setting['description'])
                                                    <small>{{ $setting['description'] }}</small>
                                                @endif
                                            </td>
                                            <td>{{ $setting['type'] }}</td>
                                            <td>
                                                @if($canUpdateSettings && $setting['editable'])
                                                    @php
                                                        $fieldName = 'ai_core_settings['.$setting['setting_key'].']';
                                                        $fieldId = 'ai-core-setting-'.md5($setting['source_table'].'|'.$setting['group_key'].'|'.$setting['setting_key']);
                                                        $type = $setting['type'];
                                                        $formValue = $setting['form_value'];
                                                        $truthy = in_array((string) $formValue, ['1', 'true', 'yes', 'on'], true) || $formValue === true;
                                                    @endphp

                                                    @if($type === 'boolean')
                                                        <input type="hidden" name="{{ $fieldName }}" value="0">
                                                        <label class="ai-core-toggle" for="{{ $fieldId }}">
                                                            <input id="{{ $fieldId }}" type="checkbox" name="{{ $fieldName }}" value="1" @checked($truthy)>
                                                            <span>Enabled</span>
                                                        </label>
                                                    @elseif(in_array($type, ['textarea', 'json'], true))
                                                        <textarea id="{{ $fieldId }}" class="ai-core-control" name="{{ $fieldName }}" rows="3">{{ $formValue }}</textarea>
                                                    @elseif($type === 'password' || $setting['sensitive_flag'])
                                                        <input id="{{ $fieldId }}" class="ai-core-control" type="password" name="{{ $fieldName }}" value="" placeholder="Leave blank to keep current value">
                                                        <small>Current value: {{ $setting['value_summary'] }}</small>
                                                    @elseif($type === 'integer')
                                                        <input id="{{ $fieldId }}" class="ai-core-control" type="number" step="1" name="{{ $fieldName }}" value="{{ $formValue }}">
                                                    @elseif(in_array($type, ['decimal', 'float'], true))
                                                        <input id="{{ $fieldId }}" class="ai-core-control" type="number" step="0.01" name="{{ $fieldName }}" value="{{ $formValue }}">
                                                    @elseif($type === 'url')
                                                        <input id="{{ $fieldId }}" class="ai-core-control" type="url" name="{{ $fieldName }}" value="{{ $formValue }}">
                                                    @else
                                                        <input id="{{ $fieldId }}" class="ai-core-control" type="text" name="{{ $fieldName }}" value="{{ $formValue }}">
                                                    @endif
                                                @else
                                                    {{ $setting['value_summary'] }}
                                                @endif
                                            </td>
                                            <td>
                                                <div class="ai-core-badges">
                                                    <span class="ai-core-badge {{ $setting['editable'] ? 'is-ok' : '' }}">{{ $setting['editable'] ? 'Editable' : 'Locked' }}</span>
                                                    @if($setting['sensitive_flag']) <span class="ai-core-badge is-danger">Sensitive</span> @endif
                                                    @if($setting['approval_required']) <span class="ai-core-badge is-warn">Approval</span> @endif
                                                </div>
                                            </td>
                                            <td>{{ $setting['status'] }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </details>
                @empty
                    <div class="ai-core-empty">No AI Core settings were found.</div>
                @endforelse
                @if($canUpdateSettings && $aiCoreSettingGroups !== [])
                    <div class="ai-core-form-footer">
                        <button class="ai-core-button" type="submit">Save AI Core Settings</button>
                    </div>
                @endif
            </form>
        </section>

        <section class="ai-core-panel">
            <div class="ai-core-panel__head">
                <div>
                    <h2>Plugin Compatibility Check</h2>
                    <p>Read-only check for plugin requirements against AI Core tools, permissions, and datasets.</p>
                </div>
            </div>
            <div class="ai-core-table-wrap">
                <table class="ai-core-table">
                    <thead>
                        <tr>
                            <th>Plugin</th>
                            <th>Required Tools</th>
                            <th>Missing Tools</th>
                            <th>Required Permissions</th>
                            <th>Missing Permissions</th>
                            <th>Required Datasets</th>
                            <th>Missing Datasets</th>
                            <th>Status</th>
                            <th>Recommended Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($compatibilityChecks as $check)
                            <tr>
                                <td><strong>{{ $check['plugin_name'] }}</strong><code>{{ $check['plugin_slug'] }}</code></td>
                                <td>{{ implode(', ', $check['required_tools']) ?: '-' }}</td>
                                <td>{{ implode(', ', $check['missing_tools']) ?: '-' }}</td>
                                <td>{{ implode(', ', $check['required_permissions']) ?: '-' }}</td>
                                <td>{{ implode(', ', $check['missing_permissions']) ?: '-' }}</td>
                                <td>{{ implode(', ', $check['required_datasets']) ?: '-' }}</td>
                                <td>{{ implode(', ', $check['missing_datasets']) ?: '-' }}</td>
                                <td>
                                    <span class="ai-core-badge {{ $check['status'] === 'ok' ? 'is-ok' : ($check['status'] === 'not_installed' ? 'is-warn' : 'is-danger') }}">
                                        {{ $check['status'] }}
                                    </span>
                                </td>
                                <td>{{ $check['recommended_action'] }}</td>
                            </tr>
                        @empty
                            <tr><td colspan="9">No AI plugin compatibility rules are registered yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </section>

        <section class="ai-core-panel">
            <div class="ai-core-panel__head">
                <div>
                    <h2>Model Registry</h2>
                    <p>Configured model values and verified runtime values from the AI Server.</p>
                </div>
            </div>
            <div class="ai-core-table-wrap">
                <table class="ai-core-table">
                    <thead>
                        <tr>
                            <th>Slug</th>
                            <th>Configured</th>
                            <th>Runtime</th>
                            <th>Backend</th>
                            <th>Endpoint</th>
                            <th>Semantic</th>
                            <th>Vector</th>
                            <th>Verified</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($models as $model)
                            <tr>
                                <td><strong>{{ $model['slug'] }}</strong><small>{{ $model['type'] }}</small></td>
                                <td>{{ $model['configured_model'] ?? '-' }}</td>
                                <td>{{ $model['runtime_model'] ?? '-' }}</td>
                                <td>{{ $model['runtime_backend'] ?? $model['backend'] }}</td>
                                <td><code>{{ $model['endpoint'] }}</code></td>
                                <td>{{ !empty($model['semantic_enabled']) ? 'Yes' : 'No' }}</td>
                                <td>
                                    {{ $model['dimensions'] ?? '-' }}
                                    @if(!empty($model['collection']))
                                        <small>{{ $model['collection'] }}</small>
                                    @endif
                                </td>
                                <td>
                                    <span class="ai-core-badge {{ ($model['verification_status'] ?? '') === 'verified' ? 'is-ok' : 'is-warn' }}">
                                        {{ $model['verification_status'] ?? 'pending' }}
                                    </span>
                                    <small>{{ $model['last_verified_at'] ?? 'Never' }}</small>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </section>

        <section class="ai-core-panel">
            <div class="ai-core-panel__head">
                <div>
                    <h2>Tool Registry</h2>
                    <p>Whitelisted endpoints only. Deprecated endpoints are blocked by AI Core.</p>
                </div>
            </div>
            <div class="ai-core-table-wrap">
                <table class="ai-core-table">
                    <thead>
                        <tr>
                            <th>Tool</th>
                            <th>Owner</th>
                            <th>Endpoint</th>
                            <th>Model</th>
                            <th>Permission</th>
                            <th>Risk</th>
                            <th>Approval</th>
                            <th>Roles</th>
                            <th>Limits</th>
                            <th>Audit</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($tools as $tool)
                            <tr>
                                <td><strong>{{ $tool['slug'] }}</strong><small>{{ $tool['enabled'] ? 'enabled' : 'disabled' }}</small></td>
                                <td>{{ $tool['plugin_owner'] ?? 'ai-core' }}</td>
                                <td><code>{{ $tool['endpoint'] }}</code></td>
                                <td>{{ $tool['model_slug'] ?? '-' }}</td>
                                <td>{{ $tool['required_permission'] ?? '-' }}</td>
                                <td><span class="ai-core-badge {{ $tool['risk_level'] === 'high' ? 'is-danger' : ($tool['risk_level'] === 'medium' ? 'is-warn' : 'is-ok') }}">{{ $tool['risk_level'] }}</span></td>
                                <td>{{ $tool['requires_approval'] ? 'Required' : 'No' }}</td>
                                <td>{{ implode(', ', (array) ($tool['allowed_roles'] ?? [])) ?: '-' }}</td>
                                <td>{{ $tool['daily_limit'] ?? '-' }}/day · {{ $tool['cooldown_seconds'] ?? 0 }}s</td>
                                <td>{{ $tool['audit_required'] ?? true ? 'Required' : 'Optional' }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </section>

        <section class="ai-core-panel">
            <div class="ai-core-panel__head">
                <div>
                    <h2>Dataset Indexing</h2>
                    <p>Dataset policies, Qdrant collection mapping, indexing status, and management actions.</p>
                </div>
            </div>
            <div class="ai-core-table-wrap">
                <table class="ai-core-table">
                    <thead>
                        <tr>
                            <th>Dataset</th>
                            <th>Collection</th>
                            <th>Privacy</th>
                            <th>Roles</th>
                            <th>Tools</th>
                            <th>Status</th>
                            <th>Last Error</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($datasets as $dataset)
                            <tr>
                                <td><strong>{{ $dataset['slug'] }}</strong><small>{{ $dataset['owner_plugin'] }} · {{ $dataset['source_type'] }}</small></td>
                                <td>{{ $dataset['qdrant_collection'] ?? $dataset['rag_collection'] ?? '-' }}<small>{{ $dataset['chunks_count'] ?? 0 }} chunks</small></td>
                                <td>{{ $dataset['privacy_level'] }}</td>
                                <td>{{ implode(', ', (array) ($dataset['allowed_roles'] ?? [])) }}</td>
                                <td>{{ implode(', ', (array) ($dataset['allowed_tools'] ?? [])) }}</td>
                                <td>
                                    <span class="ai-core-badge {{ ($dataset['indexing_status'] ?? '') === 'indexed' ? 'is-ok' : (($dataset['indexing_status'] ?? '') === 'failed' ? 'is-danger' : 'is-warn') }}">
                                        {{ $dataset['indexing_status'] ?? 'not_indexed' }}
                                    </span>
                                    <small>{{ $dataset['last_indexed_at'] ?? 'Never' }}</small>
                                </td>
                                <td>{{ $dataset['last_error'] ?? '-' }}</td>
                                <td>
                                    @if($canUpdateSettings)
                                        <div class="ai-core-row-actions">
                                            <form method="POST" action="{{ route('admin.plugins.ai-core.datasets.index', $dataset['slug']) }}">@csrf<button class="ai-core-button is-light" type="submit">Index Now</button></form>
                                            <form method="POST" action="{{ route('admin.plugins.ai-core.datasets.reindex', $dataset['slug']) }}">@csrf<button class="ai-core-button is-light" type="submit">Re-index</button></form>
                                            <form method="POST" action="{{ route('admin.plugins.ai-core.datasets.clear', $dataset['slug']) }}">@csrf<button class="ai-core-button is-light" type="submit">Clear Index</button></form>
                                            <details class="ai-core-error-details">
                                                <summary class="ai-core-button is-light">View Error</summary>
                                                <div>{{ $dataset['last_error'] ?? 'No error recorded.' }}</div>
                                            </details>
                                        </div>
                                    @else
                                        <details class="ai-core-error-details">
                                            <summary class="ai-core-button is-light">View Error</summary>
                                            <div>{{ $dataset['last_error'] ?? 'No error recorded.' }}</div>
                                        </details>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr><td colspan="8">No datasets registered yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </section>

        <section class="ai-core-panel">
            <div class="ai-core-panel__head">
                <div>
                    <h2>Usage Limits</h2>
                    <p>Editable limits by role, plan, and tool. These values are stored in `ai_core_usage_limits`.</p>
                </div>
                @if($canUpdateSettings)
                    <button class="ai-core-button" form="ai-core-limits-form" type="submit">Save Usage Limits</button>
                @endif
            </div>
            <form class="ai-core-filter-bar" method="GET" action="{{ route('admin.plugins.ai-core.index') }}">
                <label>
                    <span>Role</span>
                    <input class="ai-core-control" type="text" name="usage_role_slug" value="{{ $usageFilters['role_slug'] ?? '' }}" placeholder="admin">
                </label>
                <label>
                    <span>Plan</span>
                    <input class="ai-core-control" type="text" name="usage_plan_slug" value="{{ $usageFilters['plan_slug'] ?? '' }}" placeholder="pro">
                </label>
                <label>
                    <span>Tool</span>
                    <input class="ai-core-control" type="text" name="usage_tool_slug" value="{{ $usageFilters['tool_slug'] ?? '' }}" placeholder="image_generate">
                </label>
                <button class="ai-core-button is-light" type="submit">Filter</button>
                <a class="ai-core-button is-light" href="{{ route('admin.plugins.ai-core.index') }}">Clear</a>
            </form>
            <form id="ai-core-limits-form" method="POST" action="{{ route('admin.plugins.ai-core.usage-limits.update') }}">
                @csrf
                <div class="ai-core-table-wrap">
                    <table class="ai-core-table">
                        <thead>
                            <tr>
                                <th>Role</th>
                                <th>Plan</th>
                                <th>Tool</th>
                                <th>Daily</th>
                                <th>Monthly</th>
                                <th>Cooldown</th>
                                <th>Enabled</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($usageLimits as $limit)
                                <tr>
                                    <td>{{ $limit['role_slug'] ?? 'any' }}</td>
                                    <td>{{ $limit['plan_slug'] ?? 'any' }}</td>
                                    <td><strong>{{ $limit['tool_slug'] }}</strong></td>
                                    <td><input class="ai-core-control is-small" type="number" min="0" name="limits[{{ $limit['id'] }}][daily_limit]" value="{{ $limit['daily_limit'] }}"></td>
                                    <td><input class="ai-core-control is-small" type="number" min="0" name="limits[{{ $limit['id'] }}][monthly_limit]" value="{{ $limit['monthly_limit'] ?? '' }}"></td>
                                    <td><input class="ai-core-control is-small" type="number" min="0" name="limits[{{ $limit['id'] }}][cooldown_seconds]" value="{{ $limit['cooldown_seconds'] ?? 0 }}"></td>
                                    <td>
                                        <input type="hidden" name="limits[{{ $limit['id'] }}][enabled]" value="0">
                                        <input type="checkbox" name="limits[{{ $limit['id'] }}][enabled]" value="1" @checked($limit['enabled']) @disabled(! $canUpdateSettings)>
                                    </td>
                                </tr>
                            @empty
                                <tr><td colspan="7">No usage limits registered yet.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
                @if($canUpdateSettings && $usageLimits !== [])
                    <div class="ai-core-form-footer"><button class="ai-core-button" type="submit">Save Usage Limits</button></div>
                @endif
            </form>
        </section>
    </div>

    <style>
        :root {
            --ai-core-bg: #f8fafc;
            --ai-core-surface: #ffffff;
            --ai-core-border: #e2e8f0;
            --ai-core-ink: #0f172a;
            --ai-core-muted: #64748b;
            --ai-core-blue: #2563eb;
            --ai-core-green: #166534;
            --ai-core-red: #991b1b;
            --ai-core-amber: #92400e;
            --ai-core-radius: 8px;
        }

        .ai-core-hero,
        .ai-core-actions,
        .ai-core-status,
        .ai-core-panel__head,
        .ai-core-row-actions {
            align-items: center;
            display: flex;
            gap: 12px;
        }

        .ai-core-hero {
            justify-content: space-between;
            margin: 0 auto;
            max-width: 1480px;
            padding: 0 20px;
        }

        .ai-core-hero h1 {
            color: var(--ai-core-ink);
            font-size: 28px;
            font-weight: 800;
            margin: 0 0 6px;
        }

        .ai-core-hero p,
        .ai-core-panel__head p,
        .ai-core-table small,
        .ai-core-kpis span,
        .ai-core-kpis small {
            color: var(--ai-core-muted);
        }

        .ai-core-eyebrow {
            color: var(--ai-core-blue) !important;
            font-size: 12px;
            font-weight: 800;
            letter-spacing: .08em;
            margin-bottom: 6px !important;
            text-transform: uppercase;
        }

        .ai-core-page {
            background: var(--ai-core-bg);
            min-height: calc(100vh - 120px);
            padding: 28px;
        }

        .ai-core-kpis {
            display: grid;
            gap: 16px;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            margin: 0 auto 18px;
            max-width: 1480px;
        }

        .ai-core-kpis article,
        .ai-core-panel {
            background: var(--ai-core-surface);
            border: 1px solid var(--ai-core-border);
            border-radius: var(--ai-core-radius);
            box-shadow: 0 1px 2px rgba(15, 23, 42, .04);
        }

        .ai-core-kpis article {
            padding: 18px;
        }

        .ai-core-kpis strong {
            color: var(--ai-core-ink);
            display: block;
            font-size: 32px;
            line-height: 1.1;
            margin: 8px 0 4px;
        }

        .ai-core-panel {
            margin: 0 auto 18px;
            max-width: 1480px;
            overflow: hidden;
        }

        .ai-core-panel__head {
            border-bottom: 1px solid var(--ai-core-border);
            justify-content: space-between;
            padding: 20px 22px;
        }

        .ai-core-panel__head h2 {
            color: var(--ai-core-ink);
            font-size: 18px;
            font-weight: 800;
            margin: 0 0 4px;
        }

        .ai-core-detail-grid {
            display: grid;
            gap: 14px;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            margin: 0;
            padding: 22px;
        }

        .ai-core-detail-grid div,
        .ai-core-runtime-list {
            background: var(--ai-core-bg);
            border: 1px solid var(--ai-core-border);
            border-radius: var(--ai-core-radius);
            padding: 14px;
        }

        .ai-core-runtime-list {
            margin: 0 22px 22px;
        }

        .ai-core-detail-grid dt {
            color: var(--ai-core-muted);
            font-size: 12px;
            font-weight: 800;
            margin-bottom: 6px;
            text-transform: uppercase;
        }

        .ai-core-detail-grid dd {
            color: var(--ai-core-ink);
            font-weight: 800;
            margin: 0;
            word-break: break-word;
        }

        .ai-core-alert {
            border: 1px solid var(--ai-core-border);
            border-radius: var(--ai-core-radius);
            margin: 0 auto 18px;
            max-width: 1480px;
            padding: 14px 18px;
        }

        .ai-core-alert.is-success {
            background: #ecfdf5;
            color: var(--ai-core-green);
        }

        .ai-core-alert.is-error {
            background: #fef2f2;
            color: var(--ai-core-red);
        }

        .ai-core-status {
            background: #ecfdf5;
            border: 1px solid #bbf7d0;
            border-radius: 999px;
            color: var(--ai-core-green);
            font-size: 13px;
            font-weight: 800;
            padding: 8px 12px;
        }

        .ai-core-dot {
            background: #22c55e;
            border-radius: 999px;
            height: 8px;
            width: 8px;
        }

        .ai-core-accordion {
            border-top: 1px solid var(--ai-core-border);
        }

        .ai-core-accordion summary {
            align-items: center;
            cursor: pointer;
            display: flex;
            gap: 16px;
            justify-content: space-between;
            list-style: none;
            padding: 18px 22px;
        }

        .ai-core-accordion summary::-webkit-details-marker {
            display: none;
        }

        .ai-core-table-wrap {
            overflow-x: auto;
        }

        .ai-core-filter-bar {
            align-items: end;
            border-bottom: 1px solid var(--ai-core-border);
            display: grid;
            gap: 12px;
            grid-template-columns: repeat(3, minmax(160px, 1fr)) auto auto;
            padding: 16px 22px;
        }

        .ai-core-filter-bar label {
            color: var(--ai-core-muted);
            display: grid;
            font-size: 12px;
            font-weight: 900;
            gap: 6px;
            text-transform: uppercase;
        }

        .ai-core-table {
            border-collapse: collapse;
            min-width: 1080px;
            width: 100%;
        }

        .ai-core-table th {
            background: var(--ai-core-bg);
            border-bottom: 1px solid var(--ai-core-border);
            color: #475569;
            font-size: 12px;
            font-weight: 900;
            padding: 12px 14px;
            text-align: left;
            text-transform: uppercase;
        }

        .ai-core-table td {
            border-bottom: 1px solid var(--ai-core-border);
            color: #334155;
            padding: 14px;
            vertical-align: top;
        }

        .ai-core-table td strong {
            color: var(--ai-core-ink);
            display: block;
            font-weight: 800;
            margin-bottom: 4px;
        }

        .ai-core-table code {
            background: #eef2ff;
            border-radius: 4px;
            color: #3730a3;
            display: inline-block;
            font-size: 12px;
            padding: 3px 6px;
        }

        .ai-core-badges {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
        }

        .ai-core-badge {
            background: #f1f5f9;
            border-radius: 999px;
            color: #475569;
            display: inline-flex;
            font-size: 12px;
            font-weight: 800;
            padding: 4px 8px;
            white-space: nowrap;
        }

        .ai-core-badge.is-ok { background: #dcfce7; color: var(--ai-core-green); }
        .ai-core-badge.is-warn { background: #fef3c7; color: var(--ai-core-amber); }
        .ai-core-badge.is-danger { background: #fee2e2; color: var(--ai-core-red); }
        .ai-core-badge.is-info { background: #dbeafe; color: #1e40af; }

        .ai-core-button {
            background: var(--ai-core-ink);
            border: 1px solid var(--ai-core-ink);
            border-radius: 6px;
            color: #ffffff;
            cursor: pointer;
            font-size: 13px;
            font-weight: 900;
            line-height: 1;
            padding: 11px 14px;
            white-space: nowrap;
        }

        .ai-core-button.is-light {
            background: #ffffff;
            color: var(--ai-core-ink);
        }

        .ai-core-error-details {
            position: relative;
        }

        .ai-core-error-details summary {
            list-style: none;
        }

        .ai-core-error-details summary::-webkit-details-marker {
            display: none;
        }

        .ai-core-error-details div {
            background: #ffffff;
            border: 1px solid var(--ai-core-border);
            border-radius: var(--ai-core-radius);
            box-shadow: 0 10px 30px rgba(15, 23, 42, .16);
            color: var(--ai-core-ink);
            margin-top: 8px;
            max-width: 340px;
            min-width: 240px;
            padding: 12px;
            position: absolute;
            right: 0;
            white-space: normal;
            z-index: 20;
        }

        .ai-core-control {
            background: #ffffff;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            color: var(--ai-core-ink);
            font-size: 13px;
            min-height: 38px;
            padding: 8px 10px;
            width: min(100%, 520px);
        }

        .ai-core-control.is-small {
            max-width: 110px;
        }

        textarea.ai-core-control {
            min-height: 88px;
            resize: vertical;
        }

        .ai-core-toggle {
            align-items: center;
            display: inline-flex;
            gap: 8px;
            font-weight: 800;
        }

        .ai-core-form-footer {
            align-items: center;
            background: var(--ai-core-bg);
            border-top: 1px solid var(--ai-core-border);
            display: flex;
            justify-content: flex-end;
            padding: 16px 22px;
        }

        .ai-core-empty {
            color: var(--ai-core-muted);
            padding: 22px;
        }

        @media (max-width: 900px) {
            .ai-core-hero,
            .ai-core-panel__head,
            .ai-core-accordion summary {
                align-items: flex-start;
                flex-direction: column;
            }

            .ai-core-filter-bar {
                grid-template-columns: 1fr;
            }

            .ai-core-page {
                padding: 16px;
            }
        }
    </style>
</x-app-layout>
