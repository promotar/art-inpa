# AI Core Plugin

AI Core is the central AI execution layer for Art INPA Laravel plugins.

It is not a chat widget and not a repair console. It owns shared AI infrastructure:

- AI Gateway connection and API key
- model registry
- dataset and knowledge registry
- tool registry
- permission matrix
- usage limits and rate limits
- request, response, and audit logs
- tool results
- RAG requests
- image generation jobs
- vision requests
- artwork similarity requests
- training profile requests

All AI plugins must call the AI Server through AI Core:

```text
Plugin -> AI Core -> AI Server 10.10.0.40:8080
```

## Database Source of Truth

Editable AI operational settings are stored in `ai_core_settings`.

The Gateway API key must not be stored in child plugins. Child plugins may keep display or widget copy settings, but AI Gateway connection values belong to AI Core.

## Default Models

| Function | Model |
| --- | --- |
| general_chat | qwen3:8b |
| coding_chat | qwen2.5-coder:7b-instruct |
| image_generation | SDXL / ComfyUI |
| fast_image_generation | SDXL-Lightning |
| vision_analysis | llava:7b |
| embedding | paraphrase-multilingual-MiniLM-L12-v2 |
| artwork_similarity | clip-ViT-B-32 |

## Default Tools

- general_chat
- coding_chat
- intent_classify
- image_generate
- image_fast_generate
- image_job_poll
- vision_analyze
- text_embed
- rag_index
- rag_search
- artwork_index
- artwork_search
- training_job_create
- training_job_status
- training_job_poll

## Final AI Server Endpoints

AI Core allows only the final AI Server contract:

```text
GET  /health
GET  /models
POST /v1/router/intent
POST /v1/general/chat
POST /v1/coding/chat
POST /v1/images/generate
POST /v1/images/fast-generate
GET  /v1/images/jobs/{job_id}
POST /v1/vision/analyze
POST /v1/text/embed
POST /v1/rag/index
POST /v1/rag/search
POST /v1/artwork/index
POST /v1/artwork/search
GET  /v1/coding/training/status
POST /v1/coding/training/jobs
GET  /v1/coding/training/jobs/{job_id}
```

Unknown or deprecated tool endpoints are blocked before execution.

## Sync From AI Server

The AI Core admin page includes `Sync From AI Server`.

It calls:

- `GET /health`
- `GET /models`

Sync updates runtime model metadata and health snapshots only. It does not overwrite admin-managed permissions or usage limits.

## Usage Limits and Datasets

Usage limits are stored in `ai_core_usage_limits` by role, plan, and tool:

- daily limit
- monthly limit
- cooldown seconds
- enabled state

Datasets expose indexing status, Qdrant collection, chunk count, last indexed timestamp, allowed roles/tools, privacy level, and last error.

## Permission and Audit Flow

Every tool execution follows this sequence:

1. Load tool registry row.
2. Load model profile for the tool.
3. Check AI Core permission matrix.
4. Check usage limit.
5. Create `ai_core_requests` row.
6. Send request to the AI Gateway.
7. Store `ai_core_responses`.
8. Store `ai_core_tool_results` when relevant.
9. Write audit events for permission checks and failures.

## Child Plugin Integration

Child plugins should resolve `Modules\AiCore\AiCore` from the Laravel container and call named AI Core operations:

```php
app(\Modules\AiCore\AiCore::class)->chat($payload, [
    'plugin' => 'ai-assistant',
], $user);
```

Specialized consumer methods are also available:

- `detectIntent`
- `chat`
- `chatCoding`
- `generateImage`
- `fastGenerateImage`
- `pollImageJob`
- `analyzeImage`
- `searchArtwork`
- `searchRag`
- `logToolResult`
- `trainingJobCreate`
- `trainingJobStatus`
- `trainingJobPoll`

## Safety Rules

- AI Server API keys are never exposed to frontend code.
- AI Gateway API key is masked in the AI Core admin UI.
- Child plugins must not call the AI Server directly after AI Core is installed.
- Sensitive tools require permission and audit.
- Laravel remains responsible for platform data access and permission checks.
- The AI Gateway never receives raw database access.
- Large base64 payloads and secrets are redacted from audit logs.
- AI Core must not become a full settings editor for child plugins. Child plugin settings are displayed in AI Core only as a read-only Plugin Settings Registry / Overview.
- AI Core-owned editable settings are updated only through `ai_core_settings`.
- Plugin Compatibility Check reports missing tools, permissions, and datasets for consumer plugins without modifying those plugins.

## Professional Programmer Permission Matrix

AI Core explicitly allows `professional-programmer` for the following tools through `ai_core_tool_permissions`:

- `coding_chat`
- `training_job_create`
- `training_job_status`
- `training_job_poll`
- `rag_search`

The current privileged role slugs are:

- `super-admin`
- `super_admin`
- `admin`
- `staff`
- `developer`

All listed tools require audit. `coding_chat` and `training_job_create` are high-risk and approval-required. `training_job_status`, `training_job_poll`, and `rag_search` are medium-risk and do not require approval.

`programmer_laravel_knowledge` is the dataset registry entry for the programmer plugin. AI Core keeps this dataset available to the programmer tools but does not index it automatically.

## Tool-Specific Readiness

AI Core readiness is tool-specific. Consumer plugins must not be blocked by unrelated runtime state.

Image tools:

- `image_generate`
- `image_fast_generate`

These require only AI Core enabled state, configured Gateway URL/API key, reachable Gateway, enabled tool, allowed role/limit, and healthy ComfyUI. They must not be blocked by RAG indexing status, `production_semantic`, embedding worker, Qdrant, vision worker, Ollama, or unrelated model state.

RAG tools require embedding worker and Qdrant readiness:

- `rag_search`
- `rag_index`
- `text_embed`

Vision requires the vision worker:

- `vision_analyze`

Coding and training tools require Ollama readiness:

- `coding_chat`
- `training_job_create`
- `training_job_status`
- `training_job_poll`

Safe reason codes returned by AI Core exceptions:

- `tool_disabled`
- `role_not_allowed`
- `limit_exceeded`
- `gateway_unreachable`
- `backend_unavailable`
- `dependency_degraded`

AI Core must not expose API keys, raw stack traces, or raw connection details to consumer plugins.

## Agent Runtime Hybrid Protocol

AI Core includes an additive Agent Runtime path. It is disabled by default and must not replace the stable runtime globally.

Database settings:

- `agent_runtime_enabled`: master switch, default `false`.
- `agent_model`: model used for strict agent protocol steps.
- `max_tool_loops`: maximum active tool loops, default `4`.
- `context_window`: recent messages included in the context envelope.
- `memory_summary_enabled`: stores short conversation memory summaries in `ai_core_agent_memories`.
- `protocol_repair_attempts`: strict JSON repair attempts, default `1`.
- `tool_result_followup_enabled`: sends tool results back to the model for active test runs.
- `debug_for_super_admin`: super-admin debug visibility.
- `agent_runtime_fail_open_to_legacy`: default `false`; only safe non-expensive `general_chat` may fall back when enabled.
- `agent_shadow_timeout_ms`: non-blocking shadow timeout, default `1500`.

Runtime bindings are stored in `ai_core_agent_runtime_bindings` and are opt-in per plugin/tool. Production plugins such as `ai-assistant` and `professional-programmer` are restricted to shadow mode in this phase; active mode is only allowed for controlled test bindings.

Shadow mode never blocks production responses. If shadow planning fails, times out, returns invalid JSON, or throws an exception, AI Core logs the failure and continues the stable runtime response unchanged. Shadow mode must not affect image polling, vision, RAG, usage limits, or consumer plugin response shapes.

Active mode runs an agent loop:

1. Build a sanitized context envelope.
2. Ask the agent model for strict JSON.
3. Validate protocol enums, tool slug, confidence, and required fields.
4. Execute tools only through `AiToolBroker`.
5. Return tool results to the model for evaluation.
6. Stop on final response, clarification, async job creation, max loop, or safety failure.

Every active tool call receives a run/step idempotency key. Replayed steps must not double-execute tools or double-deduct usage. Async tool statuses include `job_created`, `job_polling`, `job_completed`, and `job_failed`; image generation preserves the existing polling flow.

Agent audit is linked to existing AI Core audit/request context through `run_id`, `step_id`, `ai_core_audit_log_id`, `agent_run_id`, and `agent_step_id` metadata. Existing AI Core request, response, usage, and audit tables remain authoritative.
